﻿namespace ImageCapture
{
    partial class EdgeToolForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EdgeToolForm));
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.TBIndex = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TBSerial = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnHeightBeDivide = new System.Windows.Forms.Button();
            this.btnSaveROI = new System.Windows.Forms.Button();
            this.btnWidthBeDivide = new System.Windows.Forms.Button();
            this.btnDeleteROI = new System.Windows.Forms.Button();
            this.tbHeight = new System.Windows.Forms.TrackBar();
            this.tbWidth = new System.Windows.Forms.TrackBar();
            this.tbY = new System.Windows.Forms.TrackBar();
            this.tbX = new System.Windows.Forms.TrackBar();
            this.btnAddROI = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbROIY = new System.Windows.Forms.Label();
            this.lbROIX = new System.Windows.Forms.Label();
            this.lbDevice = new System.Windows.Forms.Label();
            this.cbDevice = new System.Windows.Forms.ComboBox();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.imageBox40 = new Emgu.CV.UI.ImageBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.LBCoutInput = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.LBProductYield = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LBStationName = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.LBCountPass = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.LBCountFail = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.LBSN = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.imageBox20 = new Emgu.CV.UI.ImageBox();
            this.imageBox19 = new Emgu.CV.UI.ImageBox();
            this.imageBox18 = new Emgu.CV.UI.ImageBox();
            this.imageBox17 = new Emgu.CV.UI.ImageBox();
            this.imageBox16 = new Emgu.CV.UI.ImageBox();
            this.imageBox15 = new Emgu.CV.UI.ImageBox();
            this.imageBox14 = new Emgu.CV.UI.ImageBox();
            this.imageBox13 = new Emgu.CV.UI.ImageBox();
            this.imageBox12 = new Emgu.CV.UI.ImageBox();
            this.imageBox11 = new Emgu.CV.UI.ImageBox();
            this.imageBox10 = new Emgu.CV.UI.ImageBox();
            this.imageBox9 = new Emgu.CV.UI.ImageBox();
            this.imageBox8 = new Emgu.CV.UI.ImageBox();
            this.imageBox7 = new Emgu.CV.UI.ImageBox();
            this.imageBox6 = new Emgu.CV.UI.ImageBox();
            this.imageBox5 = new Emgu.CV.UI.ImageBox();
            this.imageBox4 = new Emgu.CV.UI.ImageBox();
            this.imageBox3 = new Emgu.CV.UI.ImageBox();
            this.imageBox2 = new Emgu.CV.UI.ImageBox();
            this.imageBox1 = new Emgu.CV.UI.ImageBox();
            this.lbPredictionResult2 = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.LBlian = new System.Windows.Forms.Label();
            this.LBxuan = new System.Windows.Forms.Label();
            this.lbLowerVisualPosition = new System.Windows.Forms.Label();
            this.lbDetectionLocation = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.lbLightCurtain = new System.Windows.Forms.Label();
            this.lbDoorSensor = new System.Windows.Forms.Label();
            this.lbEmergency = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.btnVisualLight = new System.Windows.Forms.Button();
            this.btnLowerVisualLight = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.btnRobotPass = new System.Windows.Forms.Button();
            this.btnxiaPASS = new System.Windows.Forms.Button();
            this.btnNG = new System.Windows.Forms.Button();
            this.btnPASS = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.SNtextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCameraScreenshot = new System.Windows.Forms.Button();
            this.btnReadBracode = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.imageBox91 = new Emgu.CV.UI.ImageBox();
            this.RtnCamera = new System.Windows.Forms.RadioButton();
            this.RtnScanningGun = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.BtnAOIReady = new System.Windows.Forms.Button();
            this.btnVisualCompletion = new System.Windows.Forms.Button();
            this.btnLowerVisualCompleted = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btn3ColorAlarm = new System.Windows.Forms.Button();
            this.btn3ColorRed = new System.Windows.Forms.Button();
            this.btn3ColorYellow = new System.Windows.Forms.Button();
            this.btn3ColorGreen = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsslStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslM2MResponse = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbLoad = new System.Windows.Forms.ToolStripButton();
            this.tsmiRun = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiCollectImageMode = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiNormalTest = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiCollectImagepoint = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiStartButton = new System.Windows.Forms.ToolStripMenuItem();
            this.tslProduct_Name = new System.Windows.Forms.ToolStripLabel();
            this.tsLanguage = new System.Windows.Forms.ToolStripMenuItem();
            this.tsChinese = new System.Windows.Forms.ToolStripMenuItem();
            this.tsEnglish = new System.Windows.Forms.ToolStripMenuItem();
            this.tsVistnamese = new System.Windows.Forms.ToolStripMenuItem();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.UItimer = new System.Windows.Forms.Timer(this.components);
            this.tbIO = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tpSetting = new System.Windows.Forms.TabPage();
            this.tbPTest = new System.Windows.Forms.TabPage();
            this.tbPSelectModel = new System.Windows.Forms.TabControl();
            this.tpRobot = new System.Windows.Forms.TabPage();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.imageBox101 = new Emgu.CV.UI.ImageBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.CbMotionType = new System.Windows.Forms.ComboBox();
            this.CbPointName = new System.Windows.Forms.ComboBox();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.button27 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.GrpCurrentPosition = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.numericUpDown13 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown14 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown15 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown16 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown17 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown21 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown20 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown19 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown18 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.button34 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.GrpPositionMove = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.numericUpDown11 = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.numericUpDown12 = new System.Windows.Forms.NumericUpDown();
            this.label29 = new System.Windows.Forms.Label();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.numericUpDown27 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.label34 = new System.Windows.Forms.Label();
            this.numericUpDown26 = new System.Windows.Forms.NumericUpDown();
            this.label35 = new System.Windows.Forms.Label();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown25 = new System.Windows.Forms.NumericUpDown();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.button37 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.TBXIndex = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.imageBox21 = new Emgu.CV.UI.ImageBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox91)).BeginInit();
            this.groupBox17.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tbIO.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tpSetting.SuspendLayout();
            this.tbPTest.SuspendLayout();
            this.tbPSelectModel.SuspendLayout();
            this.tpRobot.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox101)).BeginInit();
            this.groupBox21.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.GrpCurrentPosition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).BeginInit();
            this.groupBox25.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.GrpPositionMove.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown25)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox21)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer5
            // 
            resources.ApplyResources(this.splitContainer5, "splitContainer5");
            this.splitContainer5.Name = "splitContainer5";
            // 
            // splitContainer5.Panel1
            // 
            resources.ApplyResources(this.splitContainer5.Panel1, "splitContainer5.Panel1");
            this.splitContainer5.Panel1.Controls.Add(this.TBIndex);
            this.splitContainer5.Panel1.Controls.Add(this.label8);
            this.splitContainer5.Panel1.Controls.Add(this.TBSerial);
            this.splitContainer5.Panel1.Controls.Add(this.label7);
            this.splitContainer5.Panel1.Controls.Add(this.comboBox1);
            this.splitContainer5.Panel1.Controls.Add(this.label1);
            this.splitContainer5.Panel1.Controls.Add(this.groupBox2);
            this.splitContainer5.Panel1.Controls.Add(this.lbDevice);
            this.splitContainer5.Panel1.Controls.Add(this.cbDevice);
            // 
            // splitContainer5.Panel2
            // 
            resources.ApplyResources(this.splitContainer5.Panel2, "splitContainer5.Panel2");
            this.splitContainer5.Panel2.Controls.Add(this.splitContainer6);
            // 
            // TBIndex
            // 
            resources.ApplyResources(this.TBIndex, "TBIndex");
            this.TBIndex.Name = "TBIndex";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // TBSerial
            // 
            resources.ApplyResources(this.TBSerial, "TBSerial");
            this.TBSerial.Name = "TBSerial";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // comboBox1
            // 
            resources.ApplyResources(this.comboBox1, "comboBox1");
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Name = "comboBox1";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // groupBox2
            // 
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Controls.Add(this.btnHeightBeDivide);
            this.groupBox2.Controls.Add(this.btnSaveROI);
            this.groupBox2.Controls.Add(this.btnWidthBeDivide);
            this.groupBox2.Controls.Add(this.btnDeleteROI);
            this.groupBox2.Controls.Add(this.tbHeight);
            this.groupBox2.Controls.Add(this.tbWidth);
            this.groupBox2.Controls.Add(this.tbY);
            this.groupBox2.Controls.Add(this.tbX);
            this.groupBox2.Controls.Add(this.btnAddROI);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.lbROIY);
            this.groupBox2.Controls.Add(this.lbROIX);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // btnHeightBeDivide
            // 
            resources.ApplyResources(this.btnHeightBeDivide, "btnHeightBeDivide");
            this.btnHeightBeDivide.Name = "btnHeightBeDivide";
            this.btnHeightBeDivide.UseVisualStyleBackColor = true;
            this.btnHeightBeDivide.Click += new System.EventHandler(this.btnDenominator_Click);
            // 
            // btnSaveROI
            // 
            resources.ApplyResources(this.btnSaveROI, "btnSaveROI");
            this.btnSaveROI.Name = "btnSaveROI";
            this.btnSaveROI.UseVisualStyleBackColor = true;
            this.btnSaveROI.Click += new System.EventHandler(this.btnSaveROI_Click);
            // 
            // btnWidthBeDivide
            // 
            resources.ApplyResources(this.btnWidthBeDivide, "btnWidthBeDivide");
            this.btnWidthBeDivide.Name = "btnWidthBeDivide";
            this.btnWidthBeDivide.UseVisualStyleBackColor = true;
            this.btnWidthBeDivide.Click += new System.EventHandler(this.btnDenominator_Click);
            // 
            // btnDeleteROI
            // 
            resources.ApplyResources(this.btnDeleteROI, "btnDeleteROI");
            this.btnDeleteROI.Name = "btnDeleteROI";
            this.btnDeleteROI.UseVisualStyleBackColor = true;
            this.btnDeleteROI.Click += new System.EventHandler(this.btnDeleteROI_Click);
            // 
            // tbHeight
            // 
            resources.ApplyResources(this.tbHeight, "tbHeight");
            this.tbHeight.Maximum = 255;
            this.tbHeight.Name = "tbHeight";
            this.tbHeight.TickStyle = System.Windows.Forms.TickStyle.None;
            this.tbHeight.Scroll += new System.EventHandler(this.ROI_Scroll);
            // 
            // tbWidth
            // 
            resources.ApplyResources(this.tbWidth, "tbWidth");
            this.tbWidth.Maximum = 255;
            this.tbWidth.Name = "tbWidth";
            this.tbWidth.TickStyle = System.Windows.Forms.TickStyle.None;
            this.tbWidth.Scroll += new System.EventHandler(this.ROI_Scroll);
            // 
            // tbY
            // 
            resources.ApplyResources(this.tbY, "tbY");
            this.tbY.Maximum = 255;
            this.tbY.Name = "tbY";
            this.tbY.TickStyle = System.Windows.Forms.TickStyle.None;
            this.tbY.Scroll += new System.EventHandler(this.ROI_Scroll);
            // 
            // tbX
            // 
            resources.ApplyResources(this.tbX, "tbX");
            this.tbX.Maximum = 255;
            this.tbX.Name = "tbX";
            this.tbX.TickStyle = System.Windows.Forms.TickStyle.None;
            this.tbX.Scroll += new System.EventHandler(this.ROI_Scroll);
            // 
            // btnAddROI
            // 
            resources.ApplyResources(this.btnAddROI, "btnAddROI");
            this.btnAddROI.Name = "btnAddROI";
            this.btnAddROI.UseVisualStyleBackColor = true;
            this.btnAddROI.Click += new System.EventHandler(this.btnAddROI_Click);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // lbROIY
            // 
            resources.ApplyResources(this.lbROIY, "lbROIY");
            this.lbROIY.Name = "lbROIY";
            // 
            // lbROIX
            // 
            resources.ApplyResources(this.lbROIX, "lbROIX");
            this.lbROIX.Name = "lbROIX";
            // 
            // lbDevice
            // 
            resources.ApplyResources(this.lbDevice, "lbDevice");
            this.lbDevice.Name = "lbDevice";
            // 
            // cbDevice
            // 
            resources.ApplyResources(this.cbDevice, "cbDevice");
            this.cbDevice.FormattingEnabled = true;
            this.cbDevice.Name = "cbDevice";
            this.cbDevice.SelectedIndexChanged += new System.EventHandler(this.cbDevice_SelectedIndexChanged);
            // 
            // splitContainer6
            // 
            resources.ApplyResources(this.splitContainer6, "splitContainer6");
            this.splitContainer6.Name = "splitContainer6";
            // 
            // splitContainer6.Panel1
            // 
            resources.ApplyResources(this.splitContainer6.Panel1, "splitContainer6.Panel1");
            this.splitContainer6.Panel1.Controls.Add(this.imageBox40);
            // 
            // splitContainer6.Panel2
            // 
            resources.ApplyResources(this.splitContainer6.Panel2, "splitContainer6.Panel2");
            this.splitContainer6.Panel2.Controls.Add(this.dataGridView1);
            // 
            // imageBox40
            // 
            resources.ApplyResources(this.imageBox40, "imageBox40");
            this.imageBox40.Name = "imageBox40";
            this.imageBox40.TabStop = false;
            // 
            // dataGridView1
            // 
            resources.ApplyResources(this.dataGridView1, "dataGridView1");
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 31;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dataGridView1_DataBindingComplete);
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // splitContainer3
            // 
            resources.ApplyResources(this.splitContainer3, "splitContainer3");
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            resources.ApplyResources(this.splitContainer3.Panel1, "splitContainer3.Panel1");
            this.splitContainer3.Panel1.Controls.Add(this.splitContainer1);
            // 
            // splitContainer3.Panel2
            // 
            resources.ApplyResources(this.splitContainer3.Panel2, "splitContainer3.Panel2");
            this.splitContainer3.Panel2.Controls.Add(this.lbPredictionResult2);
            // 
            // splitContainer1
            // 
            resources.ApplyResources(this.splitContainer1, "splitContainer1");
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            resources.ApplyResources(this.splitContainer1.Panel1, "splitContainer1.Panel1");
            this.splitContainer1.Panel1.Controls.Add(this.tableLayoutPanel3);
            // 
            // splitContainer1.Panel2
            // 
            resources.ApplyResources(this.splitContainer1.Panel2, "splitContainer1.Panel2");
            this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel1);
            // 
            // tableLayoutPanel3
            // 
            resources.ApplyResources(this.tableLayoutPanel3, "tableLayoutPanel3");
            this.tableLayoutPanel3.Controls.Add(this.groupBox3, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.groupBox6, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.groupBox4, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.groupBox5, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.groupBox7, 1, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            // 
            // groupBox3
            // 
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Controls.Add(this.LBCoutInput);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // LBCoutInput
            // 
            resources.ApplyResources(this.LBCoutInput, "LBCoutInput");
            this.LBCoutInput.BackColor = System.Drawing.Color.White;
            this.LBCoutInput.Name = "LBCoutInput";
            // 
            // groupBox6
            // 
            resources.ApplyResources(this.groupBox6, "groupBox6");
            this.groupBox6.Controls.Add(this.LBProductYield);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.TabStop = false;
            // 
            // LBProductYield
            // 
            resources.ApplyResources(this.LBProductYield, "LBProductYield");
            this.LBProductYield.BackColor = System.Drawing.Color.White;
            this.LBProductYield.Name = "LBProductYield";
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this.LBStationName);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // LBStationName
            // 
            resources.ApplyResources(this.LBStationName, "LBStationName");
            this.LBStationName.BackColor = System.Drawing.Color.White;
            this.LBStationName.Name = "LBStationName";
            // 
            // groupBox4
            // 
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.Controls.Add(this.LBCountPass);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.TabStop = false;
            // 
            // LBCountPass
            // 
            resources.ApplyResources(this.LBCountPass, "LBCountPass");
            this.LBCountPass.BackColor = System.Drawing.Color.White;
            this.LBCountPass.Name = "LBCountPass";
            // 
            // groupBox5
            // 
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Controls.Add(this.LBCountFail);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.TabStop = false;
            // 
            // LBCountFail
            // 
            resources.ApplyResources(this.LBCountFail, "LBCountFail");
            this.LBCountFail.BackColor = System.Drawing.Color.White;
            this.LBCountFail.Name = "LBCountFail";
            // 
            // groupBox7
            // 
            resources.ApplyResources(this.groupBox7, "groupBox7");
            this.groupBox7.Controls.Add(this.LBSN);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.TabStop = false;
            // 
            // LBSN
            // 
            resources.ApplyResources(this.LBSN, "LBSN");
            this.LBSN.BackColor = System.Drawing.Color.White;
            this.LBSN.Name = "LBSN";
            // 
            // tableLayoutPanel1
            // 
            resources.ApplyResources(this.tableLayoutPanel1, "tableLayoutPanel1");
            this.tableLayoutPanel1.Controls.Add(this.imageBox20, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.imageBox19, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.imageBox18, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.imageBox17, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.imageBox16, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.imageBox15, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.imageBox14, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.imageBox13, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.imageBox12, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.imageBox11, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.imageBox10, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.imageBox9, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.imageBox8, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.imageBox7, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.imageBox6, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.imageBox5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.imageBox4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.imageBox3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.imageBox2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.imageBox1, 0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            // 
            // imageBox20
            // 
            resources.ApplyResources(this.imageBox20, "imageBox20");
            this.imageBox20.Name = "imageBox20";
            this.imageBox20.TabStop = false;
            // 
            // imageBox19
            // 
            resources.ApplyResources(this.imageBox19, "imageBox19");
            this.imageBox19.Name = "imageBox19";
            this.imageBox19.TabStop = false;
            // 
            // imageBox18
            // 
            resources.ApplyResources(this.imageBox18, "imageBox18");
            this.imageBox18.Name = "imageBox18";
            this.imageBox18.TabStop = false;
            // 
            // imageBox17
            // 
            resources.ApplyResources(this.imageBox17, "imageBox17");
            this.imageBox17.Name = "imageBox17";
            this.imageBox17.TabStop = false;
            // 
            // imageBox16
            // 
            resources.ApplyResources(this.imageBox16, "imageBox16");
            this.imageBox16.Name = "imageBox16";
            this.imageBox16.TabStop = false;
            // 
            // imageBox15
            // 
            resources.ApplyResources(this.imageBox15, "imageBox15");
            this.imageBox15.Name = "imageBox15";
            this.imageBox15.TabStop = false;
            // 
            // imageBox14
            // 
            resources.ApplyResources(this.imageBox14, "imageBox14");
            this.imageBox14.Name = "imageBox14";
            this.imageBox14.TabStop = false;
            // 
            // imageBox13
            // 
            resources.ApplyResources(this.imageBox13, "imageBox13");
            this.imageBox13.Name = "imageBox13";
            this.imageBox13.TabStop = false;
            // 
            // imageBox12
            // 
            resources.ApplyResources(this.imageBox12, "imageBox12");
            this.imageBox12.Name = "imageBox12";
            this.imageBox12.TabStop = false;
            // 
            // imageBox11
            // 
            resources.ApplyResources(this.imageBox11, "imageBox11");
            this.imageBox11.Name = "imageBox11";
            this.imageBox11.TabStop = false;
            // 
            // imageBox10
            // 
            resources.ApplyResources(this.imageBox10, "imageBox10");
            this.imageBox10.Name = "imageBox10";
            this.imageBox10.TabStop = false;
            // 
            // imageBox9
            // 
            resources.ApplyResources(this.imageBox9, "imageBox9");
            this.imageBox9.Name = "imageBox9";
            this.imageBox9.TabStop = false;
            // 
            // imageBox8
            // 
            resources.ApplyResources(this.imageBox8, "imageBox8");
            this.imageBox8.Name = "imageBox8";
            this.imageBox8.TabStop = false;
            // 
            // imageBox7
            // 
            resources.ApplyResources(this.imageBox7, "imageBox7");
            this.imageBox7.Name = "imageBox7";
            this.imageBox7.TabStop = false;
            // 
            // imageBox6
            // 
            resources.ApplyResources(this.imageBox6, "imageBox6");
            this.imageBox6.Name = "imageBox6";
            this.imageBox6.TabStop = false;
            // 
            // imageBox5
            // 
            resources.ApplyResources(this.imageBox5, "imageBox5");
            this.imageBox5.Name = "imageBox5";
            this.imageBox5.TabStop = false;
            // 
            // imageBox4
            // 
            resources.ApplyResources(this.imageBox4, "imageBox4");
            this.imageBox4.Name = "imageBox4";
            this.imageBox4.TabStop = false;
            // 
            // imageBox3
            // 
            resources.ApplyResources(this.imageBox3, "imageBox3");
            this.imageBox3.Name = "imageBox3";
            this.imageBox3.TabStop = false;
            // 
            // imageBox2
            // 
            resources.ApplyResources(this.imageBox2, "imageBox2");
            this.imageBox2.Name = "imageBox2";
            this.imageBox2.TabStop = false;
            // 
            // imageBox1
            // 
            resources.ApplyResources(this.imageBox1, "imageBox1");
            this.imageBox1.Name = "imageBox1";
            this.imageBox1.TabStop = false;
            // 
            // lbPredictionResult2
            // 
            resources.ApplyResources(this.lbPredictionResult2, "lbPredictionResult2");
            this.lbPredictionResult2.BackColor = System.Drawing.Color.Blue;
            this.lbPredictionResult2.ForeColor = System.Drawing.Color.White;
            this.lbPredictionResult2.Name = "lbPredictionResult2";
            // 
            // splitContainer2
            // 
            resources.ApplyResources(this.splitContainer2, "splitContainer2");
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            resources.ApplyResources(this.splitContainer2.Panel1, "splitContainer2.Panel1");
            this.splitContainer2.Panel1.Controls.Add(this.groupBox12);
            // 
            // splitContainer2.Panel2
            // 
            resources.ApplyResources(this.splitContainer2.Panel2, "splitContainer2.Panel2");
            this.splitContainer2.Panel2.Controls.Add(this.groupBox10);
            // 
            // groupBox12
            // 
            resources.ApplyResources(this.groupBox12, "groupBox12");
            this.groupBox12.Controls.Add(this.groupBox15);
            this.groupBox12.Controls.Add(this.groupBox14);
            this.groupBox12.Controls.Add(this.groupBox13);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.TabStop = false;
            // 
            // groupBox15
            // 
            resources.ApplyResources(this.groupBox15, "groupBox15");
            this.groupBox15.Controls.Add(this.LBlian);
            this.groupBox15.Controls.Add(this.LBxuan);
            this.groupBox15.Controls.Add(this.lbLowerVisualPosition);
            this.groupBox15.Controls.Add(this.lbDetectionLocation);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.TabStop = false;
            // 
            // LBlian
            // 
            resources.ApplyResources(this.LBlian, "LBlian");
            this.LBlian.BackColor = System.Drawing.Color.Gray;
            this.LBlian.ForeColor = System.Drawing.Color.White;
            this.LBlian.Name = "LBlian";
            // 
            // LBxuan
            // 
            resources.ApplyResources(this.LBxuan, "LBxuan");
            this.LBxuan.BackColor = System.Drawing.Color.Gray;
            this.LBxuan.ForeColor = System.Drawing.Color.White;
            this.LBxuan.Name = "LBxuan";
            // 
            // lbLowerVisualPosition
            // 
            resources.ApplyResources(this.lbLowerVisualPosition, "lbLowerVisualPosition");
            this.lbLowerVisualPosition.BackColor = System.Drawing.Color.Gray;
            this.lbLowerVisualPosition.ForeColor = System.Drawing.Color.White;
            this.lbLowerVisualPosition.Name = "lbLowerVisualPosition";
            // 
            // lbDetectionLocation
            // 
            resources.ApplyResources(this.lbDetectionLocation, "lbDetectionLocation");
            this.lbDetectionLocation.BackColor = System.Drawing.Color.Gray;
            this.lbDetectionLocation.ForeColor = System.Drawing.Color.White;
            this.lbDetectionLocation.Name = "lbDetectionLocation";
            // 
            // groupBox14
            // 
            resources.ApplyResources(this.groupBox14, "groupBox14");
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.TabStop = false;
            // 
            // groupBox13
            // 
            resources.ApplyResources(this.groupBox13, "groupBox13");
            this.groupBox13.Controls.Add(this.lbLightCurtain);
            this.groupBox13.Controls.Add(this.lbDoorSensor);
            this.groupBox13.Controls.Add(this.lbEmergency);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.TabStop = false;
            // 
            // lbLightCurtain
            // 
            resources.ApplyResources(this.lbLightCurtain, "lbLightCurtain");
            this.lbLightCurtain.BackColor = System.Drawing.Color.Gray;
            this.lbLightCurtain.ForeColor = System.Drawing.Color.White;
            this.lbLightCurtain.Name = "lbLightCurtain";
            // 
            // lbDoorSensor
            // 
            resources.ApplyResources(this.lbDoorSensor, "lbDoorSensor");
            this.lbDoorSensor.BackColor = System.Drawing.Color.Gray;
            this.lbDoorSensor.ForeColor = System.Drawing.Color.White;
            this.lbDoorSensor.Name = "lbDoorSensor";
            // 
            // lbEmergency
            // 
            resources.ApplyResources(this.lbEmergency, "lbEmergency");
            this.lbEmergency.BackColor = System.Drawing.Color.Gray;
            this.lbEmergency.ForeColor = System.Drawing.Color.White;
            this.lbEmergency.Name = "lbEmergency";
            // 
            // groupBox10
            // 
            resources.ApplyResources(this.groupBox10, "groupBox10");
            this.groupBox10.Controls.Add(this.groupBox19);
            this.groupBox10.Controls.Add(this.groupBox18);
            this.groupBox10.Controls.Add(this.groupBox8);
            this.groupBox10.Controls.Add(this.groupBox17);
            this.groupBox10.Controls.Add(this.groupBox11);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.TabStop = false;
            // 
            // groupBox19
            // 
            resources.ApplyResources(this.groupBox19, "groupBox19");
            this.groupBox19.Controls.Add(this.btnVisualLight);
            this.groupBox19.Controls.Add(this.btnLowerVisualLight);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.TabStop = false;
            // 
            // btnVisualLight
            // 
            resources.ApplyResources(this.btnVisualLight, "btnVisualLight");
            this.btnVisualLight.Name = "btnVisualLight";
            this.btnVisualLight.UseVisualStyleBackColor = true;
            this.btnVisualLight.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // btnLowerVisualLight
            // 
            resources.ApplyResources(this.btnLowerVisualLight, "btnLowerVisualLight");
            this.btnLowerVisualLight.Name = "btnLowerVisualLight";
            this.btnLowerVisualLight.UseVisualStyleBackColor = true;
            this.btnLowerVisualLight.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // groupBox18
            // 
            resources.ApplyResources(this.groupBox18, "groupBox18");
            this.groupBox18.Controls.Add(this.btnRobotPass);
            this.groupBox18.Controls.Add(this.btnxiaPASS);
            this.groupBox18.Controls.Add(this.btnNG);
            this.groupBox18.Controls.Add(this.btnPASS);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.TabStop = false;
            // 
            // btnRobotPass
            // 
            resources.ApplyResources(this.btnRobotPass, "btnRobotPass");
            this.btnRobotPass.Name = "btnRobotPass";
            this.btnRobotPass.UseVisualStyleBackColor = true;
            this.btnRobotPass.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // btnxiaPASS
            // 
            resources.ApplyResources(this.btnxiaPASS, "btnxiaPASS");
            this.btnxiaPASS.Name = "btnxiaPASS";
            this.btnxiaPASS.UseVisualStyleBackColor = true;
            this.btnxiaPASS.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // btnNG
            // 
            resources.ApplyResources(this.btnNG, "btnNG");
            this.btnNG.Name = "btnNG";
            this.btnNG.UseVisualStyleBackColor = true;
            this.btnNG.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // btnPASS
            // 
            resources.ApplyResources(this.btnPASS, "btnPASS");
            this.btnPASS.Name = "btnPASS";
            this.btnPASS.UseVisualStyleBackColor = true;
            this.btnPASS.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // groupBox8
            // 
            resources.ApplyResources(this.groupBox8, "groupBox8");
            this.groupBox8.Controls.Add(this.SNtextBox);
            this.groupBox8.Controls.Add(this.label5);
            this.groupBox8.Controls.Add(this.btnCameraScreenshot);
            this.groupBox8.Controls.Add(this.btnReadBracode);
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Controls.Add(this.RtnCamera);
            this.groupBox8.Controls.Add(this.RtnScanningGun);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.TabStop = false;
            // 
            // SNtextBox
            // 
            resources.ApplyResources(this.SNtextBox, "SNtextBox");
            this.SNtextBox.Name = "SNtextBox";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // btnCameraScreenshot
            // 
            resources.ApplyResources(this.btnCameraScreenshot, "btnCameraScreenshot");
            this.btnCameraScreenshot.Name = "btnCameraScreenshot";
            this.btnCameraScreenshot.UseVisualStyleBackColor = true;
            this.btnCameraScreenshot.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // btnReadBracode
            // 
            resources.ApplyResources(this.btnReadBracode, "btnReadBracode");
            this.btnReadBracode.Name = "btnReadBracode";
            this.btnReadBracode.UseVisualStyleBackColor = true;
            this.btnReadBracode.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // groupBox9
            // 
            resources.ApplyResources(this.groupBox9, "groupBox9");
            this.groupBox9.Controls.Add(this.imageBox91);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.TabStop = false;
            // 
            // imageBox91
            // 
            resources.ApplyResources(this.imageBox91, "imageBox91");
            this.imageBox91.Name = "imageBox91";
            this.imageBox91.TabStop = false;
            // 
            // RtnCamera
            // 
            resources.ApplyResources(this.RtnCamera, "RtnCamera");
            this.RtnCamera.Name = "RtnCamera";
            this.RtnCamera.TabStop = true;
            this.RtnCamera.UseVisualStyleBackColor = true;
            // 
            // RtnScanningGun
            // 
            resources.ApplyResources(this.RtnScanningGun, "RtnScanningGun");
            this.RtnScanningGun.Name = "RtnScanningGun";
            this.RtnScanningGun.TabStop = true;
            this.RtnScanningGun.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            resources.ApplyResources(this.groupBox17, "groupBox17");
            this.groupBox17.Controls.Add(this.BtnAOIReady);
            this.groupBox17.Controls.Add(this.btnVisualCompletion);
            this.groupBox17.Controls.Add(this.btnLowerVisualCompleted);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.TabStop = false;
            // 
            // BtnAOIReady
            // 
            resources.ApplyResources(this.BtnAOIReady, "BtnAOIReady");
            this.BtnAOIReady.Name = "BtnAOIReady";
            this.BtnAOIReady.UseVisualStyleBackColor = true;
            this.BtnAOIReady.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // btnVisualCompletion
            // 
            resources.ApplyResources(this.btnVisualCompletion, "btnVisualCompletion");
            this.btnVisualCompletion.Name = "btnVisualCompletion";
            this.btnVisualCompletion.UseVisualStyleBackColor = true;
            this.btnVisualCompletion.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // btnLowerVisualCompleted
            // 
            resources.ApplyResources(this.btnLowerVisualCompleted, "btnLowerVisualCompleted");
            this.btnLowerVisualCompleted.Name = "btnLowerVisualCompleted";
            this.btnLowerVisualCompleted.UseVisualStyleBackColor = true;
            this.btnLowerVisualCompleted.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // groupBox11
            // 
            resources.ApplyResources(this.groupBox11, "groupBox11");
            this.groupBox11.Controls.Add(this.btn3ColorAlarm);
            this.groupBox11.Controls.Add(this.btn3ColorRed);
            this.groupBox11.Controls.Add(this.btn3ColorYellow);
            this.groupBox11.Controls.Add(this.btn3ColorGreen);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.TabStop = false;
            // 
            // btn3ColorAlarm
            // 
            resources.ApplyResources(this.btn3ColorAlarm, "btn3ColorAlarm");
            this.btn3ColorAlarm.Name = "btn3ColorAlarm";
            this.btn3ColorAlarm.UseVisualStyleBackColor = true;
            this.btn3ColorAlarm.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // btn3ColorRed
            // 
            resources.ApplyResources(this.btn3ColorRed, "btn3ColorRed");
            this.btn3ColorRed.Name = "btn3ColorRed";
            this.btn3ColorRed.UseVisualStyleBackColor = true;
            this.btn3ColorRed.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // btn3ColorYellow
            // 
            resources.ApplyResources(this.btn3ColorYellow, "btn3ColorYellow");
            this.btn3ColorYellow.Name = "btn3ColorYellow";
            this.btn3ColorYellow.UseVisualStyleBackColor = true;
            this.btn3ColorYellow.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // btn3ColorGreen
            // 
            resources.ApplyResources(this.btn3ColorGreen, "btn3ColorGreen");
            this.btn3ColorGreen.Name = "btn3ColorGreen";
            this.btn3ColorGreen.UseVisualStyleBackColor = true;
            this.btn3ColorGreen.Click += new System.EventHandler(this.IOButton_Click);
            // 
            // statusStrip1
            // 
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslStatus,
            this.tsslM2MResponse});
            this.statusStrip1.Name = "statusStrip1";
            // 
            // tsslStatus
            // 
            resources.ApplyResources(this.tsslStatus, "tsslStatus");
            this.tsslStatus.ForeColor = System.Drawing.Color.Blue;
            this.tsslStatus.Name = "tsslStatus";
            // 
            // tsslM2MResponse
            // 
            resources.ApplyResources(this.tsslM2MResponse, "tsslM2MResponse");
            this.tsslM2MResponse.Name = "tsslM2MResponse";
            // 
            // toolStrip1
            // 
            resources.ApplyResources(this.toolStrip1, "toolStrip1");
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbLoad,
            this.tsmiRun,
            this.tsmiStartButton,
            this.tslProduct_Name,
            this.tsLanguage});
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            // 
            // tsbLoad
            // 
            resources.ApplyResources(this.tsbLoad, "tsbLoad");
            this.tsbLoad.Name = "tsbLoad";
            this.tsbLoad.Click += new System.EventHandler(this.tsbLoad_Click);
            // 
            // tsmiRun
            // 
            resources.ApplyResources(this.tsmiRun, "tsmiRun");
            this.tsmiRun.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiCollectImageMode,
            this.tsmiNormalTest,
            this.tsmiCollectImagepoint});
            this.tsmiRun.Name = "tsmiRun";
            // 
            // tsmiCollectImageMode
            // 
            resources.ApplyResources(this.tsmiCollectImageMode, "tsmiCollectImageMode");
            this.tsmiCollectImageMode.Name = "tsmiCollectImageMode";
            this.tsmiCollectImageMode.Click += new System.EventHandler(this.RunMode_Click);
            // 
            // tsmiNormalTest
            // 
            resources.ApplyResources(this.tsmiNormalTest, "tsmiNormalTest");
            this.tsmiNormalTest.Name = "tsmiNormalTest";
            this.tsmiNormalTest.Click += new System.EventHandler(this.RunMode_Click);
            // 
            // tsmiCollectImagepoint
            // 
            resources.ApplyResources(this.tsmiCollectImagepoint, "tsmiCollectImagepoint");
            this.tsmiCollectImagepoint.Name = "tsmiCollectImagepoint";
            this.tsmiCollectImagepoint.Click += new System.EventHandler(this.RunMode_Click);
            // 
            // tsmiStartButton
            // 
            resources.ApplyResources(this.tsmiStartButton, "tsmiStartButton");
            this.tsmiStartButton.Name = "tsmiStartButton";
            this.tsmiStartButton.Click += new System.EventHandler(this.btnPrediction_Click);
            // 
            // tslProduct_Name
            // 
            resources.ApplyResources(this.tslProduct_Name, "tslProduct_Name");
            this.tslProduct_Name.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tslProduct_Name.Name = "tslProduct_Name";
            this.tslProduct_Name.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            // 
            // tsLanguage
            // 
            resources.ApplyResources(this.tsLanguage, "tsLanguage");
            this.tsLanguage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsChinese,
            this.tsEnglish,
            this.tsVistnamese});
            this.tsLanguage.Image = global::ImageCapture.Properties.Resources.mmexport1717481159439;
            this.tsLanguage.Name = "tsLanguage";
            // 
            // tsChinese
            // 
            resources.ApplyResources(this.tsChinese, "tsChinese");
            this.tsChinese.Name = "tsChinese";
            this.tsChinese.Click += new System.EventHandler(this.tsChinese_Click);
            // 
            // tsEnglish
            // 
            resources.ApplyResources(this.tsEnglish, "tsEnglish");
            this.tsEnglish.Name = "tsEnglish";
            this.tsEnglish.Click += new System.EventHandler(this.tsEnglish_Click);
            // 
            // tsVistnamese
            // 
            resources.ApplyResources(this.tsVistnamese, "tsVistnamese");
            this.tsVistnamese.Name = "tsVistnamese";
            this.tsVistnamese.Click += new System.EventHandler(this.tsVistnamese_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "understanding.png");
            this.imageList1.Images.SetKeyName(1, "setting_tools.png");
            this.imageList1.Images.SetKeyName(2, "rainbow.png");
            this.imageList1.Images.SetKeyName(3, "camera.png");
            // 
            // tabPage1
            // 
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tbIO
            // 
            resources.ApplyResources(this.tbIO, "tbIO");
            this.tbIO.Controls.Add(this.panel2);
            this.tbIO.Name = "tbIO";
            this.tbIO.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Controls.Add(this.splitContainer2);
            this.panel2.Name = "panel2";
            // 
            // tpSetting
            // 
            resources.ApplyResources(this.tpSetting, "tpSetting");
            this.tpSetting.Controls.Add(this.splitContainer5);
            this.tpSetting.Name = "tpSetting";
            this.tpSetting.UseVisualStyleBackColor = true;
            // 
            // tbPTest
            // 
            resources.ApplyResources(this.tbPTest, "tbPTest");
            this.tbPTest.Controls.Add(this.splitContainer3);
            this.tbPTest.Name = "tbPTest";
            this.tbPTest.UseVisualStyleBackColor = true;
            // 
            // tbPSelectModel
            // 
            resources.ApplyResources(this.tbPSelectModel, "tbPSelectModel");
            this.tbPSelectModel.Controls.Add(this.tbPTest);
            this.tbPSelectModel.Controls.Add(this.tpSetting);
            this.tbPSelectModel.Controls.Add(this.tbIO);
            this.tbPSelectModel.Controls.Add(this.tpRobot);
            this.tbPSelectModel.Controls.Add(this.tabPage3);
            this.tbPSelectModel.ImageList = this.imageList1;
            this.tbPSelectModel.Name = "tbPSelectModel";
            this.tbPSelectModel.SelectedIndex = 0;
            this.tbPSelectModel.SelectedIndexChanged += new System.EventHandler(this.tbPSelectModel_SelectedIndexChanged);
            this.tbPSelectModel.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tbPSelectModel_Selecting);
            // 
            // tpRobot
            // 
            resources.ApplyResources(this.tpRobot, "tpRobot");
            this.tpRobot.Controls.Add(this.groupBox20);
            this.tpRobot.Controls.Add(this.groupBox21);
            this.tpRobot.Controls.Add(this.groupBox22);
            this.tpRobot.Controls.Add(this.GrpCurrentPosition);
            this.tpRobot.Controls.Add(this.groupBox25);
            this.tpRobot.Controls.Add(this.button34);
            this.tpRobot.Controls.Add(this.button33);
            this.tpRobot.Controls.Add(this.button32);
            this.tpRobot.Controls.Add(this.button31);
            this.tpRobot.Controls.Add(this.button30);
            this.tpRobot.Controls.Add(this.button29);
            this.tpRobot.Controls.Add(this.tabControl2);
            this.tpRobot.Name = "tpRobot";
            this.tpRobot.UseVisualStyleBackColor = true;
            // 
            // groupBox20
            // 
            resources.ApplyResources(this.groupBox20, "groupBox20");
            this.groupBox20.Controls.Add(this.imageBox101);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.TabStop = false;
            // 
            // imageBox101
            // 
            resources.ApplyResources(this.imageBox101, "imageBox101");
            this.imageBox101.Name = "imageBox101";
            this.imageBox101.TabStop = false;
            // 
            // groupBox21
            // 
            resources.ApplyResources(this.groupBox21, "groupBox21");
            this.groupBox21.Controls.Add(this.radioButton6);
            this.groupBox21.Controls.Add(this.radioButton5);
            this.groupBox21.Controls.Add(this.radioButton4);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.TabStop = false;
            // 
            // radioButton6
            // 
            resources.ApplyResources(this.radioButton6, "radioButton6");
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Tag = "offsetMoveSpeed";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            resources.ApplyResources(this.radioButton5, "radioButton5");
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Tag = "offsetMoveSpeed";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            resources.ApplyResources(this.radioButton4, "radioButton4");
            this.radioButton4.Checked = true;
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.TabStop = true;
            this.radioButton4.Tag = "offsetMoveSpeed";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // groupBox22
            // 
            resources.ApplyResources(this.groupBox22, "groupBox22");
            this.groupBox22.Controls.Add(this.groupBox23);
            this.groupBox22.Controls.Add(this.CbMotionType);
            this.groupBox22.Controls.Add(this.CbPointName);
            this.groupBox22.Controls.Add(this.groupBox24);
            this.groupBox22.Controls.Add(this.label16);
            this.groupBox22.Controls.Add(this.label15);
            this.groupBox22.Controls.Add(this.button27);
            this.groupBox22.Controls.Add(this.button11);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.TabStop = false;
            // 
            // groupBox23
            // 
            resources.ApplyResources(this.groupBox23, "groupBox23");
            this.groupBox23.Controls.Add(this.radioButton10);
            this.groupBox23.Controls.Add(this.radioButton11);
            this.groupBox23.Controls.Add(this.radioButton12);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.TabStop = false;
            // 
            // radioButton10
            // 
            resources.ApplyResources(this.radioButton10, "radioButton10");
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Tag = "positionMoveSpeed";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            resources.ApplyResources(this.radioButton11, "radioButton11");
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Tag = "positionMoveSpeed";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            resources.ApplyResources(this.radioButton12, "radioButton12");
            this.radioButton12.Checked = true;
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.TabStop = true;
            this.radioButton12.Tag = "positionMoveSpeed";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // CbMotionType
            // 
            resources.ApplyResources(this.CbMotionType, "CbMotionType");
            this.CbMotionType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbMotionType.FormattingEnabled = true;
            this.CbMotionType.Items.AddRange(new object[] {
            resources.GetString("CbMotionType.Items"),
            resources.GetString("CbMotionType.Items1"),
            resources.GetString("CbMotionType.Items2")});
            this.CbMotionType.Name = "CbMotionType";
            // 
            // CbPointName
            // 
            resources.ApplyResources(this.CbPointName, "CbPointName");
            this.CbPointName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbPointName.FormattingEnabled = true;
            this.CbPointName.Name = "CbPointName";
            // 
            // groupBox24
            // 
            resources.ApplyResources(this.groupBox24, "groupBox24");
            this.groupBox24.Controls.Add(this.radioButton7);
            this.groupBox24.Controls.Add(this.radioButton13);
            this.groupBox24.Controls.Add(this.radioButton8);
            this.groupBox24.Controls.Add(this.radioButton9);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.TabStop = false;
            // 
            // radioButton7
            // 
            resources.ApplyResources(this.radioButton7, "radioButton7");
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Tag = "positionMoveZSafe";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton13
            // 
            resources.ApplyResources(this.radioButton13, "radioButton13");
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Tag = "positionMoveZSafe";
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            resources.ApplyResources(this.radioButton8, "radioButton8");
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Tag = "positionMoveZSafe";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            resources.ApplyResources(this.radioButton9, "radioButton9");
            this.radioButton9.Checked = true;
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.TabStop = true;
            this.radioButton9.Tag = "positionMoveZSafe";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // button27
            // 
            resources.ApplyResources(this.button27, "button27");
            this.button27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button27.Name = "button27";
            this.button27.TabStop = false;
            this.button27.Tag = "RobotPositionMove";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.RobotButtonClick);
            // 
            // button11
            // 
            resources.ApplyResources(this.button11, "button11");
            this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button11.Name = "button11";
            this.button11.TabStop = false;
            this.button11.Tag = "RobotSavePosition";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.RobotButtonClick);
            // 
            // GrpCurrentPosition
            // 
            resources.ApplyResources(this.GrpCurrentPosition, "GrpCurrentPosition");
            this.GrpCurrentPosition.Controls.Add(this.label19);
            this.GrpCurrentPosition.Controls.Add(this.label18);
            this.GrpCurrentPosition.Controls.Add(this.label17);
            this.GrpCurrentPosition.Controls.Add(this.label9);
            this.GrpCurrentPosition.Controls.Add(this.numericUpDown13);
            this.GrpCurrentPosition.Controls.Add(this.numericUpDown14);
            this.GrpCurrentPosition.Controls.Add(this.numericUpDown15);
            this.GrpCurrentPosition.Controls.Add(this.numericUpDown16);
            this.GrpCurrentPosition.Controls.Add(this.numericUpDown17);
            this.GrpCurrentPosition.Controls.Add(this.numericUpDown21);
            this.GrpCurrentPosition.Controls.Add(this.numericUpDown20);
            this.GrpCurrentPosition.Controls.Add(this.numericUpDown19);
            this.GrpCurrentPosition.Controls.Add(this.numericUpDown18);
            this.GrpCurrentPosition.Controls.Add(this.label10);
            this.GrpCurrentPosition.Controls.Add(this.label11);
            this.GrpCurrentPosition.Controls.Add(this.label12);
            this.GrpCurrentPosition.Controls.Add(this.label13);
            this.GrpCurrentPosition.Controls.Add(this.label14);
            this.GrpCurrentPosition.Name = "GrpCurrentPosition";
            this.GrpCurrentPosition.TabStop = false;
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // numericUpDown13
            // 
            resources.ApplyResources(this.numericUpDown13, "numericUpDown13");
            this.numericUpDown13.DecimalPlaces = 3;
            this.numericUpDown13.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown13.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown13.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown13.Name = "numericUpDown13";
            this.numericUpDown13.TabStop = false;
            this.numericUpDown13.Tag = "w";
            // 
            // numericUpDown14
            // 
            resources.ApplyResources(this.numericUpDown14, "numericUpDown14");
            this.numericUpDown14.DecimalPlaces = 3;
            this.numericUpDown14.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown14.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown14.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown14.Name = "numericUpDown14";
            this.numericUpDown14.TabStop = false;
            this.numericUpDown14.Tag = "v";
            // 
            // numericUpDown15
            // 
            resources.ApplyResources(this.numericUpDown15, "numericUpDown15");
            this.numericUpDown15.DecimalPlaces = 3;
            this.numericUpDown15.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown15.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown15.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown15.Name = "numericUpDown15";
            this.numericUpDown15.TabStop = false;
            this.numericUpDown15.Tag = "u";
            // 
            // numericUpDown16
            // 
            resources.ApplyResources(this.numericUpDown16, "numericUpDown16");
            this.numericUpDown16.DecimalPlaces = 3;
            this.numericUpDown16.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown16.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown16.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown16.Name = "numericUpDown16";
            this.numericUpDown16.TabStop = false;
            this.numericUpDown16.Tag = "z";
            // 
            // numericUpDown17
            // 
            resources.ApplyResources(this.numericUpDown17, "numericUpDown17");
            this.numericUpDown17.DecimalPlaces = 3;
            this.numericUpDown17.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown17.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown17.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown17.Name = "numericUpDown17";
            this.numericUpDown17.TabStop = false;
            this.numericUpDown17.Tag = "y";
            // 
            // numericUpDown21
            // 
            resources.ApplyResources(this.numericUpDown21, "numericUpDown21");
            this.numericUpDown21.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown21.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown21.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown21.Name = "numericUpDown21";
            this.numericUpDown21.TabStop = false;
            this.numericUpDown21.Tag = "wr";
            // 
            // numericUpDown20
            // 
            resources.ApplyResources(this.numericUpDown20, "numericUpDown20");
            this.numericUpDown20.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown20.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown20.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown20.Name = "numericUpDown20";
            this.numericUpDown20.TabStop = false;
            this.numericUpDown20.Tag = "el";
            // 
            // numericUpDown19
            // 
            resources.ApplyResources(this.numericUpDown19, "numericUpDown19");
            this.numericUpDown19.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown19.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown19.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown19.Name = "numericUpDown19";
            this.numericUpDown19.TabStop = false;
            this.numericUpDown19.Tag = "ha";
            // 
            // numericUpDown18
            // 
            resources.ApplyResources(this.numericUpDown18, "numericUpDown18");
            this.numericUpDown18.DecimalPlaces = 3;
            this.numericUpDown18.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown18.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown18.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown18.Name = "numericUpDown18";
            this.numericUpDown18.TabStop = false;
            this.numericUpDown18.Tag = "x";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // groupBox25
            // 
            resources.ApplyResources(this.groupBox25, "groupBox25");
            this.groupBox25.Controls.Add(this.radioButton3);
            this.groupBox25.Controls.Add(this.radioButton2);
            this.groupBox25.Controls.Add(this.radioButton1);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.TabStop = false;
            // 
            // radioButton3
            // 
            resources.ApplyResources(this.radioButton3, "radioButton3");
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Tag = "offsetMoveDistance";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            resources.ApplyResources(this.radioButton2, "radioButton2");
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Tag = "offsetMoveDistance";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            resources.ApplyResources(this.radioButton1, "radioButton1");
            this.radioButton1.Checked = true;
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.TabStop = true;
            this.radioButton1.Tag = "offsetMoveDistance";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            resources.ApplyResources(this.button34, "button34");
            this.button34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button34.Name = "button34";
            this.button34.TabStop = false;
            this.button34.Tag = "RobotVacOff";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            resources.ApplyResources(this.button33, "button33");
            this.button33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button33.Name = "button33";
            this.button33.TabStop = false;
            this.button33.Tag = "RobotVacOn";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            resources.ApplyResources(this.button32, "button32");
            this.button32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button32.Name = "button32";
            this.button32.TabStop = false;
            this.button32.Tag = "RobotReloadPosion";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            resources.ApplyResources(this.button31, "button31");
            this.button31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button31.Name = "button31";
            this.button31.TabStop = false;
            this.button31.Tag = "RobotRelink";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            resources.ApplyResources(this.button30, "button30");
            this.button30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button30.Name = "button30";
            this.button30.TabStop = false;
            this.button30.Tag = "RobotSLock";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            resources.ApplyResources(this.button29, "button29");
            this.button29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button29.Name = "button29";
            this.button29.TabStop = false;
            this.button29.Tag = "RobotSFree";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            resources.ApplyResources(this.tabControl2, "tabControl2");
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            // 
            // tabPage6
            // 
            resources.ApplyResources(this.tabPage6, "tabPage6");
            this.tabPage6.Controls.Add(this.button13);
            this.tabPage6.Controls.Add(this.button12);
            this.tabPage6.Controls.Add(this.button2);
            this.tabPage6.Controls.Add(this.button4);
            this.tabPage6.Controls.Add(this.button10);
            this.tabPage6.Controls.Add(this.button5);
            this.tabPage6.Controls.Add(this.button6);
            this.tabPage6.Controls.Add(this.button9);
            this.tabPage6.Controls.Add(this.button7);
            this.tabPage6.Controls.Add(this.button8);
            this.tabPage6.Controls.Add(this.button14);
            this.tabPage6.Controls.Add(this.button15);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            resources.ApplyResources(this.button13, "button13");
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button13.ForeColor = System.Drawing.Color.Blue;
            this.button13.Name = "button13";
            this.button13.TabStop = false;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button12
            // 
            resources.ApplyResources(this.button12, "button12");
            this.button12.BackColor = System.Drawing.Color.White;
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.ForeColor = System.Drawing.Color.Blue;
            this.button12.Name = "button12";
            this.button12.TabStop = false;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.ForeColor = System.Drawing.Color.Blue;
            this.button2.Name = "button2";
            this.button2.TabStop = false;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button4
            // 
            resources.ApplyResources(this.button4, "button4");
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.ForeColor = System.Drawing.Color.Blue;
            this.button4.Name = "button4";
            this.button4.TabStop = false;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button10
            // 
            resources.ApplyResources(this.button10, "button10");
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.ForeColor = System.Drawing.Color.Blue;
            this.button10.Name = "button10";
            this.button10.TabStop = false;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button5
            // 
            resources.ApplyResources(this.button5, "button5");
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.ForeColor = System.Drawing.Color.Blue;
            this.button5.Name = "button5";
            this.button5.TabStop = false;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button6
            // 
            resources.ApplyResources(this.button6, "button6");
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.ForeColor = System.Drawing.Color.Blue;
            this.button6.Name = "button6";
            this.button6.TabStop = false;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button9
            // 
            resources.ApplyResources(this.button9, "button9");
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.ForeColor = System.Drawing.Color.Blue;
            this.button9.Name = "button9";
            this.button9.TabStop = false;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button7
            // 
            resources.ApplyResources(this.button7, "button7");
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.ForeColor = System.Drawing.Color.Blue;
            this.button7.Name = "button7";
            this.button7.TabStop = false;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button8
            // 
            resources.ApplyResources(this.button8, "button8");
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.ForeColor = System.Drawing.Color.Blue;
            this.button8.Name = "button8";
            this.button8.TabStop = false;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button14
            // 
            resources.ApplyResources(this.button14, "button14");
            this.button14.BackColor = System.Drawing.Color.White;
            this.button14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button14.ForeColor = System.Drawing.Color.Blue;
            this.button14.Name = "button14";
            this.button14.TabStop = false;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // button15
            // 
            resources.ApplyResources(this.button15, "button15");
            this.button15.BackColor = System.Drawing.Color.White;
            this.button15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button15.ForeColor = System.Drawing.Color.Blue;
            this.button15.Name = "button15";
            this.button15.TabStop = false;
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.BtnRobotOffsetMoveClick);
            // 
            // tabPage7
            // 
            resources.ApplyResources(this.tabPage7, "tabPage7");
            this.tabPage7.Controls.Add(this.button25);
            this.tabPage7.Controls.Add(this.button24);
            this.tabPage7.Controls.Add(this.button21);
            this.tabPage7.Controls.Add(this.button20);
            this.tabPage7.Controls.Add(this.button16);
            this.tabPage7.Controls.Add(this.button17);
            this.tabPage7.Controls.Add(this.button18);
            this.tabPage7.Controls.Add(this.button23);
            this.tabPage7.Controls.Add(this.button19);
            this.tabPage7.Controls.Add(this.button22);
            this.tabPage7.Controls.Add(this.button26);
            this.tabPage7.Controls.Add(this.button35);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            resources.ApplyResources(this.button25, "button25");
            this.button25.BackColor = System.Drawing.Color.White;
            this.button25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button25.ForeColor = System.Drawing.Color.Blue;
            this.button25.Name = "button25";
            this.button25.TabStop = false;
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button24
            // 
            resources.ApplyResources(this.button24, "button24");
            this.button24.BackColor = System.Drawing.Color.White;
            this.button24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button24.ForeColor = System.Drawing.Color.Blue;
            this.button24.Name = "button24";
            this.button24.TabStop = false;
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button21
            // 
            resources.ApplyResources(this.button21, "button21");
            this.button21.BackColor = System.Drawing.Color.White;
            this.button21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button21.ForeColor = System.Drawing.Color.Blue;
            this.button21.Name = "button21";
            this.button21.TabStop = false;
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button20
            // 
            resources.ApplyResources(this.button20, "button20");
            this.button20.BackColor = System.Drawing.Color.White;
            this.button20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button20.ForeColor = System.Drawing.Color.Blue;
            this.button20.Name = "button20";
            this.button20.TabStop = false;
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button16
            // 
            resources.ApplyResources(this.button16, "button16");
            this.button16.BackColor = System.Drawing.Color.White;
            this.button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button16.ForeColor = System.Drawing.Color.Blue;
            this.button16.Name = "button16";
            this.button16.TabStop = false;
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button17
            // 
            resources.ApplyResources(this.button17, "button17");
            this.button17.BackColor = System.Drawing.Color.White;
            this.button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button17.ForeColor = System.Drawing.Color.Blue;
            this.button17.Name = "button17";
            this.button17.TabStop = false;
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button18
            // 
            resources.ApplyResources(this.button18, "button18");
            this.button18.BackColor = System.Drawing.Color.White;
            this.button18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button18.ForeColor = System.Drawing.Color.Blue;
            this.button18.Name = "button18";
            this.button18.TabStop = false;
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button23
            // 
            resources.ApplyResources(this.button23, "button23");
            this.button23.BackColor = System.Drawing.Color.White;
            this.button23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button23.ForeColor = System.Drawing.Color.Blue;
            this.button23.Name = "button23";
            this.button23.TabStop = false;
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button19
            // 
            resources.ApplyResources(this.button19, "button19");
            this.button19.BackColor = System.Drawing.Color.White;
            this.button19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button19.ForeColor = System.Drawing.Color.Blue;
            this.button19.Name = "button19";
            this.button19.TabStop = false;
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button22
            // 
            resources.ApplyResources(this.button22, "button22");
            this.button22.BackColor = System.Drawing.Color.White;
            this.button22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button22.ForeColor = System.Drawing.Color.Blue;
            this.button22.Name = "button22";
            this.button22.TabStop = false;
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button26
            // 
            resources.ApplyResources(this.button26, "button26");
            this.button26.BackColor = System.Drawing.Color.White;
            this.button26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button26.ForeColor = System.Drawing.Color.Blue;
            this.button26.Name = "button26";
            this.button26.TabStop = false;
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // button35
            // 
            resources.ApplyResources(this.button35, "button35");
            this.button35.BackColor = System.Drawing.Color.White;
            this.button35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button35.ForeColor = System.Drawing.Color.Blue;
            this.button35.Name = "button35";
            this.button35.TabStop = false;
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.BtnSignalAxisMotionClick);
            // 
            // tabPage8
            // 
            resources.ApplyResources(this.tabPage8, "tabPage8");
            this.tabPage8.Controls.Add(this.GrpPositionMove);
            this.tabPage8.Controls.Add(this.button37);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // GrpPositionMove
            // 
            resources.ApplyResources(this.GrpPositionMove, "GrpPositionMove");
            this.GrpPositionMove.Controls.Add(this.label31);
            this.GrpPositionMove.Controls.Add(this.numericUpDown11);
            this.GrpPositionMove.Controls.Add(this.label30);
            this.GrpPositionMove.Controls.Add(this.numericUpDown12);
            this.GrpPositionMove.Controls.Add(this.label29);
            this.GrpPositionMove.Controls.Add(this.numericUpDown8);
            this.GrpPositionMove.Controls.Add(this.numericUpDown7);
            this.GrpPositionMove.Controls.Add(this.label32);
            this.GrpPositionMove.Controls.Add(this.label33);
            this.GrpPositionMove.Controls.Add(this.numericUpDown27);
            this.GrpPositionMove.Controls.Add(this.numericUpDown10);
            this.GrpPositionMove.Controls.Add(this.label34);
            this.GrpPositionMove.Controls.Add(this.numericUpDown26);
            this.GrpPositionMove.Controls.Add(this.label35);
            this.GrpPositionMove.Controls.Add(this.numericUpDown9);
            this.GrpPositionMove.Controls.Add(this.numericUpDown25);
            this.GrpPositionMove.Controls.Add(this.label36);
            this.GrpPositionMove.Controls.Add(this.label37);
            this.GrpPositionMove.Name = "GrpPositionMove";
            this.GrpPositionMove.TabStop = false;
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.Name = "label31";
            // 
            // numericUpDown11
            // 
            resources.ApplyResources(this.numericUpDown11, "numericUpDown11");
            this.numericUpDown11.DecimalPlaces = 3;
            this.numericUpDown11.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown11.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown11.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown11.Name = "numericUpDown11";
            this.numericUpDown11.TabStop = false;
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.Name = "label30";
            // 
            // numericUpDown12
            // 
            resources.ApplyResources(this.numericUpDown12, "numericUpDown12");
            this.numericUpDown12.DecimalPlaces = 3;
            this.numericUpDown12.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown12.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown12.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown12.Name = "numericUpDown12";
            this.numericUpDown12.TabStop = false;
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.Name = "label29";
            // 
            // numericUpDown8
            // 
            resources.ApplyResources(this.numericUpDown8, "numericUpDown8");
            this.numericUpDown8.DecimalPlaces = 3;
            this.numericUpDown8.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown8.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown8.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.TabStop = false;
            // 
            // numericUpDown7
            // 
            resources.ApplyResources(this.numericUpDown7, "numericUpDown7");
            this.numericUpDown7.DecimalPlaces = 3;
            this.numericUpDown7.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown7.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown7.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.TabStop = false;
            // 
            // label32
            // 
            resources.ApplyResources(this.label32, "label32");
            this.label32.Name = "label32";
            // 
            // label33
            // 
            resources.ApplyResources(this.label33, "label33");
            this.label33.Name = "label33";
            // 
            // numericUpDown27
            // 
            resources.ApplyResources(this.numericUpDown27, "numericUpDown27");
            this.numericUpDown27.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown27.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown27.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown27.Name = "numericUpDown27";
            this.numericUpDown27.TabStop = false;
            this.numericUpDown27.Tag = "wr";
            // 
            // numericUpDown10
            // 
            resources.ApplyResources(this.numericUpDown10, "numericUpDown10");
            this.numericUpDown10.DecimalPlaces = 3;
            this.numericUpDown10.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown10.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown10.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown10.Name = "numericUpDown10";
            this.numericUpDown10.TabStop = false;
            // 
            // label34
            // 
            resources.ApplyResources(this.label34, "label34");
            this.label34.Name = "label34";
            // 
            // numericUpDown26
            // 
            resources.ApplyResources(this.numericUpDown26, "numericUpDown26");
            this.numericUpDown26.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown26.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown26.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown26.Name = "numericUpDown26";
            this.numericUpDown26.TabStop = false;
            this.numericUpDown26.Tag = "el";
            // 
            // label35
            // 
            resources.ApplyResources(this.label35, "label35");
            this.label35.Name = "label35";
            // 
            // numericUpDown9
            // 
            resources.ApplyResources(this.numericUpDown9, "numericUpDown9");
            this.numericUpDown9.DecimalPlaces = 3;
            this.numericUpDown9.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown9.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown9.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.TabStop = false;
            // 
            // numericUpDown25
            // 
            resources.ApplyResources(this.numericUpDown25, "numericUpDown25");
            this.numericUpDown25.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown25.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown25.Minimum = new decimal(new int[] {
            9999,
            0,
            0,
            -2147483648});
            this.numericUpDown25.Name = "numericUpDown25";
            this.numericUpDown25.TabStop = false;
            this.numericUpDown25.Tag = "ha";
            // 
            // label36
            // 
            resources.ApplyResources(this.label36, "label36");
            this.label36.Name = "label36";
            // 
            // label37
            // 
            resources.ApplyResources(this.label37, "label37");
            this.label37.Name = "label37";
            // 
            // button37
            // 
            resources.ApplyResources(this.button37, "button37");
            this.button37.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button37.Name = "button37";
            this.button37.TabStop = false;
            this.button37.Tag = "RobotStartMove";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            resources.ApplyResources(this.tabPage3, "tabPage3");
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.TBXIndex);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.textBox2);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.comboBox2);
            this.tabPage3.Controls.Add(this.groupBox26);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // TBXIndex
            // 
            resources.ApplyResources(this.TBXIndex, "TBXIndex");
            this.TBXIndex.Name = "TBXIndex";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // textBox2
            // 
            resources.ApplyResources(this.textBox2, "textBox2");
            this.textBox2.Name = "textBox2";
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // comboBox2
            // 
            resources.ApplyResources(this.comboBox2, "comboBox2");
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Name = "comboBox2";
            // 
            // groupBox26
            // 
            resources.ApplyResources(this.groupBox26, "groupBox26");
            this.groupBox26.Controls.Add(this.imageBox21);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.TabStop = false;
            // 
            // imageBox21
            // 
            resources.ApplyResources(this.imageBox21, "imageBox21");
            this.imageBox21.Name = "imageBox21";
            this.imageBox21.TabStop = false;
            // 
            // EdgeToolForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.tbPSelectModel);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "EdgeToolForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel1.PerformLayout();
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbX)).EndInit();
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imageBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imageBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageBox1)).EndInit();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imageBox91)).EndInit();
            this.groupBox17.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tbIO.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tpSetting.ResumeLayout(false);
            this.tbPTest.ResumeLayout(false);
            this.tbPSelectModel.ResumeLayout(false);
            this.tpRobot.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imageBox101)).EndInit();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.GrpCurrentPosition.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).EndInit();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.GrpPositionMove.ResumeLayout(false);
            this.GrpPositionMove.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown25)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imageBox21)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsslStatus;
        private System.Windows.Forms.ToolStripStatusLabel tsslM2MResponse;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbLoad;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ToolStripLabel tslProduct_Name;
        private System.Windows.Forms.ToolStripMenuItem tsmiRun;
        private System.Windows.Forms.ToolStripMenuItem tsmiNormalTest;
        private System.Windows.Forms.ToolStripMenuItem tsmiCollectImageMode;
        private System.Windows.Forms.ToolStripMenuItem tsmiStartButton;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Timer UItimer;
        private System.Windows.Forms.TabPage tbIO;
        private System.Windows.Forms.TabPage tpSetting;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnHeightBeDivide;
        private System.Windows.Forms.Button btnSaveROI;
        private System.Windows.Forms.Button btnWidthBeDivide;
        private System.Windows.Forms.Button btnDeleteROI;
        private System.Windows.Forms.TrackBar tbHeight;
        private System.Windows.Forms.TrackBar tbWidth;
        private System.Windows.Forms.TrackBar tbY;
        private System.Windows.Forms.TrackBar tbX;
        private System.Windows.Forms.Button btnAddROI;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbROIY;
        private System.Windows.Forms.Label lbROIX;
        private System.Windows.Forms.Label lbDevice;
        private System.Windows.Forms.ComboBox cbDevice;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.TabPage tbPTest;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TabControl tbPSelectModel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label lbDetectionLocation;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label lbLightCurtain;
        private System.Windows.Forms.Label lbDoorSensor;
        private System.Windows.Forms.Label lbEmergency;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Button btnVisualLight;
        private System.Windows.Forms.Button btnLowerVisualLight;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Button btnNG;
        private System.Windows.Forms.Button btnPASS;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox SNtextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnCameraScreenshot;
        private System.Windows.Forms.Button btnReadBracode;
        private System.Windows.Forms.GroupBox groupBox9;
        private Emgu.CV.UI.ImageBox imageBox91;
        private System.Windows.Forms.RadioButton RtnCamera;
        private System.Windows.Forms.RadioButton RtnScanningGun;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Button BtnAOIReady;
        private System.Windows.Forms.Button btnVisualCompletion;
        private System.Windows.Forms.Button btnLowerVisualCompleted;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button btn3ColorAlarm;
        private System.Windows.Forms.Button btn3ColorRed;
        private System.Windows.Forms.Button btn3ColorYellow;
        private System.Windows.Forms.Button btn3ColorGreen;
        private System.Windows.Forms.TabPage tpRobot;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.ComboBox CbMotionType;
        private System.Windows.Forms.ComboBox CbPointName;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.GroupBox GrpCurrentPosition;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown numericUpDown13;
        private System.Windows.Forms.NumericUpDown numericUpDown14;
        private System.Windows.Forms.NumericUpDown numericUpDown15;
        private System.Windows.Forms.NumericUpDown numericUpDown16;
        private System.Windows.Forms.NumericUpDown numericUpDown17;
        private System.Windows.Forms.NumericUpDown numericUpDown21;
        private System.Windows.Forms.NumericUpDown numericUpDown20;
        private System.Windows.Forms.NumericUpDown numericUpDown19;
        private System.Windows.Forms.NumericUpDown numericUpDown18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.GroupBox GrpPositionMove;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown numericUpDown11;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown numericUpDown12;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown numericUpDown27;
        private System.Windows.Forms.NumericUpDown numericUpDown10;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown numericUpDown26;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.NumericUpDown numericUpDown25;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TabPage tabPage3;
        private Emgu.CV.UI.ImageBox imageBox101;
        private Emgu.CV.UI.ImageBox imageBox40;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label LBCoutInput;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label LBProductYield;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label LBStationName;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label LBCountPass;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label LBCountFail;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label LBSN;
        private Emgu.CV.UI.ImageBox imageBox20;
        private Emgu.CV.UI.ImageBox imageBox19;
        private Emgu.CV.UI.ImageBox imageBox18;
        private Emgu.CV.UI.ImageBox imageBox17;
        private Emgu.CV.UI.ImageBox imageBox16;
        private Emgu.CV.UI.ImageBox imageBox15;
        private Emgu.CV.UI.ImageBox imageBox14;
        private Emgu.CV.UI.ImageBox imageBox13;
        private Emgu.CV.UI.ImageBox imageBox12;
        private Emgu.CV.UI.ImageBox imageBox11;
        private Emgu.CV.UI.ImageBox imageBox10;
        private Emgu.CV.UI.ImageBox imageBox9;
        private Emgu.CV.UI.ImageBox imageBox8;
        private Emgu.CV.UI.ImageBox imageBox7;
        private Emgu.CV.UI.ImageBox imageBox6;
        private Emgu.CV.UI.ImageBox imageBox5;
        private Emgu.CV.UI.ImageBox imageBox4;
        private Emgu.CV.UI.ImageBox imageBox3;
        private Emgu.CV.UI.ImageBox imageBox2;
        private Emgu.CV.UI.ImageBox imageBox1;
        private System.Windows.Forms.Label lbPredictionResult2;
        private System.Windows.Forms.Button btnxiaPASS;
        private System.Windows.Forms.Button btnRobotPass;
        private System.Windows.Forms.Label LBlian;
        private System.Windows.Forms.Label LBxuan;
        private System.Windows.Forms.Label lbLowerVisualPosition;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TBIndex;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TBSerial;
        private System.Windows.Forms.ToolStripMenuItem tsmiCollectImagepoint;
        private System.Windows.Forms.GroupBox groupBox26;
        private Emgu.CV.UI.ImageBox imageBox21;
        private System.Windows.Forms.TextBox TBXIndex;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem tsLanguage;
        private System.Windows.Forms.ToolStripMenuItem tsChinese;
        private System.Windows.Forms.ToolStripMenuItem tsEnglish;
        private System.Windows.Forms.ToolStripMenuItem tsVistnamese;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
    }
}

