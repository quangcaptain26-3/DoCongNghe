﻿/* Class: ColorLight
 * Function:    void greenOn(),    void greenOff(), 
 *              void yellowOn(),    void yellowOff(), 
 *              void redOn(),       void redOff(),
 *              void buzzerOn(),    void buzzerOff()
 *              
 * Remark: 控制三色燈與 buzzer 的 on/off，三色燈包含Green, Yellow, Red以及Buzzer
 * IOTable 中須定義 GreenLight, YellowLight, RedLight, Buzzer 的 Info
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using pegatron.basic;
using AdvantechIOCard;

namespace ImageCapture
{
    public enum ColorLightTypes {
        start,
        pause,
        stop,
        exit,
        safety,
        waitResponse,
        info,
        normal,
        warning,
        error,
        jigPreDisable,
        jigDisable,
    }

    public class ColorLight {
        private const int ACTIVE_INTERVAL = 300;
        private const int INACTIVE_INTERVAL = 300;
        private const int LONG_INTERVAL = 3000;

        private IOCardCollection ioCardCollection;
        private pegatronLog msgLog;

        public OutputControl greenLight;
        public OutputControl yellowLight;
        public OutputControl redLight;
        public OutputControl buzzer;
        public OutputControl Light;
        public OutputControl DownLight;

        public ColorLight(IOCardCollection ioCardCollection)
        {
            this.ioCardCollection = ioCardCollection;
            //this.msgLog = msgLog;
            IODataInit();
        }

        //public ColorLight(List<IOControl.IOControl> IOControls,pegatronLog msgLog)
        //{
        //    this.msgLog = msgLog;
        //    greenLight = IOControls.Find(x => x.ioName == "GreenLight") as OutputControl;
        //    yellowLight= IOControls.Find(x => x.ioName == "YellowLight") as OutputControl;
        //    redLight= IOControls.Find(x => x.ioName == "RedLight") as OutputControl;
        //    buzzer= IOControls.Find(x => x.ioName == "Buzzer") as OutputControl;
        //}

        //public ColorLight(List<IOControl.IOControl> IOControls, pegatronLog msgLog,int number)
        //{
        //    try
        //    {
        //        this.msgLog = msgLog;
        //        greenLight = IOControls.Find(x => x.ioName == string.Format("GreenLight{0}", number)) as OutputControl;
        //        yellowLight = IOControls.Find(x => x.ioName == string.Format("YellowLight{0}", number)) as OutputControl;
        //        redLight = IOControls.Find(x => x.ioName == string.Format("RedLight{0}", number)) as OutputControl;
        //        buzzer = IOControls.Find(x => x.ioName == string.Format("Buzzer{0}", number)) as OutputControl;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }         
        //}

        bool IODataInit() {
            try {
                greenLight = new OutputControl(ioCardCollection, "GreenLight");
                yellowLight = new OutputControl(ioCardCollection, "YellowLight");
                redLight = new OutputControl(ioCardCollection, "RedLight");
                buzzer = new OutputControl(ioCardCollection, "Buzzer");
                Light = new OutputControl(ioCardCollection, "Light");
                DownLight = new OutputControl(ioCardCollection, "DownLight");
                Initial();

                return true;
            } catch (Exception) {
                return false;
            }
        }

        public void TurnOff() {
            greenOff();
            yellowOff();
            redOff();
            buzzerOff();
        }

        public void Initial() {
            greenOff();
            yellowOn();
            redOff();
            buzzerOff();
        }

        public void Start() {
            greenOn();
            yellowOff();
            redOff();
            for (int i = 0; i < 3; i++) {
                buzzerOn();
                Thread.Sleep(ACTIVE_INTERVAL);
                buzzerOff();
                Thread.Sleep(INACTIVE_INTERVAL);
            }
        }
        public void Warn(int i)
        {
            greenOff();
            yellowOn();
            redOff();
            Thread th = new Thread(new ParameterizedThreadStart(x =>
            {
                buzzerOn();
                Thread.Sleep((int)x);
                buzzerOff();
            }));
            th.Start(i);
        }

        public void Stop() {
            greenOff();
            yellowOff();
            redOn();
            for (int i = 0; i < 3; i++) {
                buzzerOn();
                Thread.Sleep(ACTIVE_INTERVAL);
                buzzerOff();
                Thread.Sleep(INACTIVE_INTERVAL);
            }
        }

        public void Exit() {
            greenOff();
            yellowOff();
            redOff();
        }

        public void Normal() {
            greenOn();
            yellowOff();
            redOff();
            buzzerOff();
        }

        public void Info() {
            greenOff();
            yellowOff();
            redOff();
            for (int i = 0; i < 3; i++) {
                yellowOn();
                buzzerOn();
                Thread.Sleep(ACTIVE_INTERVAL);
                yellowOff();
                buzzerOff();
                Thread.Sleep(INACTIVE_INTERVAL);
            }
            yellowOn();
        }


        public void Warn() {
            greenOff();
            yellowOn();
            redOff();
            buzzerOn();
        }

        public void Error() {
            greenOff();
            yellowOff();
            redOn();
            buzzerOn();
        }

        public void Error(int i)
        {
            greenOff();
            yellowOff();
            redOn();
            Thread th = new Thread(new ParameterizedThreadStart(x => {
                buzzerOn();
                Thread.Sleep((int)x);
                buzzerOff();
            }));
            th.Start(i);
        }

        public void Fatal() {
            greenOff();
            yellowOff();
            redOn();
            buzzerOn();
        }

        public void SfisError()
        {
            greenOff();
            redOff();
            yellowOff();
            for (int i = 0; i < 3; i++)
            {
                yellowOn();
                buzzerOn();
                Thread.Sleep(ACTIVE_INTERVAL);
                yellowOff();
                buzzerOff();
                Thread.Sleep(INACTIVE_INTERVAL);
            }
            yellowOn();
        }
        public void SNError()
        {
            greenOff();
            redOn();
            yellowOff();
            for (int i = 0; i < 3; i++)
            {
                buzzerOn();
                Thread.Sleep(500);
                buzzerOff();
                Thread.Sleep(500);
            }
        }
        public void LightOPen()
        {
            
            LightOff();
        }
        public void LightFalse()
        {
            LightOn();
        }
        public void DownLightOpen()
        {
            DownLightOff();
        }
        public void DownLightFalse()
        {
            
            DownLightOn();

        }
        private void LightOn()
        {
            Light.WriteState(true);
        }
        private void LightOff()
        {
            Light.WriteState(false);
        }
        private void DownLightOn()
        {
            DownLight.WriteState(true);
        }
        private void DownLightOff()
        {
            DownLight.WriteState(false);
        }
        private void greenOn() {
            greenLight.WriteState(true);
        }

        private void greenOff() {
            greenLight.WriteState(false);
        }

        private void yellowOn() {
            yellowLight.WriteState(true);
        }

        private void yellowOff() {
            yellowLight.WriteState(false);
        }

        private void redOn() {
            redLight.WriteState(true);
        }

        private void redOff() {
            redLight.WriteState(false);
        }

        private void buzzerOn() {
            buzzer.WriteState(true);
        }

        private void buzzerOff() {
            buzzer.WriteState(false);
        }
    }
}
