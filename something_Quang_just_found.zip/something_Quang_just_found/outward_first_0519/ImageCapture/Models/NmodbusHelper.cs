﻿using Modbus.Device;
using Sunny.UI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ImageCapture.Models
{
    public enum PLCStartEnum
    {
        S = 0,
        M = 43520,
        D = 4096,
        X = 1024,
        Y = 1280
    }
    public class NmodbusHelper
    {
        private ModbusIpMaster master;

        private TcpClient tcpClient = new TcpClient();

        //连接
        public bool Connect(string host, int port)
        {
            try
            {
                tcpClient.Connect(host, port);
                if (tcpClient.Connected)
                {
                    master = ModbusIpMaster.CreateIp(tcpClient);
                }
            }
            catch (Exception)
            {

                return false;
            }
            return true;
        }
        //断开
        public void DisConnect()
        {
            tcpClient?.Dispose();
            tcpClient.Close();
        }

        #region 读取线圈
        public bool ReadSinglCoil(ushort staraddress, ushort length = 1)
        {
            var data = master.ReadCoils(staraddress, length);
            if (data?.Length > 0)
            {
                return data[0];
            }
            return false;
        }
        //按地址名称读取
        public bool ReadSinglCoilByAddressName(string address, ushort length = 1)
        {

            int startAddress = GetAddressNumber(address);
            if (startAddress <= 0)
            {
                return false;
            }
            ushort start = Convert.ToUInt16(startAddress);
            return ReadSinglCoil(start);
        }

        public Task<bool> ReadSingleCoilAsync(string address)
        {

            int startAddress = GetAddressNumber(address);
            if (startAddress < 0)
            {
                return Task.FromResult(false);
            }
            ushort start = Convert.ToUInt16(startAddress);
            var task = master.ReadCoilsAsync(start, 1).ContinueWith(t => t.Result?.Length > 0 ? t.Result[0] : false);

            return task;
        }

        //超时读取
        public bool ReadCoilByAddressTimeOut(string address, int timeout)
        {
            Stopwatch sw = Stopwatch.StartNew();
            bool result = false;
            do
            {
                if (ReadSinglCoilByAddressName(address, 1))
                {
                    sw.Stop();
                    result = true;
                    break;
                }
            } while (sw.ElapsedMilliseconds <= timeout);
            return result;
        }
        #endregion
        #region 写线圈
        public bool WriteSingleCoil(ushort address, bool value)
        {
            try
            {
                master.WriteSingleCoil(address, value);
            }
            catch (Exception)
            {

                return false;
            }
            return true;
        }
        //按地址名称读取
        public bool WriteSinglCoilByAddress(string address, bool value)
        {
            try
            {
                int startAddress = GetAddressNumber(address);
                if (startAddress < 0)
                {
                    return false;
                }
                ushort start = Convert.ToUInt16(startAddress);
                return WriteSingleCoil(start, value);
            }
            catch (Exception)
            {

                return false;
            }
        }



        #endregion
        #region 读取保持寄存器
        public ushort ReadSingleHoldRegister(ushort address)
        {
            var data = master.ReadHoldingRegisters(address, 1);
            if (data?.Length > 0)
            {
                return Convert.ToUInt16(data[0]);
            }
            return default(ushort);

        }
        //按地址名称读取
        public ushort ReadSingleHoldRegisterByAddressName(string address)
        {
            int startAddress = GetAddressNumber(address);
            if (startAddress < 0)
            {
                return default;
            }
            ushort start = Convert.ToUInt16(startAddress);
            return ReadSingleHoldRegister(start);

        }

        //异步读取 

        public Task<ushort> ReadSingleHoldRegisterAsync(string address)
        {

            int startAddress = GetAddressNumber(address);
            if (startAddress < 0)
            {
                throw new ArgumentException("Invalid address"); // 抛出一个异常
            }
            ushort start = Convert.ToUInt16(startAddress);
            Task<ushort> task = master.ReadHoldingRegistersAsync(start, 1).ContinueWith(t => t.Result[0]);

            return task;
        }

        //读取指定值

        public Task<bool> ReadHoldRegisterByspecificTask(string address, ushort uValue)
        {

            var task = Task.Run(() =>
            {
                bool result = false;
                while (true)
                {

                    var v = ReadSingleHoldRegisterByAddressName(address);
                    if (v == uValue)
                    {
                        result = true;
                        break;
                    }
                }
                return result;
            });
            return task;
        }

        #endregion
        #region 写入保持寄存器
        public bool WriteSingleRegister(ushort address, ushort value)
        {
            bool Result = false;
            try
            {
                master.WriteSingleRegister(address, value);
                Result = true;
            }
            catch (Exception)
            {

                Result = false;
            }
            return Result;
        }

        //按地址写入
        public bool WriteSingleRegisterByaddressName(string addressName, ushort value)
        {
            bool Result = false;
            try
            {

                int startAddress = GetAddressNumber(addressName);
                if (startAddress < 0)
                {
                    return false;
                }
                ushort start = Convert.ToUInt16(startAddress);
                Result = WriteSingleRegister(start, value);
            }
            catch (Exception)
            {

                Result = false;
            }
            return Result;
        }
        #endregion

        private int GetAddressNumber(string addressName)
        {

            int startAddress = -1;
            string pattern = @"^[a-zA-Z][0-9]*$";
            bool b = Regex.IsMatch(addressName, pattern);
            if (b)
            {
                string character = addressName.Substring(0, 1);
                string num = addressName.Substring(1);
                switch (character.ToUpper())
                {
                    case "S":
                        startAddress = (int)PLCStartEnum.S + num.ToInt();
                        break;
                    case "M":
                        startAddress = (int)PLCStartEnum.M + num.ToInt();
                        break;
                    case "Y":
                        startAddress = (int)PLCStartEnum.Y + Convert.ToInt32(num, 8);
                        break;
                    case "X":
                        startAddress = (int)PLCStartEnum.X + Convert.ToInt32(num, 8);
                        break;
                    case "D":
                        startAddress = 4096 + num.ToInt();
                        break;
                    default:
                        break;
                }
            }
            return startAddress;
        }

    }
}
