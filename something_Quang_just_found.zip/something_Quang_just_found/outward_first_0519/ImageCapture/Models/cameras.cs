﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using Basler.Pylon;
using pegatron.basic;

namespace ImageCapture.Models
{
    class Cameras
    {
        //连接相机
        public int CameraNumber = CameraFinder.Enumerate().Count;
        public delegate void CameraImage(Bitmap png);
        public event CameraImage CameraImageEveny;
        Camera camera;
        PixelDataConverter pixelCamera = new PixelDataConverter();
        bool GraOver = false;


        public void CameraInit(string sn)
        {
            camera = new Camera(sn);

            //相机自由事件
            camera.CameraOpened += Configuration.AcquireContinuous;

            //相机开始事件
            camera.StreamGrabber.GrabStarted += StreamGrabber_GrabStarted;

            //相机关闭事件
            camera.StreamGrabber.GrabStopped += StreamGrabber_GrabStopped;

            //相机断开事件
            camera.ConnectionLost += Camera_ConnectionLost;

            //相机拍照事件
            camera.StreamGrabber.ImageGrabbed += StreamGrabber_ImageGrabbed;

            //相机打开
            camera.Open();

        }
        private void StreamGrabber_ImageGrabbed(object sender, ImageGrabbedEventArgs e)
        {
            IGrabResult grabResult = e.GrabResult;

            if (grabResult.IsValid)
            {
                if (GraOver)
                {
                    CameraImageEveny(GrabResultBmp(grabResult));
                }
            }
        }

        private void Camera_ConnectionLost(object sender, EventArgs e)
        {
            camera.StreamGrabber.Stop();
            DisCamera();
        }

        private Bitmap GrabResultBmp(IGrabResult grabResult)
        {
            Bitmap b = new Bitmap(grabResult.Width, grabResult.Height, PixelFormat.Format32bppArgb);
            BitmapData pngData = b.LockBits(new Rectangle(0, 0, b.Width, b.Height), ImageLockMode.ReadWrite, b.PixelFormat);
            pixelCamera.OutputPixelFormat = PixelType.BGRA8packed;
            IntPtr pngIntpr = pngData.Scan0;
            pixelCamera.Convert(pngIntpr, pngData.Stride * b.Height, grabResult);

            b.UnlockBits(pngData);
            return b;
        }


        private void StreamGrabber_GrabStopped(object sender, GrabStopEventArgs e)
        {
            GraOver = false;
        }

        private void StreamGrabber_GrabStarted(object sender, EventArgs e)
        {
            GraOver = true;
        }

        public void OneShot()
        {
            if (camera != null)
            {
                camera.Parameters[PLCamera.AcquisitionMode].SetValue(PLCamera.AcquisitionMode.SingleFrame);
                camera.StreamGrabber.Start(1, GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);
            }
        }

        public void Stop()
        {
            if (camera != null)
            {
                camera.StreamGrabber.Stop();
            }
        }

        public void KeepShot()
        {
            if (camera != null)
            {
                camera.Parameters[PLCamera.AcquisitionMode].SetValue(PLCamera.AcquisitionMode.Continuous);
                camera.StreamGrabber.Start(GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);
            }
        }

        public void DisCamera()
        {
            if (camera != null)
            {
                camera.Close();
                camera.Dispose();
                camera = null;
            }
        }
    }
}
