﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageCapture.Models
{
    public enum TestMode
    {
        Test_Mode,
        Collect_Image_Mode,
        Collect_Image_Point,
        Conveyor_Mode,
    }
}
