﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Diagnostics;
using ImageCapture.WebReference;

namespace ImageCapture.Models
{
    public class SFISHelper
    {
        private readonly char seqparator = Convert.ToChar(127);
        private SFISTSPWebService SFISWebService = new SFISTSPWebService();
        public delegate void TickHandler(string msg);
        public event TickHandler Tick;
        //public Drivers.ConfigStruct config;

        /// <summary>
        /// SFIS账号
        /// </summary>
        public string ProgramUid { set; get; } = ConfigurationManager.AppSettings["ProgramId"];
        /// <summary>
        /// SFIS密码
        /// </summary>
        public string ProgramPassword { set; get; } = ConfigurationManager.AppSettings["ProgramPassword"];
        /// <summary>
        /// 工号
        /// </summary>
        public string WorkerID { set; get; } = ConfigurationManager.AppSettings["WorkerID"];
        /// <summary>
        /// 密码
        /// </summary>
        public string Password { set; get; } = "";
        /// <summary>
        /// 拨号
        /// </summary>
        public string DeviceID { set; get; } = ConfigurationManager.AppSettings["DeviceID"];
        /// <summary>
        /// 站位信息
        /// </summary>
        public string TSP { set; get; } = "TSP";
        private string message;
        /// <summary>
        /// 最后一次SFIS处理的原始信息
        /// </summary>
        private string lastMessage
        {
            set
            {
                //Debug.WriteLine("[SFISMsg]" + value);
                message = value;
            }
            get
            {
                return message;
            }
        }
        /// <summary>
        /// SFIS的最后处理信息,对外接口.
        /// </summary>
        public string LastMessage { get { return lastMessage; } }
        /// <summary>
        /// 当前SFIS是否已经登录
        /// </summary>
        public bool IsLogin { get { return CheckLogin(); } }

        /// <summary>
        /// 是否自动重新登入
        /// </summary>
        public bool AutoRelogin { set; get; } = false;
        /// <summary>
        /// 自动登入的时间间隔
        /// </summary>
        public double IntervalH { set; get; } = 11.5;
        private Timer timer;
        public DateTime LoginTime { private set; get; }
        private DateTime NextLoginTime;
        public string SFISLeftTime
        {
            get
            {
                return (NextLoginTime - DateTime.Now).ToString(@"hh\:mm\:ss");
            }
        }
        public string GetDatabaseInfomation()
        {
            lastMessage = SFISWebService.GetDatabaseInformation();
            return lastMessage;
        }
        /// <summary>
        /// 登入SFIS
        /// </summary>
        /// <param name="DeviceId">拨号</param>
        /// <param name="WorkerId">工号</param>
        /// <returns>登入结果</returns>
        public bool Login(string DeviceId, string WorerkId, string ProgramUid, string ProgramPassword)
        {
            this.DeviceID = DeviceId;
            this.WorkerID = WorerkId;
            this.ProgramUid = ProgramUid;
            this.ProgramPassword = ProgramPassword;


            return Login();
        }
        /// <summary>
        /// 登入SFIS
        /// </summary>
        /// <returns>登入结果</returns>
        public bool Login()
        {
            this.Logout();
            try
            {
                if (string.IsNullOrEmpty(this.DeviceID) || string.IsNullOrEmpty(WorkerID)) throw new Exception("DeviceId or WorkerId is empty.");
                lastMessage = SFISWebService.WTSP_LOGINOUT(ProgramUid, ProgramPassword, WorkerID, Password, DeviceID, "", 1);
                var res = lastMessage.Contains("Welcome using Pegatron SFIS") || lastMessage.Contains("Login Twice");
                if (res && AutoRelogin)
                {
                    NextLoginTime = DateTime.Now.AddHours(this.IntervalH);

                    timer = new Timer() { Interval = 1000, Enabled = true };
                    timer.Tick += delegate
                    {
                        if ((NextLoginTime - DateTime.Now).TotalMinutes < 30)
                        {
                            this.Logout();
                            this.Login();
                        }
                        Tick?.Invoke(SFISLeftTime);
                    };
                }

                return res;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "SFIS ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        /// <summary>
        /// 登出SFIS
        /// </summary>
        /// <returns>登出结果</returns>
        public bool Logout()
        {
            try
            {
                lastMessage = SFISWebService.WTSP_LOGINOUT(ProgramUid, ProgramPassword, WorkerID, Password, DeviceID, TSP, 2);
                var res = lastMessage.Contains("Thank you for using Pegatron SFIS") || lastMessage.Contains("Login First");
                if (timer != null) timer.Enabled = !res;
                return res;
            }
            catch (Exception)
            {
                return false;
                //throw;
            }

        }
        /// <summary>
        /// 检查当前拨号是否已经被使用
        /// </summary>
        /// <returns>拨号使用状态</returns>
        private bool CheckLogin()
        {
            lastMessage = SFISWebService.WTSP_LOGINOUT(ProgramUid, ProgramPassword, WorkerID, Password, DeviceID, TSP, 5);
            return lastMessage.Contains("IN USED");
        }
        public bool WTSP_CHKROUTE(string SSN)
        {
            lastMessage = SFISWebService.WTSP_CHKROUTE(ProgramUid, ProgramPassword, SSN, DeviceID, "", "", 1);
            return lastMessage.StartsWith("1");
        }
        /// <summary>
        /// 为SFIS设置MO信息,投入站需要,非必要步骤.
        /// </summary>
        /// <param name="MO">工单号</param>
        /// <returns>执行结果</returns>
        public bool MOINFO(string MO)
        {
            lastMessage = SFISWebService.WTSP_DEVIF_MO(ProgramUid, ProgramPassword, DeviceID, MO);
            return lastMessage.StartsWith("1");
        }
        public bool WTSP_GETVERSION(string SSN, string type, string checkData1, string checkData2)
        {
            lastMessage = SFISWebService.WTSP_GETVERSION(ProgramUid, ProgramPassword, SSN, DeviceID, type, checkData1, checkData2);
            return lastMessage.StartsWith("1");
        }
        /// <summary>
        /// 普通站过站
        /// </summary>
        /// <param name="SSN">流水号</param>
        /// <param name="ErrorCode">错误代码,成功留空.</param>
        /// <param name="data">上传的数据</param>
        /// <returns>过站结果</returns>
        public bool WTSP_RESULT(string SSN, string ErrorCode, string data)
        {
            lastMessage = SFISWebService.WTSP_RESULT(ProgramUid, ProgramPassword, SSN, ErrorCode, DeviceID, TSP, data, 1, "N");
            return lastMessage.StartsWith("1");
        }
        public bool WTSP_REPAIR(string SSN, string REASON, string DUTY)
        {
            lastMessage = SFISWebService.WTSP_REPAIR(ProgramUid, ProgramPassword, "1", SSN, DeviceID, REASON, DUTY, "", "");
            return lastMessage.StartsWith("1");
        }
        /// <summary>
        /// 获取整箱的标准重量.
        /// </summary>
        /// <param name="SSN">流水号</param>
        /// <returns>成功返回重量值字串,失败返回NA</returns>
        public string GetWeightBox(string SSN)
        {
            if (WTSP_GETVERSION(SSN, "GET_PKTYPE_GW", "AY", "PKTYPE_T"))
            {
                return lastMessage.Split(new char[] { seqparator }).ElementAt<string>(2);
            }
            else
            {
                return null;
            }

        }
        /// <summary>
        /// 获取Carton的标准重量
        /// </summary>
        /// <param name="SSN">序列号</param>
        /// <returns>成功返回重量,失败返回NA</returns>
        public string GetWeightCarton(string SSN)
        {
            if (WTSP_GETVERSION(SSN, "GET_PKTYPE_GW", "C", "PKTYPE"))
            {
                return lastMessage.Split(new char[] { '\u007f' }).ElementAt<string>(2);
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        /// 保存重量到SFIS_BOX
        /// </summary>
        /// <param name="averageWeigh">标准重量</param>
        /// <param name="actualWeigh">实际重量</param>
        /// <param name="SSN">序列号</param>
        /// <returns>操作结果</returns>
        public bool SaveBoxWeightToSFIS(string averageWeigh, string actualWeigh, string SSN)
        {
            return WTSP_SSD_INPUTDATA(averageWeigh + ";" + actualWeigh + seqparator + SSN, "1");
        }
        /// <summary>
        /// 保存重量到SFIS_Carton
        /// </summary>
        /// <param name="Weight">重量</param>
        /// <param name="SSN">流水號</param>
        /// <returns>執行結果</returns>
        public bool SaveCartonWeightToSFIS(string Weight, string SSN)
        {
            return WTSP_SSD_INPUTDATA(Weight + seqparator + "C" + seqparator + SSN, "1");
        }
        /// <summary>
        /// 获取对应的序列号
        /// </summary>
        /// <param name="ISN">输入序列号</param>
        /// <param name="type">序列号类型 可选ISN/SSN/SN1</param>
        /// <returns>成功返回对应序列号,失败返回null</returns>
        public string GetSN(string ISN, string type)
        {
            if (WTSP_GETVERSION(ISN, "GET_TOKPISN_INFO", type, ""))
            {
                return lastMessage.Split(seqparator)[2].Split(':')[1];
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        /// WTSP_SSD_INPUTDATA基本函數
        /// </summary>
        /// <param name="data">數據</param>
        /// <param name="type">類型</param>
        /// <returns>執行結果</returns>
        public bool WTSP_SSD_INPUTDATA(string data, string type)
        {
            lastMessage = SFISWebService.WTSP_SSD_INPUTDATA(ProgramUid, ProgramPassword, DeviceID, data, type);
            return lastMessage.StartsWith("1");
        }
        /// <summary>
        /// 以台車號綁定方式過站
        /// </summary>
        /// <param name="ISN">流水號</param>
        /// <param name="err">錯誤信息,沒有錯誤留空</param>
        /// <returns>執行結果</returns>
        public bool ContainerBinding(string ISN, string err = null)
        {
            string data = err == null ? ISN : ISN + seqparator + err;
            return WTSP_SSD_INPUTDATA(data, "1");
        }
        /// <summary>
        /// 關閉ISN對應的台車號
        /// </summary>
        /// <param name="ISN">流水號</param>
        /// <returns>執行結果</returns>
        public bool ContainerClose(string ISN)
        {
            return WTSP_SSD_INPUTDATA("CLOSE_CONTAIN" + seqparator + ISN, "5");
        }
    }
}
