﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using Newtonsoft.Json;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using System.Drawing;

namespace ImageCapture.Models
{
    class Inference_SDK : IDisposable
    {
        public delegate void SdkResponseDelegate(string msg);
        public event SdkResponseDelegate GetModelName;
        public event SdkResponseDelegate GetModelVersion;
        public event SdkResponseDelegate PredictError;

        public string inference_ip;
        public string Service_Name;
        public string Service_Token;
        public string Service_Version;
        public string Service_Weight;
        public string device_id;
        public int[] image_shape;
        public HttpClient httpclient;
        public string n;
        public string o;


        public Inference_SDK(string inference_IP, string service_Name, string service_Token,string service_version, string service_weight , string device_ID)
        {
            this.inference_ip = inference_IP;
            this.Service_Name = service_Name;
            this.Service_Token = service_Token;
            this.device_id = device_ID;
            this.Service_Version = service_version;
            this.Service_Weight = service_weight;
        }



        public void Initial()
        {
            try
            {
                httpclient = new HttpClient();
                httpclient.DefaultRequestHeaders.Add("Connection", "keep-alive");
                httpclient.DefaultRequestHeaders.Add("Service-Name", Service_Name);
                httpclient.DefaultRequestHeaders.Add("Service-Token", Service_Token);
                httpclient.DefaultRequestHeaders.Add("Service-Version", Service_Version);
                httpclient.DefaultRequestHeaders.Add("Service-Weight", Service_Weight);
                (string model_name, string model_version) = GetModelInfo();
                if (!string.IsNullOrEmpty(model_name))
                    GetModelName?.Invoke(model_name);
                else
                    throw new Exception($"Error when calling get_classification_name");
                if (!string.IsNullOrEmpty(model_version))
                    GetModelVersion?.Invoke(model_version);
                else
                    throw new Exception($"Error when calling get_classification_version");
                GetImageShape();
            }
            catch (Exception ex)
            {
                PredictError?.Invoke(ex.Message);
            }

        }



        private void GetImageShape()
        {
            try
            {
                string shape = GetMessage($"http://{inference_ip}:7779/api/v2/serving/input_image_shape");
                InputImageShape imageshape = JsonConvert.DeserializeObject<InputImageShape>(shape);
                image_shape = imageshape.input_image_shape;
            }
            catch
            {

            }
        }


        private string GetMessage(string uri)
        {
            string json = string.Empty;
            HttpWebRequest request = WebRequest.Create(uri) as HttpWebRequest;
            request.Method = "Get";
            request.ContentType = "application/json";
            request.Headers.Add("Service-Name", Service_Name);
            request.Headers.Add("Service-Token", Service_Token);
            request.Headers.Add("Service-Version", Service_Version);
            request.Headers.Add("Service-Weight", Service_Weight);
            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            {
                StreamReader sr = new StreamReader(response.GetResponseStream());
                json = sr.ReadToEnd();
                sr.Close();
            }
            return json;
        }



        private (string, string) GetModelInfo()
        {
            string modelname = string.Empty;
            string modelversion = string.Empty;
            try
            {
                string result = GetMessage($"http://{inference_ip}:7779/api/v2/serving/version");
                ModelVersion version = JsonConvert.DeserializeObject<ModelVersion>(result);
                modelname = version.models[0].name;
                modelversion = version.models[0].version;
            }
            catch
            {

            }
            return (modelname, modelversion);
        }




        public async Task<(string result, string resp_info)> YoloPredictFull(string imageFile, string product_name)
        {
            try
            {
                if (File.Exists(imageFile))
                {
                    string encodingimage = ImageToBase64(imageFile);
                    string timestamp = ((long)(DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalMilliseconds).ToString();
                    InputJson input = new InputJson(device_id, timestamp, encodingimage, product_name);
                    string JSON = JsonConvert.SerializeObject(input, Formatting.Indented);
                    string predict_result = await Inference(JSON);
                    ReceivedMessage receivedMessage = JsonConvert.DeserializeObject<ReceivedMessage>(predict_result);
                    n = predict_result.ToString();
                    return (receivedMessage.outputs[0].results[0].bbox.ToString(), predict_result);

                }
                else
                    throw new Exception($"{imageFile}:图片不存在");

            }
            catch (Exception ex)
            {
                return ($"PredictException:{ex.Message}", null);
            }

        }




        private string ImageToBase64(string imagefile)
        {
            try
            {
                using (Bitmap bmp = new Bitmap(imagefile))
                using (MemoryStream ms = new MemoryStream())
                {
                    bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    byte[] arr = new byte[ms.Length];
                    ms.Position = 0;
                    ms.Read(arr, 0, (int)ms.Length);
                    ms.Close();
                    return Convert.ToBase64String(arr);
                }
            }
            catch
            {
                return null;
            }
        }


        private async Task<string> Inference(string json)
        {
            HttpContent content = new StringContent(json);
            content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            HttpResponseMessage request = await httpclient.PostAsync($"http://{inference_ip}:7779/api/v2/serving/predict", content);
            return await request.Content.ReadAsStringAsync();
        }


        public void Dispose()
        {
            if (httpclient != null)
                httpclient.Dispose();
        }
    }


    public class ModelVersion
    {
        public Inference_Engine inference_engine;
        public List<Model> models;
    }


    public class Inference_Engine
    {
        public string commit;
        public string committed_timestamp;
        public string name;
        public string version;
    }


    public class Model
    {
        public string convert_error;
        public string convert_status;
        public string framework;
        public string name;
        public string precision;
        public string type;
        public string version;
    }


    public class InputImageShape
    {
        public int[] input_image_shape;
    }



    public class InputJson
    {
        public int model_type;
        public int number_of_input;
        public InputInfo[] inputs;

        public InputJson(string device_id, string timestamp, string base64image, string productname)
        {
            this.model_type = 1;
            this.number_of_input = 1;
            this.inputs = new InputInfo[1] { new InputInfo { caller_id = device_id, caller_timestamp = timestamp, height = 640, input_id = 1, image = base64image, number_of_sub_input = 0, product_name = productname, product_sku = "no", part_id = "1", part_number = "1", sub_inputs = new SubInput[1] { new SubInput() }, width = 640, dut_id_in_panel = "", dut_sn = "", number_of_dut_in_panel = "", panel_sn = "" } };
        }

    }


    public class InputInfo
    {
        public string caller_id;
        public string caller_timestamp;
        public string dut_id_in_panel;
        public string dut_sn;
        public int height;
        public int input_id;
        public string image;
        public string number_of_dut_in_panel;
        public int number_of_sub_input;
        public string product_name;
        public string product_sku;
        public string part_id;
        public string part_number;
        public string panel_sn;
        public SubInput[] sub_inputs;
        public int width;
    }



    public class SubInput
    {
        public SubInput()
        {

        }
    }



    public class ReceivedMessage
    {
        public int error_code;
        public ModelInfo model;
        public Outputs[] outputs;
        
    }


    public class ModelInfo
    {
        public string backend;
        public string convert_status;
        public string name;
        public string precision;
        public string token;
        public string version;
        public string weight_version;
    }



    public class Outputs
    {
        public string callee_id;
        public double cycle_time;
        public string image_file_name;
        public int[] image_resolution;
        public string inference_id;
        public int input_id;
        public bool m2m_send_img;
        public double predict_time;
        public ModelResponse[] results;
        public string test_slot_result;
    }



    public class ModelResponse
    {
        public int category_id;
        public string category_name;
        public double[] category_probs;
        public int[] bbox;
    }
}
