﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text.RegularExpressions;

namespace Epson.V1
{
    public class Robot
    {
        private Socket ControlClient;
        private Socket CommandClient;
        private Socket DataClient;



        public bool FlagPaused = false;

        public string ErrorMessage { private set; get; } = string.Empty;

        public Position position { private set; get; }
        public VisionResult visionResult { private set; get; }

        public event Action<Position> PositionChanged;

        public bool Open(string ip, int controlPort, int commandPort, int dataPort)
        {
            try
            {
                this.Close();

                ControlClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                CommandClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                DataClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                try
                {
                    ControlClient.Connect(ip, controlPort);
                    if (!ControlClient.Connected)
                    {
                        return false;
                    }
                }
                catch (Exception)
                {
                    return false;
                }

                Login("").CheckReturn("Error when login");
                Reset().CheckReturn();
                Start().CheckReturn();

                try
                {
                    CommandClient.Connect(ip, commandPort);
                    DataClient.Connect(ip, dataPort);

                    return CommandClient.Connected && DataClient.Connected;
                }
                catch (Exception)
                {

                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void Close()
        {
            try { Stop(); } catch (Exception) { }
            try { Logout(); } catch (Exception) { }
            //try { DataClient.Close(); } catch (Exception) { }
            //try { CommandClient.Close(); } catch (Exception) { }
            //try { ControlClient.Close(); } catch (Exception) { }
        }

        #region 远程控制指令
        protected bool Login(string password)
        {
            return this.ExecuteControlCommand($"login,{password}");
        }

        protected bool Logout()
        {
            return this.ExecuteControlCommand("logout");
        }

        public bool Start(int programId = 0)
        {
            return this.ExecuteControlCommand($"start,{programId}");
        }

        public bool Stop()
        {
            return this.ExecuteControlCommand("stop");
        }

        public bool Pause()
        {
            var ret = this.ExecuteControlCommand("pause");
            FlagPaused = true;
            return ret;
        }

        public bool Continue()
        {
            FlagPaused = false;
            return this.ExecuteControlCommand("continue");
        }

        public bool Reset()
        {
            return this.ExecuteControlCommand("reset");
        }

        /// <summary>
        /// 获取输入状态, 控制器连接执行.
        /// </summary>
        /// <param name="port"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public bool GetIOState(int port, out bool state)
        {
            string res;
            state = false;
            if (!this.ExecuteControlCommand($"GetIO,{port}", out res, 2000))
            {
                return false;
            }

            state = res.TrimEnd().EndsWith("1");
            return true;

        }
        #endregion

        #region 类型定义
        public enum MotorState { ON, OFF }
        public enum JointState { Free, Lock }
        /// <summary>
        /// 左右手
        /// </summary>
        public enum Hand { Righty = 1, Lefty = 2 }
        /// <summary>
        /// 肘部姿势
        /// </summary>
        public enum Elbow { Above = 1, Below = 2 }
        /// <summary>
        /// 腕部姿势
        /// </summary>
        public enum Wrist { NoFlip = 1, Flip = 2 }
        /// <summary>
        /// 视觉取板
        /// </summary>
        public enum Local { local = 1 }
        public enum MoveMode { GO, MOVE, JUMP }
        public enum Axis { J1, J2, J3, J4, J5, J6, X, Y, Z, U, V, W }
        public class Position
        {
            public string Name;
            public double X;
            public double Y;
            public double Z;
            public double U;
            public double V;
            public double W;
            public Hand Hand;
            public Elbow Elbow;
            public Wrist Wrist;
            public Local Local;


            public Position() { }
            public Position(double x, double y, double z, double u, double v, double w, Hand hand, Elbow elbow, Wrist wrist)
            {
                this.X = x;
                this.Y = y;
                this.Z = z;
                this.U = u;
                this.V = v;
                this.W = w;
                this.Hand = hand;
                this.Elbow = elbow;
                this.Wrist = wrist;
            }

            public override string ToString()
            {
                string hand, elbow, wrist;
                hand = this.Hand == Hand.Lefty ? "/L" : "/R";
                elbow = this.Elbow == Elbow.Above ? "/A" : "/B";
                wrist = this.Wrist == Wrist.Flip ? "/F" : "/NF";
                return $"XY({X},{Y},{Z},{U},{V},{W}) {hand} {elbow} {wrist}";
            }
            public string ToPositionString(string positionString)
            {
                return $"{X},{Y},{Z},{U},{V},{W},{(int)Hand},{(int)Elbow},{(int)Wrist}";
            }
            public static Position FromXYString(string xystring)
            {
                Hand hand = xystring.Contains("/L") ? Hand.Lefty : Hand.Righty;
                Elbow elbow = xystring.Contains("/A") ? Elbow.Above : Elbow.Below;
                Wrist wrist = xystring.Contains("/F") ? Wrist.Flip : Wrist.NoFlip;
                xystring = xystring.ToUpper().Trim().Replace("XY(", "");
                double[] tmpArr = Array.ConvertAll<string, double>(xystring.Split(')')[0].Split(','), (x) => double.Parse(x.Trim()));
                return new Position(tmpArr[0], tmpArr[1], tmpArr[2], tmpArr[3], tmpArr[4], tmpArr[5], hand, elbow, wrist);
            }

            public static Position FromPositionString(string positionString)
            {
                string[] tmpArr = positionString.Trim().Split(',');
                return new Position()
                {
                    X = Convert.ToDouble(tmpArr[1]),
                    Y = Convert.ToDouble(tmpArr[2]),
                    Z = Convert.ToDouble(tmpArr[3]),
                    U = Convert.ToDouble(tmpArr[4]),
                    V = Convert.ToDouble(tmpArr[5]),
                    W = Convert.ToDouble(tmpArr[6]),
                    Hand = (tmpArr[7] == "1") ? Hand.Righty : Hand.Lefty,
                    Elbow = (tmpArr[8] == "1") ? Elbow.Above : Elbow.Below,
                    Wrist = (tmpArr[9] == "1") ? Wrist.NoFlip : Wrist.Flip
                };
            }

            public Position Clone()
            {
                return (Position)MemberwiseClone();
            }
        }

        public struct VisionResult
        {
            public bool ModelFound;
            public bool PointFound;
            public byte Brightness;
            public byte Contrast;
            public double ExposureTime;
            public bool IsNew;

            public VisionResult(bool modelfound, bool pointfound, byte brightness, byte contrast, double exposuretime)
            {
                this.ModelFound = modelfound;
                this.PointFound = pointfound;
                this.Brightness = brightness;
                this.Contrast = contrast;
                this.ExposureTime = exposuretime;
                this.IsNew = false;
            }

            public static VisionResult ConvertFromString(string result)
            {
                var returnVal = new VisionResult();
                if (string.IsNullOrEmpty(result)) return returnVal;
                string[] stringArr = result.Split(',');
                if (stringArr.Length != 6 || stringArr.First().ToUpper() != "VISION") return returnVal;

                returnVal.ModelFound = stringArr[1].Equals("1");
                returnVal.PointFound = stringArr[2].Equals("1");
                returnVal.Brightness = Convert.ToByte(stringArr[3]);
                returnVal.Contrast = Convert.ToByte(stringArr[4]);
                returnVal.ExposureTime = Convert.ToDouble(stringArr[5]);
                returnVal.IsNew = true;

                return returnVal;
            }
        }

        public enum FlashMode
        {
            OFF = 0, Green = 1, Yellow = 2, Red = 3, Error = 4
        }

        #endregion

        #region 自定义指令
        /// <summary>
        /// 设置马达状态
        /// </summary>
        /// <param name="motorState"></param>
        /// <returns></returns>
        public bool Fcn00_MotorServo(MotorState motorState)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + "," + motorState.ToString());
        }
        /// <summary>
        /// 设置关节状态
        /// </summary>
        /// <param name="jointState"></param>
        /// <returns></returns>
        public bool Fcn01_JointState(JointState jointState)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + "," + jointState.ToString());
        }
        /// <summary>
        /// 获取输入状态
        /// </summary>
        /// <param name="bit"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public bool Fcn02_GetInputState(int bit, out bool state)
        {
            state = false;
            string response;
            try
            {
                this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{bit}", out response).CheckReturn();
                state = response.Contains("On");
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 设置输出状态, 当durationtime大于0, 或isduration为True时. 为设置该bit状态durationtime秒后返回原始状态.
        /// </summary>
        /// <param name="bit"></param>
        /// <param name="state"></param>
        /// <param name="durationtime">持续时间, 单位秒</param>
        /// <param name="isduration">是否为持续</param>
        /// <returns></returns>
        public bool Fcn03_SetOutputState(int bit, bool state)
        {
            string cmd = System.Reflection.MethodBase.GetCurrentMethod().Name + $",{bit},{(state ? "ON" : "OFF")}";
            try
            {
                return this.ExecuteCommand(cmd, 2000);
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 读取当前坐标值, 从属性position中获取
        /// </summary>
        /// <returns></returns>
        public bool Fcn04_ReadCurrentPosition()
        {
            try
            {
                string response;
                this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name, out response).CheckReturn();
                this.position = Position.FromPositionString(response);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// 获取某个点位的坐标信息
        /// </summary>
        /// <param name="point"></param>
        /// <param name="position"></param>
        /// <returns></returns>
        public bool Fcn05_ReadPointPosition(int point, out Position position)
        {
            position = null;
            string response;
            try
            {
                this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{point}", out response).CheckReturn();
                position = Position.FromPositionString(response);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool Fcn06_SavePointHere(int index, string fileName)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{index},{fileName}");
        }
        public bool Fcn55_SaveVisionPoint(int index, string fileName, Local local)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{index},{fileName}");
        }
        public bool Fcn07_SavePointCommit(int index, string fileName, double x, double y, double z, double u, double v, double w, Hand hand, Elbow elbow, Wrist wrist)
        {
            string cmd = $",{index},{fileName},{x},{y},{z},{u},{v},{w},{(int)hand},{(int)elbow},{(int)wrist}";
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + cmd);
        }
        public bool Fcn08_LoadPoint(string fileName)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{fileName}");
        }
        public bool Fcn09_SetSpeed(int speed, int accel)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{speed},{accel}");
        }
        public bool Fcn10_SetSpeeds(int speeds, int accels)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{speeds},{accels}");
        }
        public bool Fcn11_ColorLight(FlashMode mode)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{(int)mode}");
        }
        public bool Fcn12_PickAction(double distance, int vacPort, int blowPort, int vacOKPort)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{distance},{vacPort},{blowPort},{vacOKPort}");
        }
        public bool Fcn13_Placection(double distance, int vacPort, int blowPort, int vacOKPort)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{distance},{vacPort},{blowPort},{vacOKPort}");
        }
        public bool Fcn20_MoveToPoint(int speed, MoveMode moveMode, int index, double zDistance)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{speed},{moveMode},{index},{zDistance}");
        }
        public bool Fcn22_MovoToPointOffset(int speed, MoveMode moveMode, int index, double x, double y, double z, double u, double v, double w)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{speed},{moveMode},{index},{x},{y},{z},{u},{v},{w}");
        }
        public bool Fcn21_MoveToPointsCP(int speed, MoveMode moveMode, int[] points, int[] zDistances = null)
        {
            if (zDistances == null)
            {
                zDistances = new int[points.Length];
            }
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{speed},{moveMode},{string.Join(";", points)},{string.Join(";", zDistances)}");
        }
        public bool Fcn23_MoveToPallet(int speed, MoveMode moveMode, int palletNum, int index, double zDistance)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{speed},{moveMode},{palletNum},{index},{zDistance}");
        }
        public bool Fcn24_GoToPosition(int speed, double x, double y, double z, double u, double v, double w, Hand hand, Elbow elbow, Wrist wrist)
        {
            string cmd = $",{speed},{x},{y},{z},{u},{v},{w},{(int)hand},{(int)elbow},{(int)wrist}";
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + cmd);
        }
        public bool Fcn25_OffsetMove(double x, double y, double z, double u, double v, double w)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{x},{y},{z},{u},{v},{w}");
        }
        public bool Fcn26_SingleAxisMove(int speed, Axis axis, double distance)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{speed},{axis},{distance}");
        }
        public bool Fcn27_GoDownWithTCLim(double zDistance, int tclimit)
        {
            return this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{zDistance},{tclimit}");
        }
        public bool Fcn50_VisionFoundModel(int index, byte brightness, byte contrast, double exposuretime, out VisionResult visionResult)
        {
            string response;
            var ret = this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{index},{brightness},{contrast},{exposuretime}", out response, 60000);
            visionResult = Robot.VisionResult.ConvertFromString(response);
            return ret;
        }
        public bool Fcn51_VisionFoundPoint(byte brightness, byte contrast, double exposuretime, out VisionResult visionResult)
        {
            string response;
            var ret = this.ExecuteCommand(System.Reflection.MethodBase.GetCurrentMethod().Name + $",{brightness},{contrast},{exposuretime}", out response, 10000);
            visionResult = Robot.VisionResult.ConvertFromString(response);
            return ret;
        }

        #endregion

        #region 三个执行指令执行函数

        protected bool ExecuteControlCommand(string cmd, int timeout = 15000)
        {
            string response;
            return ExecuteControlCommand(cmd, out response, timeout);
        }
        protected bool ExecuteControlCommand(string cmd, out string response, int timeout = 15000)
        {
            response = string.Empty;
            string kwd = "\r\n";

            try
            {
                //ClearReceiveBuff(ControlClient);
                if (ControlClient == null) return false;

                //NetworkStream stream = ControlClient.GetStream();
                cmd = $"${cmd}\r\n";
                byte[] sendBuff = Encoding.ASCII.GetBytes(cmd);
                ControlClient.Send(sendBuff);

                int l;
                byte[] receiveBuff = new byte[1024];
                TimeSpan time = new TimeSpan(0);
                DateTime st = DateTime.Now;
                do
                {
                    while (FlagPaused) Thread.Sleep(10);

                    if (ControlClient.Available > 0)
                    {
                        l = ControlClient.Receive(receiveBuff);
                        response += Encoding.ASCII.GetString(receiveBuff, 0, l);
                        if (response.Contains(kwd)) break;
                    }

                    Thread.Sleep(50);
                    time = time.Add(new TimeSpan(TimeSpan.TicksPerMillisecond * 50));
                } while (time.TotalMilliseconds < timeout);

                return response.StartsWith("#") && response.Contains(kwd);
            }
            catch (Exception)
            {
                return false;
            }
        }

        protected bool ExecuteCommand(string cmd, int timeout = 10000)
        {
            string response = string.Empty;

            try
            {
                //获取stream
                //NetworkStream stream = CommandClient.
                cmd = $"{cmd}\r\n";
                byte[] sendBuff = Encoding.ASCII.GetBytes(cmd);

                //发送指令数据
                CommandClient.Send(sendBuff);

                //接收返回信息("OK or NG")
                int l;
                byte[] receiveBuff = new byte[1024];
                TimeSpan time = new TimeSpan(0);
                DateTime st = DateTime.Now;
                do
                {
                    //判断暂停
                    while (FlagPaused) Thread.Sleep(10);

                    if (CommandClient.Available > 0)
                    {
                        l = CommandClient.Receive(receiveBuff);
                        response += Encoding.ASCII.GetString(receiveBuff, 0, l);
                        if (response.Contains("OK") || response.Contains("NG")) break;
                    }

                    Thread.Sleep(50);
                    time = time.Add(new TimeSpan(TimeSpan.TicksPerMillisecond * 50));
                    //超时判断
                } while (time.TotalMilliseconds < timeout);

                //执行NG情况
                if (response.Contains("NG")) return false;

                //判断有数据返回的情况
                Regex regex = new Regex(@"[\d]{2}");
                var match = regex.Match(cmd);
                if (!match.Success) return true;

                int fcnIdx = Convert.ToInt32(match.Value);
                if (fcnIdx >= 20)
                {

                    l = DataClient.Receive(receiveBuff);
                    response = Encoding.ASCII.GetString(receiveBuff, 0, l).Trim();
                    if (response.StartsWith("Position"))
                    {
                        try
                        {
                            this.PositionChanged?.BeginInvoke(Position.FromPositionString(response), null, null);
                        }
                        catch (Exception) { }
                    }
                }

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        protected bool ExecuteCommand(string cmd, out string response, int timeout = 2000)
        {
            response = string.Empty;
            try
            {

                //获取stream
                //NetworkStream stream = CommandClient.GetStream();
                cmd = $"{cmd}\r\n";
                byte[] sendBuff = Encoding.ASCII.GetBytes(cmd);

                //发送指令数据
                CommandClient.Send(sendBuff);

                //接收返回信息("OK or NG")
                int l;
                byte[] receiveBuff = new byte[1024];
                TimeSpan time = new TimeSpan(0);
                DateTime st = DateTime.Now;
                do
                {
                    //判断暂停
                    while (FlagPaused) Thread.Sleep(10);

                    if (CommandClient.Available > 0)
                    {
                        l = CommandClient.Receive(receiveBuff);
                        response += Encoding.ASCII.GetString(receiveBuff, 0, l);
                        if (response.Contains("OK") || response.Contains("NG")) break;
                    }

                    Thread.Sleep(50);
                    time = time.Add(new TimeSpan(TimeSpan.TicksPerMillisecond * 50));
                    //超时判断
                } while (time.TotalMilliseconds < timeout);

                //执行NG情况
                if (response.Contains("NG")) return false;

                //stream = DataClient.GetStream();
                l = DataClient.Receive(receiveBuff);
                response = Encoding.ASCII.GetString(receiveBuff, 0, l);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        private void ClearReceiveBuff(TcpClient client)
        {
            try
            {
                if (client == null) return;

                byte[] buff = new byte[1024];
                while (client.Available > 0)
                {
                    client.GetStream().Read(buff, 0, 1024);
                    Thread.Sleep(10);
                }
            }
            catch (Exception)
            {

            }

        }

        #endregion
    }

    internal static class EpsonRobotEx
    {
        public static void CheckReturn(this bool res, string message)
        {
            if (!res)
            {
                throw new EpsonRobotExption(message);
            }
        }

        public static void CheckReturn(this bool res)
        {
            CheckReturn(res, "");
        }
    }

    public class EpsonRobotExption : Exception
    {
        public string ErrorMessage { private set; get; }
        public string ErrorCode { private set; get; }

        public EpsonRobotExption(string Message) : base(Message)
        {

        }

        public EpsonRobotExption(int ErrorCode)
        {

        }
    }
}
