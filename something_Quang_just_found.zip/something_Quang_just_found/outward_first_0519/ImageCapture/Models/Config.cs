﻿using AMS.Profile;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Advantech.Common;

namespace ImageCapture.Models
{
    public struct Image
    {
        public string Collection_Image_Path;
        public string Image_temporary_Path;
        public string Log_Path;
        public string Image_Path_After_Inference;
        public string Image_Path_ReadBarcodeImage;
        public string ImageStaging;
        public string Models_Path;
        public string IO_Table;
        public bool Save_Image_After_Inference;
        public bool SaveBigImage;
        public string BigImage;
        public string DAQ;
        public string BarcodeImage;
        public string AOIIPImage;
    }
    public struct IniProducer
    {
        public string ProducerSDK;
        public string DeviceID;
        public string ModuleName;
        public string Station;
        public string Plant;
        public string Line;
        public string Campus;
        public string Product_Name;
        public string DefaultLanguage;
    }
    public struct CamerasSN
    {
        public int CameraDevices;
        public int CameraWidth;
        public int CameraHeight;
        public int Camera1SN;
        public int Camera2SN;
        public int Camera3SN;
    }
    public struct SFISPara
    {
        public string WorkerId;
        public string DeviceId;
        public string ErrorCode;
        public string programId;
        public string programPassword;
        public bool SFISUP;
        public bool ErrorCodeStart;
        public int NumberofRetest;
        public string ErrorCodeContent;
        public string DUTY;
        public string REASON;
    }
    public struct Inference
    {
        public string Inference_Server_IP;
        public string Service_Name;
        public string Service_Token;
        public string Service_Version;
        public string Service_Weight;
        public string CurrentModel;
    }
    public struct ReadBarcode
    {
        public int SNStartBit;
        public int BarcodeLength;
        public string ImageBarcodePoint;
        public int Index;
        public int BarcodeCameraSN;
        public bool CameraBarcode;
        public bool DecodeOpen;
        public bool NoGripTest;
        public string dianchiAOI;
    }
    public struct RobotPara
    {
        public bool Robotopen;
        /// <summary>
        /// 控制器地址
        /// </summary>
        public string Address;
        /// <summary>
        /// 控制端口
        /// </summary>
        public int ControlPort;
        /// <summary>
        /// 指令端口
        /// </summary>
        public int CommandPort;
        /// <summary>
        /// 数据端口
        /// </summary>
        public int DataPort;
        /// <summary>
        /// 连接PLC
        /// </summary>
        public string ModBusIP;
        public int ModBusPort;

        public int ProgramId;
        public int SpeedHigh;
        public int SpeedLow;
        public string Production;
        public int PCBValue;
    }

    public class ConfigStruct
    {
        public Image Image;
        public IniProducer iniProducer;
        public SFISPara SFIS;
        public Inference Inference;
        public CamerasSN Camerai;
        public RobotPara Robot;
        public ReadBarcode ReadBarcode;
        private AMS.Profile.Registry reg;
        public ConfigStruct()
        {
            reg = new Registry();
            reg.RootKey = Microsoft.Win32.Registry.CurrentUser;
            reg.Name = string.Format(@"Software\CPEAuto\AGVCallCarHelper");
        }
        
        [JsonIgnore]
        public int CountPass
        {
            set { reg.SetValue("Count", "Pass", value); }
            get { return reg.GetValue("Count", "Pass", 0); }
        }
        [JsonIgnore]
        public int CountFail
        {
            set { reg.SetValue("Count", "Fail", value); }
            get { return reg.GetValue("Count", "Fail", 0); }
        }
        [JsonIgnore]
        public double PassYield
        {
            get { return CountPass / (CountPass + CountFail); }
        }
        [JsonIgnore]
        public bool SfisEnable
        {
            get { return reg.GetValue("Station", "Sfis", false); }
            set { reg.SetValue("Station", "Sfis", value); }
        }
        [JsonIgnore]
        public string Product
        {
            get { return reg.GetValue("Station", "Product", ""); }
            set { reg.SetValue("Station", "Product", value); }
        }
        [JsonIgnore]
        public string LastISN
        {
            get { return reg.GetValue("Station", "LastISN", ""); }
            set { reg.SetValue("Station", "LastISN", value); }
        }
        [JsonIgnore]
        public string LastTaskId
        {
            get { return reg.GetValue("Station", "LastTaskId", ""); }
            set { reg.SetValue("Station", "LastTaskId", value); }
        }
        [JsonIgnore]
        public string LastCarId
        {
            get { return reg.GetValue("Station", "LastCarId", ""); }
            set { reg.SetValue("Station", "LastCarId", value); }
        }
        [JsonIgnore]
        public int LastPickIndex
        {
            get { return reg.GetValue("Station", "LastPickIndex", 0); }
            set { reg.SetValue("Station", "LastPickIndex", value); }
        }
        [JsonIgnore]
        public int LastPlaceIndex
        {
            get { return reg.GetValue("Station", "LastPlaceIndex", 0); }
            set { reg.SetValue("Station", "LastPlaceIndex", value); }
        }
        [JsonIgnore]
        public int ProductCount
        {
            get { return reg.GetValue("Count", "ProductCount", 0); }
            set { reg.SetValue("Count", "ProductCount", value); }
        }
        [JsonIgnore]
        public string CarTaskStep
        {
            get { return reg.GetValue("Station", "CarTaskStep", ""); }
            set { reg.SetValue("Station", "CarTaskStep", value); }
        }

    }
    public static class Config
    {
        public static ConfigStruct Content;
        static string file = string.Empty;

        public static void Load()
        {
            try
            {
                string defaultfile = Path.Combine(Application.StartupPath, "Config.Json");
                file = Path.Combine(Application.StartupPath, @"..\data\Config.Json");

                if (!File.Exists(file))
                {
                    if (!Directory.Exists(Path.GetDirectoryName(file)))
                    {
                        Directory.CreateDirectory(Path.GetDirectoryName(file));
                    }

                    if (File.Exists(defaultfile))
                    {
                        File.Copy(defaultfile, file);
                    }
                    else
                    {
                        File.WriteAllText(file, JsonConvert.SerializeObject(new ConfigStruct()));
                    }
                }

                Content = JsonConvert.DeserializeObject<ConfigStruct>(File.ReadAllText(file));
            }
            catch (Exception)
            {
                throw;
            }


        }

        public static void Write()
        {
            try
            {
               // File.WriteAllText(file, JsonConvert.SerializeObject(Content).Formarjson());
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
