﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using pegatron.basic;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.UI;
using System.IO;
using System.Configuration;
using System.Diagnostics;
using System.Threading;
using AdvantechIOCard;
using System.Threading.Tasks;
using System.Timers;
using Basler;
using InferenceAPI;
using pegatron.SMT.basic;
using ImageCapture.Models;
using MotionControlCard;
using System.Drawing.Printing;
using ImageCapture.Enumes;
using ZXing;
using Basler.Pylon;
using System.Drawing.Imaging;

namespace ImageCapture
{
    public enum Test_Step
    {
        wait_dut_in,
        clamp_dut,
        read_barcode,
        first_capture,
        second_capture,
        rotarymechanism_go_final_pisition,
        wait_xzmechanism_vacuum_reach,
        third_capture,
        //xzmechanism_relax_dut,
        //xzmechanism_dut_relax_finish,
        //begin_test,
        //testing,
        wait_predict_result,
        test_finish,
        test_Fail,
        ConveyorMode,
        xzmechanism_relax_dut,
        xzmechanism_dut_relax_finish,
        
        error
    }

    public partial class EdgeToolForm : Form
    {

        //int current_image;
        bool AllowCaptureForPredict { get; set; } = false;
        //bool imageUploadAuto { get; set; } = true;
        Stopwatch stopWatch = new Stopwatch();
        Inference_Server predictor;
        //M2MProducer2 m2m;
        //ProducerMode mode = ProducerMode.online;
        pegatronLog log = null;
        //Screenshot_Area r1 = new Screenshot_Area();
        //Object syncObject = new object();
        BaslerVideoCapture[] caps = null;
        BaslerVideoCapture selectedCapture;
        //Reader barcodescanner;
        List<Small_Image> small_images;
        //InputControl dut_arrive;
        //OutputControl aoi_ready;
        //OutputControl test_finish;
        bool collectImage = false;
        IOCardCollection iocards;
        Test_Step current_step;
        ColorLight ColorLight;
        System.Timers.Timer TaskTimer = new System.Timers.Timer(50);
        System.Timers.Timer EmergencyTimer = new System.Timers.Timer(20);
        System.Timers.Timer failTrayTimer = new System.Timers.Timer();
        ManualResetEvent waitCapture = new ManualResetEvent(true);
        //string CollectImagePath = @"E:\Collect_Image\";
        TabPage preTabPage = null;
        public int Motor_Move_Distance { get; set; }
        int[] CaptureDelay;
        public Velocity Velocity { get; set; } = Velocity.Low;
        public bool IsPause { get; private set; } = false;
        public bool IsRunning { get; private set; } = false;
        public bool StopEmergencyTask { get; private set; } = false;
        public bool Test_Barcode { get; private set; } = true;
        public bool TestFinish { get; private set; } = true;
        public bool infra_screw { get; private set; } = true;
        public int CountPass { get; private set; }
        public int CountFail { get; private set; }
        public string SFISmsg = "";
        SFISHelper SFIS = new SFISHelper();
        OutwardConfiguration cfg;
        #region 輸入IO
        InputControl EmergencySensor;
        InputControl DoorSensor;
        InputControl PlacePASSDUT;
        InputControl YellowInputButton;
        InputControl GreenInputButton;
        InputControl RedInputButton;
        InputControl LightCurtainSensor;
        #endregion
        ControlCard ControlCard;
        #region 機構裝置
        RotaryMechanism RotaryMechanism;
        XZMechanism XZMechanism;
        ConveyorMechanism ConveyorMechanism;
        UpDownMechanism UpDownMechanism;
        OutputMechanism OutputMechanism;
        #endregion
        CaptureMechanism LeftCaptureMechanism;
        CaptureMechanism RightCaptureMechanism;
        DecisionMechanism DecisionMechanism;
        //Small_Image small_Image;
        //SingleAxis SelectedX = null;
        //SingleAxis SelectedZ = null;
        IMotorInterface selectedMechanism = null;
        int selectedMotorIndex = -1;
        ProductOutward PO = null;
        TestMode RunMode = TestMode.Test_Mode;
        string timera = "";
        //string ReadBarcodeIsn = "";
        public static string ReadBarcodeIsn;
        public string ReadBarcodeIsn1 = "";
        //public int ReadBarcodei=0; 
        //Velocity VelocityMode = Velocity.Low;
        public EdgeToolForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageForm iniMessageForm = new MessageForm();
            iniMessageForm.SetMessage("Start Initial...");
            iniMessageForm.Show();
            #region Create Configuration
            string cfgFullPath = ConfigurationManager.AppSettings["Config_File_Path"];
            if (File.Exists(cfgFullPath)) cfg = new OutwardConfiguration(cfgFullPath);
            else
            {
                iniMessageForm.Close();
                MessageBox.Show("設定檔開啟錯誤", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            #endregion
            #region Create LOG檔
            if (!Directory.Exists(cfg.LogPath)) Directory.CreateDirectory(cfg.LogPath);
            string logDir = Path.Combine(cfg.LogPath, $"{DateTime.Now.ToString("yyyyMMdd")}");
            if (!Directory.Exists(logDir)) Directory.CreateDirectory(logDir);
            log = new pegatronLog(Path.Combine(logDir, $"log{DateTime.Now:yyyyMMddHHmmss}.txt"));
            log.write($"Application Start({Application.ProductVersion})");
            #endregion

            #region 初始化IO
            iniMessageForm.SetMessage("Initial DAQ...");

            if (!iniIOcard())
            {
                iniMessageForm.Close();
                MessageBox.Show("IO 卡初始化錯誤", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            log.write("IO Card initial PASS.");
            #endregion
            ColorLight.ControlLightOff();
            
            #region 初始化Motor
            iniMessageForm.SetMessage("Initial MotorControl...");
            if (!InitMotionCard())
            {
                iniMessageForm.Close();
                MessageBox.Show("Motor控制卡初始化錯誤", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            log.write("Motor Control 卡初始化完成");
            #endregion
            #region 旋轉裝置
            iniMessageForm.SetMessage("Initial Rotary Mechanism...");
            RotaryMechanism = new RotaryMechanism(iocards,
                ControlCard.Axis_Handles[cfg.RotaryMechanism_Rotary_Motor_Handle],
                ControlCard.Axis_Handles[cfg.RotaryMechanism_Shift_Motor_Handle]);
            if (!RotaryMechanism.Initial(cfg.RotaryMechanism_High_Velocity,
                cfg.RotaryMechanism_Medium_Velocity,
                cfg.RotaryMechanism_Low_Velocity))
            {
                iniMessageForm.Close();
                MessageBox.Show("旋轉裝置初始化錯誤", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            log.write("Rotary Mechanism 初始化完成");
            #endregion
            #region XZ機構
            iniMessageForm.SetMessage("Initial X-Z Mechanism...");
            XZMechanism = new XZMechanism(iocards,
                ControlCard.Axis_Handles[cfg.XZMechanism_X_Motor_Handle],
                ControlCard.Axis_Handles[cfg.XZMechanism_Z_Motor_Handle]);
            if (!XZMechanism.Initial(cfg.XZMechanism_High_Velocity,
                cfg.XZMechanism_Medium_Velocity,
                cfg.XZMechanism_Low_Velocity))
            {
                iniMessageForm.Close();
                MessageBox.Show("XZ裝置初始化錯誤", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            log.write("XZ Mechanism 初始化完成");
            #endregion
            #region 皮帶線
            iniMessageForm.SetMessage("Initial Conveyor...");
            ConveyorMechanism = new ConveyorMechanism(iocards);
            if (!ConveyorMechanism.Initial())
            {
                iniMessageForm.Close();
                MessageBox.Show("皮帶線初始化錯誤", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            log.write("Conveyor 初始化完成");
            #endregion
            #region Up-Down Mechanism
            //iniMessageForm.SetMessage("Initial 升降機構...");
            UpDownMechanism = new UpDownMechanism(iocards);
            if (!UpDownMechanism.Initial())
            {
                iniMessageForm.Close();
                MessageBox.Show("升降機構初始化錯誤", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            //log.write("升降機構 初始化完成");
            #endregion
            #region Fail Area
            iniMessageForm.SetMessage("Initial 輸出機構...");
            OutputMechanism = new OutputMechanism(iocards);
            if (!OutputMechanism.Initial())
            {
                iniMessageForm.Close();
                MessageBox.Show("輸出機構初始化錯誤", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            log.write("Output Mechanism 初始化完成");
            if (cfg.DecisionMechanismEnable) DecisionMechanism = new DecisionMechanism(ConveyorMechanism, UpDownMechanism, OutputMechanism, cfg);
            #endregion
            #region Camera
            iniMessageForm.SetMessage("Initial Camera...");
            var devices = EnumAllBaslerCameras.ListCameras();
            if (devices.Count != 4)
            {
                iniMessageForm.Close();
                MessageBox.Show("相機初始化錯誤", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            else
            {
                caps = new BaslerVideoCapture[devices.Count];
                CaptureDelay = new int[devices.Count];
                //predict_temporary_path = new string[devices.Count];++
                string dir1 = cfg.ImagePath;
                if (!Directory.Exists(dir1)) Directory.CreateDirectory(dir1);
                boxes = new List<ImageBox>() { imageBox2, imageBox5, imageBox6, imageBox3, imageBox7, imageBox8 };
                string dir = cfg.Image_temporary_Path;
                try
                {
                    if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                    //int index = 0;
                    for (int i = 0; i < devices.Count; i++)
                    {
                        selectedCapture = new BaslerVideoCapture(devices[i]);

                        if (cfg.Top_Capture_Serial == selectedCapture.serial)
                        {
                            caps[0] = selectedCapture;
                            selectedCapture.Open(cfg.Top_Capture_Width, cfg.Top_Capture_Height);
                            boxes[0].Name = $"{selectedCapture.serial}_0";
                            //index = 0;
                            string cap_inference_tempPath = Path.Combine(dir, $"{selectedCapture.serial}_{0}");
                            if (!Directory.Exists(cap_inference_tempPath)) Directory.CreateDirectory(cap_inference_tempPath);
                            else
                            {
                                foreach (string f in Directory.GetFiles(cap_inference_tempPath))
                                {
                                    File.Delete(f);
                                }
                            }
                            predict_result.Add($"{selectedCapture.serial}_{0}", null);
                            //selectedCapture.width = cfg.Top_Capture_Width;
                            //selectedCapture.height = cfg.Top_Capture_Height;
                            CaptureDelay[0] = cfg.Top_Capture_Delay;
                        }
                        else if (cfg.Bottom_Capture_Serial == selectedCapture.serial)
                        {
                            caps[1] = selectedCapture;
                            selectedCapture.Open(cfg.Bottom_Capture_Width, cfg.Bottom_Capture_Height);
                            boxes[5].Name = $"{selectedCapture.serial}_0";
                            string cap_inference_tempPath = Path.Combine(dir, $"{selectedCapture.serial}_{0}");
                            if (!Directory.Exists(cap_inference_tempPath)) Directory.CreateDirectory(cap_inference_tempPath);
                            else
                            {
                                foreach (string f in Directory.GetFiles(cap_inference_tempPath))
                                {
                                    File.Delete(f);
                                }
                            }
                            predict_result.Add($"{selectedCapture.serial}_{0}", null);
                            //selectedCapture.width = cfg.Bottom_Capture_Width;
                            //selectedCapture.height = cfg.Bottom_Capture_Height;
                            CaptureDelay[1] = cfg.Bottom_Capture_Delay;
                        }
                        else if (cfg.Left_Capture_Serial == selectedCapture.serial)
                        {
                            caps[2] = selectedCapture;
                            selectedCapture.Open(cfg.Left_Capture_Width, cfg.Left_Capture_Height);
                            boxes[1].Name = $"{selectedCapture.serial}_0";
                            boxes[3].Name = $"{selectedCapture.serial}_1";
                            //selectedCapture.width = cfg.Left_Capture_Width;
                            //selectedCapture.height = cfg.Left_Capture_Height;
                            CaptureDelay[2] = cfg.Left_Capture_Delay;
                            LeftCaptureMechanism = new CaptureMechanism(
                                selectedCapture,
                                ControlCard.Axis_Handles[cfg.Left_Motor_Handle],
                                "Cap_Left");
                            string cap_inference_tempPath = Path.Combine(dir, $"{selectedCapture.serial}_{0}");
                            if (!Directory.Exists(cap_inference_tempPath)) Directory.CreateDirectory(cap_inference_tempPath);
                            else
                            {
                                foreach (string f in Directory.GetFiles(cap_inference_tempPath))
                                {
                                    File.Delete(f);
                                }
                            }
                            predict_result.Add($"{selectedCapture.serial}_{0}", null);
                            cap_inference_tempPath = Path.Combine(dir, $"{selectedCapture.serial}_{1}");
                            if (!Directory.Exists(cap_inference_tempPath)) Directory.CreateDirectory(cap_inference_tempPath);
                            else
                            {
                                foreach (string f in Directory.GetFiles(cap_inference_tempPath))
                                {
                                    File.Delete(f);
                                }
                            }
                            predict_result.Add($"{selectedCapture.serial}_{1}", null);
                            if (!LeftCaptureMechanism.Initial(cfg.Left_High_Velocity,
                                cfg.Left_Medium_Velocity, cfg.Left_Low_Velocity))
                            {
                                iniMessageForm.Close();
                                MessageBox.Show("相機帶動馬達初始化失敗!!", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                this.Close();
                                return;
                            }
                        }
                        else if (cfg.Right_Capture_Serial == selectedCapture.serial)
                        {
                            caps[3] = selectedCapture;
                            //selectedCapture.width = cfg.Right_Capture_Width;
                            //selectedCapture.height = cfg.Right_Capture_Height;
                            selectedCapture.Open(cfg.Right_Capture_Width, cfg.Right_Capture_Height);
                            boxes[2].Name = $"{selectedCapture.serial}_0";
                            boxes[4].Name = $"{selectedCapture.serial}_1";
                            CaptureDelay[3] = cfg.Right_Capture_Delay;
                            string cap_inference_tempPath = Path.Combine(dir, $"{selectedCapture.serial}_{0}");
                            if (!Directory.Exists(cap_inference_tempPath)) Directory.CreateDirectory(cap_inference_tempPath);
                            else
                            {
                                foreach (string f in Directory.GetFiles(cap_inference_tempPath))
                                {
                                    File.Delete(f);
                                }
                            }
                            predict_result.Add($"{selectedCapture.serial}_{0}", null);
                            cap_inference_tempPath = Path.Combine(dir, $"{selectedCapture.serial}_{1}");
                            if (!Directory.Exists(cap_inference_tempPath)) Directory.CreateDirectory(cap_inference_tempPath);
                            else
                            {
                                foreach (string f in Directory.GetFiles(cap_inference_tempPath))
                                {
                                    File.Delete(f);
                                }
                            }
                            predict_result.Add($"{selectedCapture.serial}_{1}", null);
                            RightCaptureMechanism = new CaptureMechanism(
                                selectedCapture,
                                ControlCard.Axis_Handles[cfg.Right_Motor_Handle],
                                "Cap_Right");
                            if (!RightCaptureMechanism.Initial(cfg.Right_High_Velocity,
                                cfg.Right_Medium_Velocity, cfg.Right_Low_Velocity))
                            {
                                iniMessageForm.Close();
                                MessageBox.Show("相機帶動馬達初始化失敗!!", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                this.Close();
                                return;
                            }
                        }




                        //predict_temporary_path[i] = dir;

                        //string predict_temporary_path = Path.Combine(cfg.Image_temporary_Path, $"{}_{}"cap[i].serial.ToString());

                    }
                }
                catch
                {
                    MessageBox.Show("相機初始化失敗", "Initial", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                    return;
                }

            }

            #endregion

            #region Inference Engine
            if (!Init_Inference_SDK())
            {
                iniMessageForm.Close();
                MessageBox.Show("推論引擎初始化失敗", "Initial Inference", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
            #endregion

            if (cfg.Save_images_after_predict)
            {
                if (!Directory.Exists(cfg.Image_Path_After_Inference)) Directory.CreateDirectory(cfg.Image_Path_After_Inference);
            }
            iniMessageForm.SetMessage("馬達歸零中...");
            //LeftCaptureMechanism.ResetError();
            //RightCaptureMechanism.ResetError();
            LeftCaptureMechanism.Home();
            RightCaptureMechanism.Home();


            TimeCounter t1 = new TimeCounter(40 * 1000);
            if (t1.Start(() => LeftCaptureMechanism.Ready() && RightCaptureMechanism.Ready(), true))
            {
                //RotaryMechanism.ResetError();
                //XZMechanism.ResetError();
                LeftCaptureMechanism.ResetPosition();
                RightCaptureMechanism.ResetPosition();
                RotaryMechanism.Home();
                XZMechanism.Home();
            }
            else
            {
                iniMessageForm.Close();
                MessageBox.Show("相機馬達歸零失敗!!", "Motor go home", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            t1 = new TimeCounter(40 * 1000);
            if (t1.Start(() => RotaryMechanism.Ready() && XZMechanism.Ready(), true))
            {
                RotaryMechanism.ResetPosition();
                XZMechanism.ResetPosition();
                Product_Name = cfg.CurrentModel;
                small_images = new List<Small_Image>();

                cbDevice.SelectedIndexChanged -= cbDevice_SelectedIndexChanged;
                cbDevice.DataSource = caps;
                cbDevice.DisplayMember = "serial";
                cbDevice.SelectedIndexChanged += cbDevice_SelectedIndexChanged;
                string current_model = cfg.CurrentModel;
                LoadParameters(current_model);
                try
                {
                    if (PO != null)
                    {
                        LeftCaptureMechanism.AbsoluteMove(PO.LeftCapture_X_Position, 0);
                        RightCaptureMechanism.AbsoluteMove(PO.RightCapture_X_Position, 0);
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "馬達運動", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                tslProduct_Name.Text = $"當前運行機種: {cfg.CurrentModel}";
                splitContainer1.SplitterDistance = this.Width / 4;

                //barcodescanner = new Reader(ConfigurationManager.AppSettings["BarcodeScanner"]);
                //barcodescanner.GetReaderReadResult += GetBarcode;
                current_step = Test_Step.wait_dut_in;
                // CheckForIllegalCrossThreadCalls = false;
                iniMessageForm.Close();
            }
            else
            {
                iniMessageForm.Close();
                if (!RotaryMechanism.Ready())
                {
                    MessageBox.Show("旋轉機構馬達歸零失敗!!", "Motor go home", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("XZ機構馬達歸零失敗!!", "Motor go home", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return;
            }
            SFIS.Login(cfg.DeviceId, cfg.WorkerId, cfg.programId, cfg.programPassword);
            failTrayTimer.Elapsed += new ElapsedEventHandler(FailTrayTimer);
            failTrayTimer.Interval = 800;
            failTrayTimer.Enabled = false;


        }

        private bool Init_Inference_SDK()
        {
            try
            {
                string service_name = cfg.Service_Name;
                string service_token = cfg.Service_Token;
                string service_version = cfg.Service_Version;
                string service_weight = cfg.Service_Weight;
                string ip = cfg.Inference_IP;
                if (string.IsNullOrEmpty(service_name) || string.IsNullOrEmpty(service_token) || string.IsNullOrEmpty(ip)) return false;
                InferenceServerConnected recallback = new InferenceServerConnected(x =>
                  {
                      predictor = x;
                      if (predictor != null)
                      {
                          this.BeginInvoke(new Action(() =>
                          {
                              this.Text += $"\rInference Model:{predictor.model_information.models[0].name}";
                              this.Text += $"\rModel Version:{predictor.model_information.models[0].version}";
                              this.Text += $"\rEdge Tool Version:{Application.ProductVersion}";
                          }));
                      } 
                  });
                Inference_Server.CreateInferenceInstance(
                    ip,
                    service_name,
                    service_token,
                    service_version,
                    service_weight,
                    recallback);
                return true;
            }
            catch (Exception ex)
            {
                log?.wrieException(ex);
                return false;
            }
            //if (log != null) log.write("Initial Predict SDK completely.");
        }

        private bool iniIOcard()
        {
            try
            {
                if (File.Exists(cfg.IO_Table_Path))
                {
                    iocards = new IOCardCollection(cfg.IO_Table_Path);

                    if (iocards.AddNewCard(cfg.DAQ))
                    {
                        DoorSensor = new InputControl(iocards, "DoorSensor");
                        EmergencySensor = new InputControl(iocards, "Emergency_Stop");
                        LightCurtainSensor = new InputControl(iocards, "LightCurtain");
                        ColorLight = new ColorLight(iocards);
                        PlacePASSDUT = new InputControl(iocards, "InputSignal_PlaceDut");
                        YellowInputButton = new InputControl(iocards, "InputSignal_YellowButton");
                        GreenInputButton = new InputControl(iocards, "InputSignal_GreenButton");
                        RedInputButton = new InputControl(iocards, "InputSignal_RedButton");
                        //aoi_ready = new OutputControl(iocards, "AOI_Ready");
                        //aoi_ready.WriteState(true);
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
                else
                {
                    log.write($"{cfg.IO_Table_Path} is not exist.");
                    return false;
                }
            }
            catch (Exception ex)
            {
                log?.wrieException(ex);
                return false;
            }
        }
        private bool InitMotionCard()
        {
            try
            {
                ControlCard = new ControlCard((uint)cfg.Motion_Card_Device_Number);
                if (ControlCard.InitCard(cfg.MotionCardConfig))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                log?.wrieException(ex);
                return false;
            }
        }

        private void LoadParameters(string current_model)
        {
            log.write($"LOAD Model:{current_model}");
            if (!string.IsNullOrEmpty(current_model) && File.Exists(Path.Combine(cfg.Models_Path, $"{current_model}.XML")))
            {
                PO = XMLHelper.Create<ProductOutward>(Path.Combine(cfg.Models_Path, $"{current_model}.XML"));
                if (PO != null)
                {
                    Product_Name = PO.Name;
                    cfg.CurrentModel = Product_Name;
                    ROIS = PO.ROIs;
                    lbModelName.Text = PO.Name;
                    ReflashMotorUIPosition();
                    log.write("Load Model successfully.");
                }
                else
                {
                    log.write("Load Model fail.");
                }
            }
            else
            {
                log.write($"Load Model fail.(current model:{current_model}, File:{Path.Combine(cfg.Models_Path, $"{current_model}.XML")})");
                PO = null;
                ROIS = null;
            }

        }

        private void GetBarcode(string barcode)
        {

        }


        private void Cap_CamImageReady(object sender, Bitmap bmp)
        {
            Emgu.CV.IImage oldImage = null;
            try
            {
                Image<Rgb, byte> img = new Image<Rgb, byte>(bmp);//new Image<Rgb, byte>(bmp);
                if (AllowCaptureForPredict&&!cfg.BigImage)
                {
                    Thread th = new Thread(new ParameterizedThreadStart(P));
                    th.IsBackground = true;
                    th.Start(new object[] { new Image<Rgb, byte>(bmp), ((BaslerVideoCapture)sender).serial, ((BaslerVideoCapture)sender).index });
                    AllowCaptureForPredict = false;
                    waitCapture.Set();
                }
                else if(AllowCaptureForPredict&&cfg.BigImage)
                {
                    Thread th = new Thread(new ParameterizedThreadStart(P));
                    th.IsBackground = true;
                    th.Start(new object[] { new Image<Rgb, byte>(bmp), ((BaslerVideoCapture)sender).serial, ((BaslerVideoCapture)sender).index });
                    AllowCaptureForPredict = false;
                    waitCapture.Set();
                    
                    Thread.Sleep(500);
                    Thread th1 = new Thread(new ParameterizedThreadStart(CaptureImageOnlyCollection1));
                    th1.Start(new object[] { img.Bitmap, DateTime.Now.ToString("yyyyMMddHHmmssff"), ((BaslerVideoCapture)sender).serial, ((BaslerVideoCapture)sender).index });
                    ImageBox box = boxes.Where(x => x.Name.Equals($"{((BaslerVideoCapture)sender).serial}_{((BaslerVideoCapture)sender).index}")).First();
                    Emgu.CV.IImage iimg = box.Image;
                    //box.Image = img.Resize(320, 240, Emgu.CV.CvEnum.Inter.Linear);
                    //if (iimg != null) iimg.Dispose();
                }
                else if (collectImage)
                {
                    collectImage = false;
                    Thread th = new Thread(new ParameterizedThreadStart(CaptureImageOnlyCollection));
                    th.Start(new object[] { img.Bitmap, DateTime.Now.ToString("yyyyMMddHHmmssff"), ((BaslerVideoCapture)sender).serial, ((BaslerVideoCapture)sender).index });
                    ImageBox box = boxes.Where(x => x.Name.Equals($"{((BaslerVideoCapture)sender).serial}_{((BaslerVideoCapture)sender).index}")).First();
                    Emgu.CV.IImage iimg = box.Image;
                    box.Image = img.Resize(320, 240, Emgu.CV.CvEnum.Inter.Linear);
                    if (iimg != null) iimg.Dispose();
                }
                if (displayROI && selectedROI != null)//setting
                {
                    img.Draw(new Rectangle(selectedROI.x, selectedROI.y, selectedROI.width, selectedROI.height), new Rgb(255, 255, 0), 8);
                }

                if (img != null)
                {
                    if (isSetting)
                    {
                        oldImage = imageBox4.Image;
                        imageBox4.Image = img;
                        //if(iimg!=null) iimg.Dispose();
                    }
                    else
                    {
                        //oldImage = imageBox1.Image;
                        //imageBox1.Image = img.Resize(800, 600, Emgu.CV.CvEnum.Inter.Linear);
                        img.Dispose();
                    }
                    //img.Dispose();
                }
                if (oldImage != null) oldImage.Dispose();
            }
            catch (Exception ex)
            {
                log.write($"Capture image exception---");
                log.write(ex.Message);
                log.write(ex.StackTrace);
                MessageBox.Show(ex.Message, "Cap_CamImageReady", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            //bmp.Dispose();
        }
        private void Cap_CamImageReady1(object sender, Bitmap bmp)
        {
            Emgu.CV.IImage oldImage = null;
            try
            {
                Image<Rgb, byte> img = new Image<Rgb, byte>(bmp);
                if (AllowCaptureForPredict)
                {
                    Thread th = new Thread(new ParameterizedThreadStart(P1));
                    th.IsBackground = true;
                    th.Start(new object[] { new Image<Rgb, byte>(bmp), ((BaslerVideoCapture)sender).serial, ((BaslerVideoCapture)sender).index });
                    AllowCaptureForPredict = false;
                    waitCapture.Set();
                }
                if (displayROI && selectedROI != null)//setting
                {
                    img.Draw(new Rectangle(selectedROI.x, selectedROI.y, selectedROI.width, selectedROI.height), new Rgb(255, 255, 0), 8);
                }

                if (oldImage != null) oldImage.Dispose();
            }
            catch (Exception ex)
            {
                log.write($"Capture image exception---");
                log.write(ex.Message);
                log.write(ex.StackTrace);
                MessageBox.Show(ex.Message, "Cap_CamImageReady", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void P(object data)
        {
            object[] o = data as object[];
            Image<Rgb, byte> img = o[0] as Image<Rgb, byte>;
            int serial = (int)o[1];
            int index = (int)o[2];
            List<Small_Image> images = null;
            using (img)
            {

                try
                {
                    string predict_temporary_path = Path.Combine(cfg.Image_temporary_Path, $"{serial}_{index}");
                    images = img.Capture(ROIS.Where(r => r.serial == serial && r.index == index).ToList(), predict_temporary_path);
                    log.write("圖片保存完成");
                    all_small_images.Add(images);
                    
                    foreach (Small_Image small_image in images)
                    {
                        //#if DEBUG
                        //                    Random random = new Random();
                        //                    int delay = random.Next(100);
                        //                    Thread.Sleep(delay);
                        //                    if (index == 2 && small_image == images[1]) small_image.predictResult = "FAIL";
                        //                    else small_image.predictResult = "PASS";
                        //#else
                        Predict(small_image);
                        //#endif
                    }
                    log.write("圖片推論完成");
                    Emgu.CV.UI.ImageBox box = boxes.Where(x => x.Name == $"{serial}_{index}").First();
                    if (images.All(x => x.predictResult == "PASS"))
                    {
                        if (img.Width == 3840)
                        {
                            img.Draw(message: "PASS",
                            bottomLeft: new Point(img.Width / 2 - 500, img.Height / 2),
                            fontFace: Emgu.CV.CvEnum.FontFace.HersheySimplex,
                            color: new Rgb(0, 255, 0),
                            thickness: 15,
                            fontScale: 15.0);
                        }
                        else
                        {
                            img.Draw(message: "PASS",
                            bottomLeft: new Point(img.Width / 2 - 200, img.Height / 2),
                            fontFace: Emgu.CV.CvEnum.FontFace.HersheySimplex,
                            color: new Rgb(0, 255, 0),
                            thickness: 15,
                            fontScale: 10.0);
                        }

                        predict_result[$"{serial}_{index}"] = "PASS";
                    }
                    else
                    {
                        predict_result[$"{serial}_{index}"] = "FAIL";
                        ParallelLoopResult result = Parallel.For(0, images.Count, i =>
                        {
                            if (images[i].predictResult == "PASS")
                            {
                                //img.Draw(images[i].r, new Rgb(0, 255, 0), 8);
                            }
                            else
                            {
                                //if (images[i].r.Width>24 && images[i].r.Height > 24)
                                //{

                                //}
                                img.Draw(images[i].r, new Rgb(255, 0, 0), 12);
                                log.write($"X={images[i].r.X},Y={images[i].r.Y},Width={images[i].r.Width},height={images[i].r.Height}");
                            }


                        });
                    }
                    this.Invoke(new Action(() =>
                    {
                        box.Image = img.Resize(320, 240, Emgu.CV.CvEnum.Inter.Linear);
                        box.Refresh();
                    }
                    ));
                }
                catch (Exception ex)
                {
                    log.wrieException(ex);
                    throw ex;
                }


                //if (small_images.All(x => x.predictResult == "Pass"))
                //{
                //    UpdateMsg("Pass", Color.Green);
                //    SaveBigImage(isn, "Pass");
                //}
                //else
                //{
                //    UpdateMsg("NG", Color.Red);
                //    SaveBigImage(isn, "NG");
                //}
                //UpdateStatus($"检查完成，CycleTime:{stopWatch.ElapsedMilliseconds} msec", Color.Blue);

            }

        }
        private void P1(object data)
        {
            object[] o = data as object[];
            Image<Rgb, byte> img = o[0] as Image<Rgb, byte>;
            int serial = (int)o[1];
            int index = (int)o[2];
            List<Small_Image> images = null;
            using (img)
            {

                try
                {
                    string predict_temporary_path = Path.Combine(cfg.ImagePath/*, $"{serial}_{index}"*/);
                    images = img.Capture(ROIS.Where(r => r.serial == serial && r.index == index).ToList(), predict_temporary_path);
                    log.write("圖片保存完成");
                }
                catch (Exception ex)
                {
                    log.wrieException(ex);
                    throw ex;
                }
            }

        }
        public void UpdateStatus(string msg, Color color)
        {
            this.Invoke(new Action<string, Color>((x, y) =>
            {

                tsslStatus.Text = msg;
                tsslStatus.ForeColor = color;

            }), new object[] { msg, color });
        }
        public void UpdateMsg(string msg, Color color)
        {
            this.Invoke(new Action<string, Color>((x, y) =>
            {
                lbPredictionResult2.Text = msg;
                lbPredictionResult2.BackColor = color;
                lbPredictionResult2.ForeColor = Color.White;
            }), new object[] { msg, color });
        }

        //private void SaveBigImage(string ISN, string result)
        //{
        //    try
        //    {
        //        string path = @"E:\4027_Images";
        //        if (!Directory.Exists(path))
        //            Directory.CreateDirectory(path);
        //        path = Path.Combine(path, $"{DateTime.Now:yyyyMMdd}");
        //        if (!Directory.Exists(path))
        //            Directory.CreateDirectory(path);
        //        Bitmap bmp = imageBox2.Image.Bitmap.Clone() as Bitmap;
        //        Image<Bgr, byte> big_image = new Image<Bgr, byte>(bmp);
        //        big_image.ROI = r1.r;
        //        big_image.Save(Path.Combine(path, $"{ISN}_{result}.jpg"));
        //        bmp.Dispose();
        //        big_image.Dispose();
        //    }
        //    catch(Exception ex)
        //    {
        //        log.write($"Save image exception---");
        //        log.write(ex.Message);
        //        log.write(ex.StackTrace);
        //    }
        //}


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (selectedCapture != null && selectedCapture.IsOpen)
            {
                selectedCapture.CamImageReady -= Cap_CamImageReady;

                //cap1.OneShot();
                //Thread.Sleep(10);
                selectedCapture.Stop();

                //cap1.Dispose();
            }
            //cbDevice.DataSource = null;
            if (caps != null)
            {
                foreach (BaslerVideoCapture cap1 in caps)
                {
                    //if (cap != null && cap.IsOpen)
                    //{
                    //cap.Stop();
                    //Thread.Sleep(50);
                    //cap.CamImageReady -= Cap_CamImageReady;
                    ////Thread.Sleep(50);
                    ////cap.Stop();
                    //cap.Dispose();
                    //}
                    //else if (cap != null)
                    //{
                    if (cap1 != null)
                    {
                        cap1.CamImageReady -= Cap_CamImageReady;
                        cap1.Dispose();
                    }

                    //}
                }
            }
            Light(false);
            RotaryMechanism?.Dispose();
            XZMechanism?.Dispose();


            // barcodescanner.GetReaderReadResult -= GetBarcode;
            //if (barcodescanner != null) barcodescanner.Dispose();
        }


        
        public void UpdateProducerResponse(string msg, Color color)
        {
            this.Invoke(new Action<string, Color>((x, y) =>
            {

                tsslM2MResponse.Text = msg;
                tsslM2MResponse.ForeColor = color;

            }), new object[] { msg, color });
        }


        //private void F_UpdatePosition(Screenshot_Area positions)
        //{
        //    r1 = positions;
        //}

        private bool CameraCapture(BaslerVideoCapture cap)
        {
            log.write($"{cap.serial}_{cap.index} allow capture.");
            //AllowCaptureForPredict = true;
            if (RunMode == TestMode.Test_Mode) AllowCaptureForPredict = true;
            else collectImage = true;
            waitCapture.Reset();
            cap.CamImageReady += Cap_CamImageReady;
            cap.OneShot();
            waitCapture.WaitOne(5000);
            //if ((cap.serial == cfg.BarcodeCameraSN) && cfg.CameraBarcode)
            //{
            //    ReadBarcode();
            //}
            if ((RunMode == TestMode.Test_Mode ? AllowCaptureForPredict : collectImage) == false)
            {
                log.write($"{cap.serial}_{cap.index} capture finish.");
                cap.CamImageReady -= Cap_CamImageReady;
                Thread.Sleep(500);
                log.write($"{cap.serial}_關閉相機");
                cap.Stop();
                return true;
            }
            else//capture time out
            {
                log.write($"{cap.serial}_{cap.index} capture time out.");
                UpdateStatus($"camera:{cap.serial} capture image time out.", Color.Red);
                cap.Stop();
                return false;
            }
            
        }

        private bool CameraCapture1(BaslerVideoCapture cap)
        {
            log.write($"{cap.serial}_{cap.index} allow capture.");
            //AllowCaptureForPredict = true;
            if (RunMode == TestMode.Test_Mode) AllowCaptureForPredict = true;
            else collectImage = true;
            waitCapture.Reset();
            cap.CamImageReady += Cap_CamImageReady1;
            cap.OneShot();
            waitCapture.WaitOne(5000);
            if ((RunMode == TestMode.Test_Mode ? AllowCaptureForPredict : collectImage) == false)
            {
                log.write($"{cap.serial}_{cap.index} capture finish.");
                cap.CamImageReady -= Cap_CamImageReady1;
                Thread.Sleep(500);
                cap.Stop();
                return true;
            }
            else//capture time out
            {
                log.write($"{cap.serial}_{cap.index} capture time out.");
                UpdateStatus($"camera:{cap.serial} capture image time out.", Color.Red);
                cap.Stop();
                return false;
            }
            cap.Stop();
        }
        private void btnPrediction_Click(object sender, EventArgs e)
        {
            if (tsmiStartButton.Text.Equals("開始(Start)"))
            {
                if (RBtnPlaceSeparately.Checked == true && RBtnReverse.Checked == false && RBtnForeward.Checked == false)
                {
                    MessageBox.Show("Fail区皮带运行方向未选择!!", "Belt Running Direction", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (PO == null || string.IsNullOrEmpty(this.Product_Name) || ROIS == null || ROIS.Count == 0)
                {
                    MessageBox.Show("未載入機種，無法啟動!!", "Run Predict Process", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (ConveyorMechanism.HasDutInPosition1 || ConveyorMechanism.HasDutInPosition2 /*|| UpDownMechanism.HasDut*/)
                {
                    MessageBox.Show("產品未清空，無法啟動!!", "Run Predict Process", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (EmergencySensor.GetState())
                {
                    MessageBox.Show("緊急停止按紐未釋放，無法啟動!!", "Run Predict Process", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    ControlPointBelt();
                    Login_Init();
                    IsPause = false;
                    IsRunning = true;
                    tabMain.SelectedIndex = 0;
                    ColorLight.Normal();
                    RotaryMechanism.Velocity = Velocity;
                    XZMechanism.Velocity = Velocity;
                    RotaryMechanism.SetClamp(true);
                    RotaryMechanism.SetVacuum(false);
                    XZMechanism.SetVacuum(false);
                    Thread th = new Thread(() =>
                      {
                          XZMechanism.AbsoluteMove(PO.XZMechanism_Initila_X_position, PO.XZMechanism_Initila_Z_position);
                      });
                    th.Start();
                    RotaryMechanism.AbsoluteMove_RotationFirst(PO.RotaryMechanism_Initial_Position, 0);
                    //DecisionMechanism.results.Clear();
                    current_step = Test_Step.wait_dut_in;

                    EmergencyTimer.Elapsed += EmergencyTask;
                    TaskTimer.Elapsed += Timer_Elapsed;
                    failTrayTimer.Start();
                    //TaskTimer.Enabled = true;
                    displayROI = false;
                    TaskTimer.AutoReset = false;
                    tsmiStartButton.Text = "停止(Stop)";
                    LBStationName.Text = cfg.StationName;
                    EmergencyTimer.Start();
                    DecisionMechanism?.Start();
                    TaskTimer.Start();
                    tsmiStopAfterClearDUT.Visible = true;
                    tsmiStopAfterClearDUT.Enabled = true;
                    //tsbCollectImage.Enabled = false;
                    RBtnPlaceSeparately.AutoCheck = false;
                    RBtnSamePlacement.AutoCheck = false;
                    RBtnForeward.AutoCheck = false;
                    RBtnReverse.AutoCheck = false;
                    if(!cfg.Light_Control)
                    {
                        ColorLight.ControlLightOn();
                    }
                }
            }
            else
            {

                //先停tasktimer
                Light(false);
                //DecisionMechanism.TaskOverWhenClearResults = true;
                TaskTimer.Elapsed -= Timer_Elapsed;
                EmergencyTimer.Elapsed -= EmergencyTask;
                EmergencyTimer.Stop();
                TaskTimer.Stop();
                DecisionMechanism?.Stop();
                tsmiStartButton.Text = "開始(Start)";
                UpDownMechanism.Stop();
                tsmiStopAfterClearDUT.Visible = false;
                tsmiStopAfterClearDUT.Enabled = false;
                RBtnPlaceSeparately.AutoCheck = true;
                RBtnSamePlacement.AutoCheck = true;
                RBtnForeward.AutoCheck = true;
                RBtnReverse.AutoCheck = true;
                //IsPause = false;
                //tsbCollectImage.Enabled = true;
            }
        }

        private void EmergencyTask(object sender, ElapsedEventArgs e)
        {
            if (EmergencySensor.GetState())
            {
                TaskTimer.Stop();
                TaskTimer.Elapsed -= Timer_Elapsed;
                DecisionMechanism?.Stop();
                tsmiRun.Enabled = false;
                ConveyorMechanism.Conveyor(false);
                UpDownMechanism.Conveyor(false);
                OutputMechanism.Conveyor(false);
                this.Invoke(new Action(() => {
                    tsmiStartButton.Text = "開始(Start)";
                    tsmiRun.Enabled = false;
                }));
            }
            if (cfg.DoorSensorEnable && !DoorSensor.GetState())
            {

                if (!IsPause)
                {
                    IsPause = true;
                    ColorLight.Warn(500);
                }
                //if(MessageBox.Show("偵測到安全門已開啟，設備暫停運行，是否繼續運行?","設備暫停", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)== DialogResult.Yes)
                //{
                //    IsPause= false;
                //}
            }
            else
            {
                if (cfg.DoorSensorEnable && IsPause && DoorSensor.GetState())
                {
                    IsPause = false;
                    ColorLight.Normal();
                }

            }
            if (StopEmergencyTask && ((DecisionMechanism == null || DecisionMechanism.IsStop)))//最後停EmergencyTimer
            {
                //if(DecisionMechanism.IsStop)
                EmergencyTimer.Elapsed -= EmergencyTask;
                EmergencyTimer.Stop();
                this.Invoke(new Action(() =>
                {
                    tsmiStartButton.Text = "開始(Start)";
                    tsmiStartButton.Enabled = true;
                    tsmiStopAfterClearDUT.Visible = false;
                }));
            }

        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            TaskTimer.Stop();
            if (!IsPause)
            {
                switch (current_step)
                {
                    case Test_Step.wait_dut_in:
                        if (IsRunning)
                        {
                            if (RotaryMechanism.HasDut && PlacePASSDUT.GetState())
                            {
                                ReadBarcodeIsn = "";
                                current_step = Test_Step.clamp_dut;
                                log.write("Dut arrive, and enter clamp dut step.");
                                RotaryMechanism.SetVacuum(true);
                                stopWatch.Restart();
                                //label6.Text = null;
                            }
                        }
                        else
                        {
                            TaskTimer.Elapsed -= Timer_Elapsed;
                            //tasktimer停了，再停DecisionMechanism timer，確保所有DUT都已經沒有了
                            if (DecisionMechanism != null) DecisionMechanism.TaskOverWhenClearResults = true;
                            else ConveyorMechanism.Conveyor(false);
                            StopEmergencyTask = true;
                        }
                        break;
                    case Test_Step.clamp_dut:
                        if (RotaryMechanism.ClampArrive && RotaryMechanism.VacuumIsReach && LightCurtainSensor.GetState())
                        {
                            log.write("入料檢測，真空值已達標，準備鬆開夾持，並進入拍照區");
                            try
                            {
                                
                                RotaryMechanism.AbsoluteMove(PO.RotaryMechanism_Capture_X_Position, PO.RotaryMechanism_Capture_Z_Position);
                                RotaryMechanism.SetClamp(false);
                                Light(true);
                                Thread.Sleep(500);
                                this.Invoke(new Action(() =>
                                {
                                    foreach (Emgu.CV.UI.ImageBox box in boxes)
                                    {
                                        if (box.Image != null) box.Image.Dispose();
                                        box.Image = null;
                                    }
                                }));
                                foreach (BaslerVideoCapture basler in caps)
                                {
                                    predict_result[$"{basler.serial}_{basler.index}"] = null;
                                }
                                if (selectedCapture != null)
                                {
                                    selectedCapture.Stop();
                                    selectedCapture.CamImageReady -= Cap_CamImageReady;
                                    Thread.Sleep(20);
                                }
                                if (RunMode == TestMode.Test_Mode || RunMode == TestMode.Collect_Image_Mode)
                                {
                                    if (cfg.RotaryMechanism_Capture_Delay > 0) Thread.Sleep(cfg.RotaryMechanism_Capture_Delay);
                                    current_step = Test_Step.first_capture;
                                }

                                else if (RunMode == TestMode.Conveyor_Mode)
                                {
                                    if (cfg.CameraBarcode)
                                    {
                                        log.write("轨道模式下进行识别条码!!");
                                        if (cfg.RotaryMechanism_Capture_Delay > 0) Thread.Sleep(cfg.RotaryMechanism_Capture_Delay);
                                        current_step = Test_Step.first_capture;
                                    }
                                    else
                                    {
                                        log.write("轨道模式下旋轉區準備翻轉");
                                        RotaryMechanism.AbsoluteMove(PO.RotaryMechanism_Rotary_X_Position, PO.RotaryMechanism_Rotary_Z_Position);
                                        current_step = Test_Step.rotarymechanism_go_final_pisition;
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                log.wrieException(ex);
                                current_step = Test_Step.error;
                            }
                        }
                        else if (stopWatch.ElapsedMilliseconds > 15000)
                        {
                            log.write("入料檢測，真空值未達標");
                            if (MessageBox.Show("入料區，真空未達標，是否繼續?", "動作異常", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                            {
                                log.write("真空值未達標，重新檢測真空值");
                                stopWatch.Restart();
                                current_step = Test_Step.clamp_dut;
                            }
                            else
                            {
                                stopWatch.Stop();
                                current_step = Test_Step.error;
                            }
                        }
                        break;

                    case Test_Step.first_capture:
                        //ReadBarcodei = 0;
                        log.write("進行第一次拍照");
                        try
                        {
                            //firstcaptrue:
                            selectedCapture = caps[0];//top capture
                                                      //log.write("")
                            Thread.Sleep(cfg.Top_Capture_Delay);
                            if(CameraCapture1(selectedCapture))
                            {
                                if (cfg.CameraBarcode)
                                {
                                    Thread.Sleep(1000);
                                    ReadBarcode();
                                }
                            }
                            Thread.Sleep(2000);
                            if (CameraCapture(selectedCapture))
                            {
                                Thread.Sleep(2000);
                                if (RunMode == TestMode.Conveyor_Mode)
                                {
                                    if (!Test_Barcode)
                                    {
                                        UpdateMsg("条码检测失败", Color.Red);
                                        Light(false);
                                        ColorLight.Warn(5000);
                                        current_step = Test_Step.test_Fail;
                                    }
                                    else
                                    {
                                        current_step = Test_Step.ConveyorMode;
                                    }
                                }
                                else
                                {
                                    if (!Test_Barcode)
                                    {
                                        UpdateMsg("条码检测失败", Color.Red);
                                        Light(false);
                                        ColorLight.Warn(5000);
                                        current_step = Test_Step.test_Fail;
                                    }
                                    else
                                    {
                                        selectedCapture = LeftCaptureMechanism.BaslerVideoCapture;
                                        selectedCapture.index = 0;
                                        if (CameraCapture(selectedCapture))
                                        {
                                            selectedCapture = RightCaptureMechanism.BaslerVideoCapture;
                                            selectedCapture.index = 0;
                                            if (CameraCapture(selectedCapture))
                                            {

                                                log.write("旋轉區準備翻轉");
                                                RotaryMechanism.AbsoluteMove(PO.RotaryMechanism_Rotary_X_Position, PO.RotaryMechanism_Rotary_Z_Position);
                                                if (cfg.RotaryMechanism_Capture_Delay > 0) Thread.Sleep(cfg.RotaryMechanism_Capture_Delay);
                                                current_step = Test_Step.second_capture;
                                            }
                                            else
                                            {
                                                current_step = Test_Step.error;
                                            }
                                        }
                                        else
                                        {
                                            current_step = Test_Step.error;
                                        }
                                    }
                                }
                                
                            }
                        }
                        catch (Exception ex)
                        {
                            log.wrieException(ex);
                            current_step = Test_Step.error;
                        }
                        break;
                    case Test_Step.second_capture:
                        selectedCapture = LeftCaptureMechanism.BaslerVideoCapture;
                        selectedCapture.index = 1;
                        try
                        {
                            log.write("進行第二次拍照");
                            if (CameraCapture(selectedCapture))
                            {
                                selectedCapture = RightCaptureMechanism.BaslerVideoCapture;
                                selectedCapture.index = 1;
                                if (CameraCapture(selectedCapture))
                                {
                                    current_step = Test_Step.rotarymechanism_go_final_pisition;
                                }
                                else
                                {
                                    current_step = Test_Step.error;
                                }
                                Light(false);
                            }
                            else
                            {
                                current_step = Test_Step.error;
                            }
                        }
                        catch (Exception ex)
                        {
                            log.wrieException(ex);
                            current_step = Test_Step.error;
                        }
                        break;
                    case Test_Step.rotarymechanism_go_final_pisition:
                        log.write("旋轉機構進入吸取區");
                        RotaryMechanism.AbsoluteMove(PO.RotaryMechanism_Final_X_Position, PO.RotaryMechanism_Final_Z_Position);
                        log.write("旋轉機構關閉吸真空");
                        RotaryMechanism.SetVacuum(false);
                        log.write("XZ機構運動至吸取位置");
                        XZMechanism.AbsoluteMove(PO.XZMechanism_Clamp_X_Position, PO.XZMechanism_Clamp_Z_Position);
                        log.write("XZ機構開始吸真空");
                        XZMechanism.SetVacuum(true);
                        stopWatch.Restart();
                        current_step = Test_Step.wait_xzmechanism_vacuum_reach;
                        break;
                    case Test_Step.wait_xzmechanism_vacuum_reach:
                        if (XZMechanism.VacuumIsReach)
                        {
                            stopWatch.Stop();
                            if (RunMode == TestMode.Test_Mode || RunMode == TestMode.Collect_Image_Mode)
                            {
                                log.write("XZ機構吸真空已到達，開始運動到拍照區");
                                XZMechanism.AbsoluteMove(PO.XZMechanism_Capture_X_Position, PO.XZMechanism_Capture_Z_Position);
                                if (cfg.XZMechanism_Capture_Delay > 0) Thread.Sleep(cfg.XZMechanism_Capture_Delay);
                                log.write("XZ機構拍照區已到達，開始進行第三次拍照");
                                //XZMechanism.AbsoluteMove(PO.RotaryMechanism_Initial_Position, 0);
                                Light(true);
                                current_step = Test_Step.third_capture;
                            }
                            else
                            {
                                //if (!ConveyorMechanism.HasDutInPosition1)
                                //{
                                //ConveyorMechanism.Conveyor(false);
                                XZMechanism.AbsoluteMove(PO.XZMechanism_Initila_X_position, PO.XZMechanism_Initila_Z_position);

                                //XZMechanism.AbsoluteMove(PO.XZMechanism_Relax_X_Position, PO.XZMechanism_Relax_Z_Position);
                                //XZMechanism.SetVacuum(false);
                                //XZMechanism.SetBreakVacuum(true);
                                //current_step = Test_Step.xzmechanism_dut_relax_finish;
                                current_step = Test_Step.xzmechanism_relax_dut;
                                //}

                            }
                            Thread th = new Thread(() =>
                            {
                                RotaryMechanism.SetClamp(true);
                                RotaryMechanism.AbsoluteMove_RotationFirst(PO.RotaryMechanism_Initial_Position, 0);
                                //RotaryMechanism.AbsoluteMove_RotationFirst(PO.XZMechanism_Initila_X_position, PO.XZMechanism_Initila_Z_position);
                            });
                            th.Start();
                        }
                        else if (stopWatch.ElapsedMilliseconds > 5000)
                        {
                            log.write("XZ機構真空值未達標");
                            ColorLight.Error();
                            if (MessageBox.Show("XZ機構真空未達標，是否繼續?", "動作異常", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                            {
                                log.write("XZ機構真空值未達標，重新檢測真空值");
                                ColorLight.Normal();
                                stopWatch.Restart();
                                current_step = Test_Step.wait_xzmechanism_vacuum_reach;
                            }
                            else
                            {
                                stopWatch.Stop();
                                current_step = Test_Step.error;
                            }
                        }
                        break;
                    case Test_Step.third_capture:
                        selectedCapture = caps[1];
                        try
                        {
                            log.write("進行底部拍照");
                            if (CameraCapture(selectedCapture))
                            {
                                //log.write("DUT等待釋放");
                                log.write("等待检查");
                                Light(false);
                                //current_step = Test_Step.xzmechanism_relax_dut;
                                current_step = Test_Step.wait_predict_result;
                            }
                            else
                            {
                                current_step = Test_Step.error;
                            }
                        }
                        catch (Exception ex)
                        {
                            log.wrieException(ex);
                            current_step = Test_Step.error;
                        }

                        break;
                    case Test_Step.wait_predict_result:
                        if (RunMode == TestMode.Test_Mode)
                        {
                            if (stopWatch.ElapsedMilliseconds < 15000)
                            {
                                if (predict_result.All(x => x.Value != null))
                                {
                                    log.write("All predicts have answers. Enter test_finish step");
                                    Invoke(new updateYieldHandler(imageSN));
                                    current_step = Test_Step.test_finish;
                                }
                            }
                            else//超時
                            {
                                log.write("Wait predict result time out.");
                                current_step = Test_Step.error;
                            }
                        }
                        else
                        {
                            if (stopWatch.ElapsedMilliseconds < 15000)
                            {

                                //if (predict_result.All(x => x.Value != null))
                                //{
                                log.write("All predicts have answers. Enter test_finish step");
                                current_step = Test_Step.xzmechanism_relax_dut;
                                //}
                            }
                            else//超時
                            {
                                log.write("Wait predict result time out.");
                                current_step = Test_Step.error;
                            }
                        }

                        break;

                    case Test_Step.test_finish:
                        if (predict_result.All(x => x.Value.Equals("PASS")))
                        {
                            log.write("Predict result pass.");
                            TestFinish = true;
                            DecisionMechanism?.SetResults(true);
                            DecisionMechanism.InferenceTest = true;
                            CountPass++;
                            Invoke(new updateYieldHandler(updateYield));
                            if(cfg.SFISOpen)
                            {
                                PASS_Function(ReadBarcodeIsn1);
                            }
                            if (cfg.SFISOpen&& SFISresult)
                            {
                                //UpdateMsg("Pass---SFIS上传成功", Color.Green);
                                UpdateMsg($"Pass---{SFISmsg}", Color.Green);
                            }
                            else if(cfg.SFISOpen&&!SFISresult)
                            {
                                //UpdateMsg("Pass---SFIS上传失败", Color.Green);
                                UpdateMsg($"Pass---{SFISmsg}", Color.Green);
                            }
                            else
                            {
                                UpdateMsg("Pass", Color.Green);
                            }
                            infra_screw = true;
                            ColorLight.Normal();
                            //test_finish.WriteState(true);
                            Thread.Sleep(50);
                            //test_finish.WriteState(false);
                            Thread.Sleep(2000);
                            log.write("Wait next dut arrive.");
                            current_step = Test_Step.xzmechanism_relax_dut;
                            //#endif
                        }
                        else
                        {
                            log.write("Predict result fail.");
                            TestFinish = false;
                            DecisionMechanism.InferenceTest = false;
                            DecisionMechanism?.SetResults(false);
                            CountFail++;
                            if (cfg.SFISOpen&&infra_screw==true)
                            {
                                PASS_Function(ReadBarcodeIsn1);
                            }
                            else if(cfg.SFISOpen&&infra_screw==false)
                            {
                                NG_Function(ReadBarcodeIsn1,cfg.ErrorCode);
                            }

                            Invoke(new updateYieldHandler(updateYield));
                            if (cfg.SFISOpen && SFISresult&&infra_screw==true)
                            {
                                //UpdateMsg("Fail---SFIS上传成功", Color.Red);
                                UpdateMsg($"Fail---{SFISmsg}", Color.Red);
                            }
                            else if (cfg.SFISOpen && !SFISresult&& infra_screw == true)
                            {
                                //UpdateMsg("Fail---SFIS上传失败", Color.Red);
                                UpdateMsg($"Fail---{SFISmsg}", Color.Red);
                            }
                            else if(infra_screw==false)
                            {
                                UpdateMsg($"Fail---已鎖住！請解碼", Color.Red);
                            }
                            else
                            {
                                UpdateMsg("Fail", Color.Red);
                            }
                            infra_screw = true;
                            ColorLight.Warn(5000);
                            //test_finish.WriteState(true);
                            Thread.Sleep(50);
                            //test_finish.WriteState(false);
                            Thread.Sleep(2000);
                            log.write("Wait next dut arrive.");
                            current_step = Test_Step.xzmechanism_relax_dut;
                            //#endif
                        }
                        break;
                    case Test_Step.test_Fail:
                        DecisionMechanism.InferenceTest = false;
                        log.write("旋轉機構進入吸取區--->条码检测失败");
                        RotaryMechanism.AbsoluteMove(PO.RotaryMechanism_Final_X_Position, PO.RotaryMechanism_Final_Z_Position);
                        log.write("旋轉機構關閉吸真空--->条码检测失败");
                        RotaryMechanism.SetVacuum(false);
                        log.write("XZ機構運動至吸取位置--->条码检测失败");
                        XZMechanism.AbsoluteMove(PO.XZMechanism_Clamp_X_Position, PO.XZMechanism_Clamp_Z_Position);
                        log.write("XZ機構開始吸真空--->条码检测失败");
                        XZMechanism.SetVacuum(true);
                        Thread.Sleep(1000);
                        Vacuum:
                        if (XZMechanism.VacuumIsReach)
                        {
                            XZMechanism.AbsoluteMove(PO.XZMechanism_Capture_X_Position, PO.XZMechanism_Capture_Z_Position);
                        }
                        else if (stopWatch.ElapsedMilliseconds > 5000)
                        {
                            log.write("XZ機構真空值未達標");
                            ColorLight.Error();
                            if (MessageBox.Show("XZ機構真空未達標，是否繼續?", "動作異常", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                            {
                                log.write("XZ機構真空值未達標，重新檢測真空值");
                                ColorLight.Normal();
                                stopWatch.Restart();
                                goto Vacuum;
                            }
                            else
                            {
                                stopWatch.Stop();
                                current_step = Test_Step.error;
                            }
                        }
                        stopWatch.Restart();
                        log.write("Predict result Barcodefail.");
                        DecisionMechanism?.SetResults(false);
                        RotaryMechanism.SetClamp(true);
                        RotaryMechanism.AbsoluteMove_RotationFirst(PO.RotaryMechanism_Initial_Position, 0);
                        Thread.Sleep(50);
                        current_step = Test_Step.xzmechanism_relax_dut;
                        //#endif
                        break;
                    case Test_Step.ConveyorMode:
                        DecisionMechanism.InferenceTest = true;
                        log.write("旋轉機構進入吸取區--->轨道模式");
                        RotaryMechanism.AbsoluteMove(PO.RotaryMechanism_Final_X_Position, PO.RotaryMechanism_Final_Z_Position);
                        log.write("旋轉機構關閉吸真空--->轨道模式");
                        RotaryMechanism.SetVacuum(false);
                        log.write("XZ機構運動至吸取位置--->轨道模式");
                        XZMechanism.AbsoluteMove(PO.XZMechanism_Clamp_X_Position, PO.XZMechanism_Clamp_Z_Position);
                        log.write("XZ機構開始吸真空--->轨道模式");
                        XZMechanism.SetVacuum(true);
                        Thread.Sleep(1000);
                        Vacuum1:
                        if (XZMechanism.VacuumIsReach)
                        {
                            XZMechanism.AbsoluteMove(PO.XZMechanism_Capture_X_Position, PO.XZMechanism_Capture_Z_Position);
                        }
                        else if (stopWatch.ElapsedMilliseconds > 5000)
                        {
                            log.write("XZ機構真空值未達標");
                            ColorLight.Error();
                            if (MessageBox.Show("XZ機構真空未達標，是否繼續?", "動作異常", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                            {
                                log.write("XZ機構真空值未達標，重新檢測真空值");
                                ColorLight.Normal();
                                stopWatch.Restart();
                                goto Vacuum1;
                            }
                            else
                            {
                                stopWatch.Stop();
                                current_step = Test_Step.error;
                            }
                        }
                        stopWatch.Restart();
                        log.write("轨道模式运行.");
                        DecisionMechanism?.SetResults(false);
                        RotaryMechanism.SetClamp(true);
                        RotaryMechanism.AbsoluteMove_RotationFirst(PO.RotaryMechanism_Initial_Position, 0);
                        Thread.Sleep(50);
                        if (cfg.SFISOpen && SFISresult)
                        {
                            UpdateMsg("轨道模式---SFIS上传成功", Color.Green);
                        }
                        else if (cfg.SFISOpen && !SFISresult)
                        {
                            UpdateMsg("轨道模式---SFIS上传失败", Color.Gray);
                        }
                        current_step = Test_Step.xzmechanism_relax_dut;
                        //#endif
                        break;
                    case Test_Step.xzmechanism_relax_dut:
                        if (!ConveyorMechanism.HasDutInPosition1 && !ConveyorMechanism.ConveyorIsRunning)
                        {
                            Light(false);
                            if (RBtnSamePlacement.Checked == true)
                            {
                                XZmechan:
                                if(!UpDownMechanism.PassHasDut&&!OutputMechanism.ConveyorIsRunning)
                                {
                                    log.write("XZ機構移動至DUT釋放位置");
                                    if (DecisionMechanism != null) DecisionMechanism.XZMechanismRelaxDut = true;
                                    else ConveyorMechanism.Conveyor(false);
                                    //读取放板点位
                                    XZMechanism.AbsoluteMove(PO.XZMechanism_Relax_X_Position, PO.XZMechanism_Relax_Z_Position);

                                    XZMechanism.SetVacuum(false);
                                    XZMechanism.SetBreakVacuum(true);
                                    current_step = Test_Step.xzmechanism_dut_relax_finish;
                                }
                                else
                                {
                                    goto XZmechan;
                                }
                                
                            }
                            else if (RBtnPlaceSeparately.Checked == true)
                            {
                                //分开放置
                                if (lbPredictionResult2.Text == "Pass")
                                {
                                    log.write("XZ機構移動至PASS区釋放位置");
                                    if (DecisionMechanism != null) DecisionMechanism.XZMechanismRelaxDut = true;
                                    else ConveyorMechanism.Conveyor(false);
                                    //读取放板点位
                                    XZMechanism.AbsoluteMove(PO.XZMechanism_Relax_X_Position, PO.XZMechanism_Relax_Z_Position);

                                    XZMechanism.SetVacuum(false);
                                    XZMechanism.SetBreakVacuum(true);
                                    current_step = Test_Step.xzmechanism_dut_relax_finish;
                                }
                                else
                                {
                                    log.write("XZ機構移動至Fail区釋放位置");
                                    if (DecisionMechanism != null) DecisionMechanism.XZMechanismRelaxDut = true;
                                    else ConveyorMechanism.Conveyor(false);
                                    //读取放板点位
                                    XZMechanism.AbsoluteMove(PO.XZMechanism_Relax_X_Position2, PO.XZMechanism_Relax_Z_Position2);

                                    XZMechanism.SetVacuum(false);
                                    XZMechanism.SetBreakVacuum(true);
                                    current_step = Test_Step.xzmechanism_dut_relax_finish;
                                }

                            }
                        }
                        break;
                    case Test_Step.xzmechanism_dut_relax_finish:

                        if (!XZMechanism.VacuumIsReach && UpDownMechanism.PassHasDut)
                        {
                            XZMechanism.SetBreakVacuum(false);
                            Thread th = new Thread(() =>
                            {
                                XZMechanism.AbsoluteMove(PO.XZMechanism_Initila_X_position, PO.XZMechanism_Initila_Z_position);
                                if (DecisionMechanism != null) DecisionMechanism.XZMechanismRelaxDut = false;
                                else ConveyorMechanism.Conveyor(true);
                            });
                            th.Start();
                            if (RunMode == TestMode.Collect_Image_Mode || RunMode == TestMode.Conveyor_Mode)
                            {
                                DecisionMechanism?.results.Enqueue(true);
                                current_step = Test_Step.wait_dut_in;
                            }
                            else
                            {
                                stopWatch.Restart();
                                //current_step = Test_Step.wait_predict_result;
                                current_step = Test_Step.wait_dut_in;
                            }
                        }
                        else if (!XZMechanism.VacuumIsReach && UpDownMechanism.FailLaydownarea)
                        {
                            XZMechanism.SetBreakVacuum(false);
                            Thread th = new Thread(() =>
                            {
                                XZMechanism.AbsoluteMove(PO.XZMechanism_Initila_X_position, PO.XZMechanism_Initila_Z_position);
                                if (DecisionMechanism != null) DecisionMechanism.XZMechanismRelaxDut = false;
                                else ConveyorMechanism.Conveyor2(true);
                            });
                            th.Start();
                            if (RunMode == TestMode.Collect_Image_Mode || RunMode == TestMode.Conveyor_Mode)
                            {
                                DecisionMechanism?.results.Enqueue(true);
                                current_step = Test_Step.wait_dut_in;
                            }
                            else
                            {
                                stopWatch.Restart();
                                //current_step = Test_Step.wait_predict_result;
                                current_step = Test_Step.wait_dut_in;
                            }
                        }
                        break;
                    case Test_Step.error:
                        UpdateMsg("检查失敗", Color.Gray);
                        //#if DEBUG

                        //#else
                        ColorLight.Error(2000);
                        //test_finish.WriteState(true);
                        Thread.Sleep(50);
                        //test_finish.WriteState(false);
                        //#endif

                        current_step = Test_Step.wait_dut_in;
                        break;
                }

            }
            TaskTimer.Start();
        }

        public void Predict(Small_Image small_image)
        {
            try
            {
                string isn = Path.GetFileNameWithoutExtension(small_image.imagePath);
                //int ret = -1;
                string resp_info = null;
                //string dut_info = null;

                //string construct_info = "{" +
                //         "\"dut_sn\": \"" + isn + "\"" +
                //         "}";
                //ret = m2m.ExecuteConstructMaster(construct_info);
                //dut_info = "{\"dut_sn\": \"" + isn + "\"," +
                //    "\"product_name\": \"UIE4027\"}";
                //if (ret == 0)
                {
                    //string number = null;

                    var predict_result = predictor.Predict(
                        Product_Name,
                        new List<string> { small_image.imagePath },
                        new List<string> { isn },
                        null);                 //(small_image.imagePath, dut_info, ref resp_info);
                    string result = predict_result.outputs[0].results[0].category_name;
                    resp_info = predict_result.ToString();
                    small_image.predictResult = result;
                    if(result== "infra_screw_ng"||result== "infra_net_ng")
                    {
                        infra_screw = false;
                    }
                    log.write($"{result}----回傳結果");
                    small_image.Save(cfg.Image_Path_After_Inference);
                    //update result for some mask
                    small_image.predictResult = small_image.mask ? "PASS" : (result.Equals(small_image.category) ? "PASS" : result);

                    log.write($"Predict status:{small_image.imagePath} {ReadBarcodeIsn} predict--->{result}");
                    //}
                    //else
                    //{
                    //    UpdateProducerResponse($"ConstructM2MMessage error(ret={ret})", Color.Red);
                    //}
                    //}
                }
                //else UpdateProducerResponse($"ConstructExecutingM2MMessage error(ret={ret})", Color.Red);
            }
            catch (Exception ex)
            {
                //log.write($"Predict exception:{ex.Message}");
                //log.write(ex.StackTrace);
                log?.wrieException(ex);
                return;
                //MessageBox.Show(ex.Message, "Predict error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void tbPSelectModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (cbDevice.SelectedItem != null)
            //{
            //    BaslerVideoCapture cap = cbDevice.SelectedItem as BaslerVideoCapture;
            //    cap.Stop();
            //    Thread.Sleep(50);
            //    cap.CamImageReady -= Cap_CamImageReady;
            //    Thread.Sleep(50);
            //}
            UItimer.Stop();
            if (preTabPage == tpSetting)
            {
                UItimer.Tick -= UpdateMotorPosition;
            }
            else if (preTabPage == tpIOInterface)
            {
                UItimer.Tick -= CheckInputIOStatus;
            }
            if (selectedCapture != null)
            {

                selectedCapture.Stop();
                selectedCapture.CamImageReady -= Cap_CamImageReady;
            }
            isSetting = false;
            if (tabMain.SelectedTab.Name == "tpSetting")
            {
                if (selectedCapture != null)
                {
                    if (selectedCapture == (BaslerVideoCapture)cbDevice.SelectedItem)
                    {
                        ReflashSettingUI();
                        selectedCapture.CamImageReady += Cap_CamImageReady;
                        selectedCapture.ContinuousShot();
                    }
                    else
                    {
                        selectedCapture.Stop();
                        Thread.Sleep(50);
                        selectedCapture.CamImageReady -= Cap_CamImageReady;
                        Thread.Sleep(50);
                        //cap1 = null;
                        selectedCapture = (BaslerVideoCapture)cbDevice.SelectedItem;
                        selectedCapture.CamImageReady += Cap_CamImageReady;
                        ReflashSettingUI();
                        selectedCapture.ContinuousShot();
                    }

                }
                else
                {
                    if (caps != null && caps.Count() > 0)
                    {
                        selectedCapture = (BaslerVideoCapture)cbDevice.SelectedItem;
                        selectedCapture.CamImageReady += Cap_CamImageReady;
                        ReflashSettingUI();
                        selectedCapture.ContinuousShot();
                    }

                }
                //if (cbMotorPosition.SelectedIndex == -1) selectedMechanism = null;
                //else if (cbMotorPosition.SelectedIndex >= 0 && cbMotorPosition.SelectedIndex <= 3) selectedMechanism = RotaryMechanism;
                //else if (tabSettings.SelectedTab == tpXZArea) selectedMechanism = XZMechanism;
                //else
                //{
                //    if (cbDevice.SelectedItem.Equals(LeftCaptureMechanism.BaslerVideoCapture)) selectedMechanism = LeftCaptureMechanism;
                //    else if (cbDevice.SelectedItem.Equals(RightCaptureMechanism)) selectedMechanism = RightCaptureMechanism;
                //}
                if (selectedMechanism != null)
                {
                    if (selectedMechanism.Velocity == Velocity.High) rbHigh_Velocity.Checked = true;
                    else if (selectedMechanism.Velocity == Velocity.Medium) rbMedium_Velocity.Checked = true;
                    else rbLow_Velocity.Checked = true;
                    if (selectedMechanism.Motor_Move_Distance == 1) rb1mm.Checked = true;
                    else if (selectedMechanism.Motor_Move_Distance == 2) rb2mm.Checked = true;
                    else if (selectedMechanism.Motor_Move_Distance == 5) rb5mm.Checked = true;
                    else rb10mm.Checked = true;
                }
                UItimer.Tick += UpdateMotorPosition;
                isSetting = true;
                UItimer.Start();
                lbModelName.Text = (PO == null ? "NA" : PO.Name);
            }
            else if (tabMain.SelectedTab == tpIOInterface)
            {
                btnRotationAreaClampOrRelax.Text = RotaryMechanism.Clamp ? "Relax(鬆開)" : "Clamp(夾緊)";
                btnRotationAreaVacuum.Text = RotaryMechanism.VacuumON ? "Vacuum(吸真空) OFF" : "Vacuum(吸真空) ON";
                btnXZAreaVacuum.Text = XZMechanism.VacuumOn ? "Vacuum(吸真空) OFF" : "Vacuum(吸真空) ON";
                btnXZAreaBreakVacuum.Text = XZMechanism.BreakVacuumOn ? "Break Vacuum (破真空) OFF" : "Break Vacuum (破真空) ON";
                btnConveyor.Text = ConveyorMechanism.ConveyorIsRunning ? "Conveyor(皮帶2) OFF" : "Conveyor(皮帶2) ON";
                btnUpDownAreaConveyor.Text = UpDownMechanism.ConveyorIsRunning ? "Conveyor(皮帶1) OFF" : "Conveyor(皮帶1) ON";
                btnFailAreaConveyor.Text = OutputMechanism.ConveyorIsRunning ? "Conveyor(皮帶) OFF" : "Conveyor(皮帶) ON";
                btn3ColorRed.Text = ColorLight.redLight.State ? "Red(紅燈) OFF" : "Red(紅燈) ON";
                btn3ColorGreen.Text = ColorLight.greenLight.State ? "Green(綠燈) OFF" : "Green(綠燈) ON";
                btn3ColorYellow.Text = ColorLight.yellowLight.State ? "Yellow(黃燈) OFF" : "Yellow(黃燈) ON";
                btn3ColorAlarm.Text = ColorLight.buzzer.State ? "Alarm(蜂鳴器) OFF" : "Alarm(蜂鳴器) ON";
                UItimer.Tick += CheckInputIOStatus;
                UItimer.Start();
            }
            //if (UItimer.Tick != null) UItimer.Start();
            preTabPage = tabMain.SelectedTab;
        }

        private void EmergencyCheck(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void CheckInputIOStatus(object sender, EventArgs e)
        {
            //安全
            lbDoorSensor.BackColor = DoorSensor.GetState() ? Color.Green : Color.Gray;
            lbEmergency.BackColor = EmergencySensor.GetState() ? Color.Green : Color.Gray;
            lbLightCurtain.BackColor = LightCurtainSensor.GetState() ? Color.Gray : Color.Green;
            //lbConveyorSafetySensor.BackColor=UpDownMechanism.ConveyorSafetySensor.GetState()? Color.Green : Color.Gray;
            ///旋轉區
            lbRotationAreaHasDut.BackColor = RotaryMechanism.HasDut ? Color.Green : Color.Gray;
            lbRotationAreaClamp.BackColor = RotaryMechanism.ClampArrive ? Color.Green : Color.Gray;
            lbRotationAreaRelax.BackColor = RotaryMechanism.RelaxArrive ? Color.Green : Color.Gray;
            lbRotationAreaVacuum.BackColor = RotaryMechanism.VacuumIsReach ? Color.Green : Color.Gray;
            //FAIL區
            lbFailAreaHasDut.BackColor = OutputMechanism.FailAreaHasDut ? Color.Green : Color.Gray;
            lbPassAreaHasDut.BackColor = OutputMechanism.PassAreaHasDutSensor ? Color.Green : Color.Gray;
            lbAreaHasDut.BackColor = UpDownMechanism.PassHasDut ? Color.Green : Color.Gray;
            //UPDOWN
            lbUpDownAreaHasDut.BackColor = UpDownMechanism.HasDut ? Color.Green : Color.Gray;
            //lbUpDownAreaUpPosition.BackColor = UpDownMechanism.IsUp ? Color.Green : Color.Gray;
            //lbUpDownAreaDownPosition.BackColor = UpDownMechanism.IsDown ? Color.Green : Color.Gray;
            //INPUT訊號
            lbInpuntSignalDutPlace.BackColor = PlacePASSDUT.GetState() ? Color.Green : Color.Gray;
            lbInpuntSignalGreenButton.BackColor = GreenInputButton.GetState() ? Color.Green : Color.Gray;
            lbInpuntSignalRedButton.BackColor = RedInputButton.GetState() ? Color.Green : Color.Gray;
            lbInpuntSignalYellowButton.BackColor = YellowInputButton.GetState() ? Color.Green : Color.Gray;
            //皮帶線
            lbConveyorInput1.BackColor = ConveyorMechanism.HasDutInPosition1 ? Color.Green : Color.Gray;
            lbConveyorInput2.BackColor = ConveyorMechanism.HasDutInPosition2 ? Color.Green : Color.Gray;
            //XZ
            lbXZAreaVacuum.BackColor = XZMechanism.VacuumIsReach ? Color.Green : Color.Gray;
        }

        private void UpdateMotorPosition(object sender, EventArgs e)
        {
            UItimer.Stop();
            double x = 0;
            double y = 0;
            if (selectedMechanism != null) (x, y) = selectedMechanism.GetPosition();
            //double x = (selectedMechanism == null ? 0 : selectedMechanism.GetCurrentActualPosition());
            //double y = (selectedMechanism == null ? 0 : SelectedZ.GetCurrentActualPosition());  
            tbMotorPositionX.Text = x.ToString();
            tbMotorPositionZ.Text = y.ToString();
            UItimer.Start();
        }




        #region 圖片收集
        private void btnCollectImage_Click(object sender, EventArgs e)
        {
            //tsbCollectImage.Enabled = false;
            foreach (Emgu.CV.UI.ImageBox box in boxes)
            {
                if (box.Image != null) box.Image.Dispose();
                box.Image = null;
                box.Refresh();
            }
            Thread th = new Thread(new ThreadStart(CollectImageHandler));
            th.Start();
        }
        private void CollectImageHandler()
        {
            if (selectedCapture != null && selectedCapture.IsOpen)
            {
                selectedCapture.CamImageReady -= Cap_CamImageReady;
                selectedCapture.Stop();
            }
            try
            {
                for (int index = 0; index < caps.Length; index++)
                {
                    //BaslerVideoCapture
                    selectedCapture = caps[index];
                    if (selectedCapture != null)
                    {

                        selectedCapture.CamImageReady += Cap_CamImageReady;
                        waitCapture.Reset();
                        Thread.Sleep(100);
                        collectImage = true;
                        //cap1.Open(cameraResolution[index].Width, cameraResolution[index].Height);
                        selectedCapture.OneShot();
                        waitCapture.WaitOne();
                        selectedCapture.CamImageReady -= Cap_CamImageReady;
                        selectedCapture.Stop();
                        Thread.Sleep(50);
                        selectedCapture = null;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}\r\n{ex.StackTrace}", "Collect Image", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Invoke(new Action(() =>
                {
                    //tsbCollectImage.Enabled = true;
                }));
            }
        }
        private void CaptureImageOnlyCollection(Object data)
        {
            Object[] tmp = data as Object[];
            Bitmap bmp = tmp[0] as Bitmap;
            string timeStamp = tmp[1] as string;
            int serial = (int)tmp[2];
            int index = (int)tmp[3];
            timera = timeStamp;
            string SN = "";
            //string bigImage = Path.Combine(cfg.CollectImagePath, "big");
            //string smallImage = Path.Combine(cfg.CollectImagePath, "small");
            string bigImage = Path.Combine(cfg.CollectImagePath, $"{serial}_{index}", "big");
            string smallImage = Path.Combine(cfg.CollectImagePath, $"{serial}_{index}", "small");
            if (!Directory.Exists(bigImage)) Directory.CreateDirectory(bigImage);
            if (!Directory.Exists(smallImage)) Directory.CreateDirectory(smallImage);
            bigImage = Path.Combine(bigImage, DateTime.Now.ToString("yyyyMMdd"));
            smallImage = Path.Combine(smallImage, DateTime.Now.ToString("yyyyMMdd"));
            if (!Directory.Exists(smallImage)) Directory.CreateDirectory(smallImage);
            if (!Directory.Exists(bigImage)) Directory.CreateDirectory(bigImage);
            try
            {
                using (Image<Rgb, byte> img = new Image<Rgb, byte>(bmp))
                {
                    img.Save(Path.Combine(bigImage, $"{timeStamp}_{serial}_{ReadBarcodeIsn}_{index}.jpg"));
                    img.ROI = Rectangle.Empty;
                    int position = 0;
                    foreach (CaptureROI roi in ROIS.Where(x => x.serial == serial && x.index == index))
                    {
                        img.ROI = new Rectangle(roi.x, roi.y, roi.width, roi.height);
                        using (Image<Rgb, byte> img2 = img.Copy())
                        {
                            img2.Save(Path.Combine(smallImage, $"{timeStamp}_{serial}_{ReadBarcodeIsn}_{index}_{position}.jpg"));
                        }
                        img.ROI = Rectangle.Empty;
                        position++;
                    }

                }
            }
            finally
            {
                bmp.Dispose();
                waitCapture.Set();
            }


        }
        private void CaptureImageOnlyCollection1(Object data)
        {
            Object[] tmp = data as Object[];
            Bitmap bmp = tmp[0] as Bitmap;
            string timeStamp = tmp[1] as string;
            int serial = (int)tmp[2];
            int index = (int)tmp[3];
            timera = timeStamp;
            string SN = "";
            string bigImage = Path.Combine(cfg.CollectImagePath, $"BIGImage", "big");
            string smallImage = Path.Combine(cfg.CollectImagePath, $"{serial}_{index}", "small");
            if (!Directory.Exists(bigImage)) Directory.CreateDirectory(bigImage);
            if (!Directory.Exists(smallImage)) Directory.CreateDirectory(smallImage);
            bigImage = Path.Combine(bigImage, DateTime.Now.ToString("yyyyMMdd"));
            smallImage = Path.Combine(smallImage, DateTime.Now.ToString("yyyyMMdd"));
            if (!Directory.Exists(smallImage)) Directory.CreateDirectory(smallImage);
            if (!Directory.Exists(bigImage)) Directory.CreateDirectory(bigImage);
            try
            {
                using (Image<Rgb, byte> img = new Image<Rgb, byte>(bmp))
                {
                    img.Save(Path.Combine(bigImage, $"{timeStamp}_{serial}_{ReadBarcodeIsn}_{index}.jpg"));
                    img.ROI = Rectangle.Empty;
                    
                }
            }
            finally
            {
                bmp.Dispose();
                waitCapture.Set();
            }


        }
        #endregion

        #region ROI設置
        private void cbDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (selectedCapture == cbDevice.SelectedItem) return;
            if (selectedCapture != null && selectedCapture.IsOpen)
            {
                selectedCapture.Stop();
                selectedCapture.CamImageReady -= Cap_CamImageReady;
                Thread.Sleep(500);

            }
            selectedCapture = cbDevice.SelectedItem as BaslerVideoCapture;
            if (selectedCapture != null)
            {
                selectedCapture.CamImageReady += Cap_CamImageReady;
                //int index = cbDevice.SelectedIndex;
                //cap1.Open(cameraResolution[index].Width, cameraResolution[index].Height);
                ReflashSettingUI();
                selectedCapture.ContinuousShot();
            }
            //if (selectedCapture.Equals(RightCaptureMechanism.BaslerVideoCapture))
            //{
            //    if (RightCaptureMechanism.Current_Position == Mechanism_Position.Rotary) selectedCapture.index = 1;
            //    else selectedCapture.index = 0;
            //}
            //else if (selectedCapture.Equals(LeftCaptureMechanism.BaslerVideoCapture))
            //{
            //    if (LeftCaptureMechanism.Current_Position == Mechanism_Position.Rotary) selectedCapture.index = 1;
            //    else selectedCapture.index = 0;
            //}
            selectedROI = null;

        }

        public void ReflashSettingUI()
        {
            if (selectedCapture != null)
            {
                tbX.Maximum = selectedCapture.width;
                tbY.Maximum = selectedCapture.height;
                tbHeight.Maximum = selectedCapture.height;
                tbWidth.Maximum = selectedCapture.width;
                if (ROIS != null)
                {
                    dataGridView1.DataSource = ROIS.Where(i => i.serial == selectedCapture.serial && i.index == selectedCapture.index).ToList();
                }
            }
        }
        private void btnAddROI_Click(object sender, EventArgs e)
        {
            tbX.Value = 100;
            tbY.Value = 100;

            tbHeight.Value = 100;
            tbWidth.Value = 100;
            displayROI = true;
            dataGridView1.ClearSelection();
            if ((BaslerVideoCapture)cbDevice.SelectedItem != null)
            {
                selectedROI = new CaptureROI()
                {
                    serial = ((BaslerVideoCapture)cbDevice.SelectedItem).serial,
                    index = ((BaslerVideoCapture)cbDevice.SelectedItem).index,
                    x = tbX.Value,
                    y = tbY.Value,
                    width = tbWidth.Value,
                    height = tbHeight.Value,
                    mask = false,
                };
                ROIS.Add(selectedROI);
                UpdateDataGridViewForROI();
            }


            //dataGridView1.Refresh();
            //foreach(DataGridViewRow r in dataGridView1.Rows)
            //{
            //    if((int)r.Cells["x"].Value==selectedROI.x && (int)r.Cells["y"].Value == selectedROI.y && (int)r.Cells["width"].Value == selectedROI.width && (int)r.Cells["height"].Value == selectedROI.height)
            //    {
            //        r.Selected = true;
            //    }
            //}

            //dataGridView1.Rows[dataGridView1.Rows.Count - 1].Selected = true;
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {


        }

        private void btnDeleteROI_Click(object sender, EventArgs e)
        {
            displayROI = false;
            if (dataGridView1.SelectedRows != null && dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow r = dataGridView1.SelectedRows[0];
                int index = (int)r.Cells["index"].Value;
                int x = (int)r.Cells["x"].Value;
                int y = (int)r.Cells["y"].Value;
                int width = (int)r.Cells["width"].Value;
                int height = (int)r.Cells["height"].Value;
                ROIS.Remove(selectedROI);

                dataGridView1.ClearSelection();
                UpdateDataGridViewForROI();
                //selectedROI = null;
            }
        }

        private void ROI_Scroll(object sender, EventArgs e)
        {
            //ScrollBar sb = sender as ScrollBar;
            selectedROI.x = tbX.Value;
            selectedROI.y = tbY.Value;
            selectedROI.width = tbWidth.Value;
            selectedROI.height = tbHeight.Value;
            UpdateDataGridViewForROI();



        }
        private void UpdateDataGridViewForROI()
        {
            //var a = ROIS.Where(x => x.serial == selectedCapture.serial && x.index == selectedCapture.index).ToList();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = ROIS.Where(x => x.serial == selectedCapture.serial && x.index == selectedCapture.index).ToList();
            dataGridView1.Refresh();
        }

        private void btnSaveROI_Click(object sender, EventArgs e)
        {
            if (PO != null)
            {
                string full_Path = cfg.Models_Path;
                if (!Directory.Exists(full_Path)) Directory.CreateDirectory(full_Path);
                full_Path = Path.Combine(full_Path, $"{PO.Name}.XML");
                if (File.Exists(full_Path)) File.Delete(full_Path);
                if (tabNewModelSettings.SelectedTab == tpMotorPoints)
                {
                    switch (cbMotorPosition.SelectedItem)
                    {
                        case "旋轉機構初始位置":
                            PO.RotaryMechanism_Initial_Position = Convert.ToInt32(tbMotorPositionX.Text);
                            tbRotaryMechanismInitialPosition.Text = $"{PO.RotaryMechanism_Initial_Position} , 0";
                            break;
                        case "旋轉機構拍照位置":
                            PO.RotaryMechanism_Capture_X_Position = Convert.ToInt32(tbMotorPositionX.Text);
                            PO.RotaryMechanism_Capture_Z_Position = Convert.ToInt32(tbMotorPositionZ.Text);
                            tbRotaryMechanismCapturePosition.Text = $"{PO.RotaryMechanism_Capture_X_Position} , {PO.RotaryMechanism_Capture_Z_Position}";
                            break;
                        case "旋轉機構旋轉位置":
                            PO.RotaryMechanism_Rotary_X_Position = Convert.ToInt32(tbMotorPositionX.Text);
                            PO.RotaryMechanism_Rotary_Z_Position = Convert.ToInt32(tbMotorPositionZ.Text);
                            PO.RotaryMechanism_Final_Z_Position = PO.RotaryMechanism_Rotary_Z_Position;
                            tbRotaryMechansimRotaryPosition.Text = $"{PO.RotaryMechanism_Rotary_X_Position} , {PO.RotaryMechanism_Rotary_Z_Position}";
                            tbRotaryMechanismFinalPosition.Text = $"{PO.RotaryMechanism_Final_X_Position} , {PO.RotaryMechanism_Final_Z_Position}";
                            break;
                        case "旋轉機構吸取位置":
                            PO.RotaryMechanism_Final_X_Position = Convert.ToInt32(tbMotorPositionX.Text);
                            PO.RotaryMechanism_Final_Z_Position = Convert.ToInt32(tbMotorPositionZ.Text);
                            tbRotaryMechanismFinalPosition.Text = $"{PO.RotaryMechanism_Final_X_Position} , {PO.RotaryMechanism_Final_Z_Position}";
                            break;
                        case "XZ機構初始位置":
                            PO.XZMechanism_Initila_X_position = Convert.ToInt32(tbMotorPositionX.Text);
                            PO.XZMechanism_Initila_Z_position = Convert.ToInt32(tbMotorPositionZ.Text);
                            tbXZMechanismInitialPosition.Text = $"{PO.XZMechanism_Initila_X_position} , {PO.XZMechanism_Initila_Z_position}";
                            break;
                        case "XZ機構吸取位置":
                            PO.XZMechanism_Clamp_X_Position = Convert.ToInt32(tbMotorPositionX.Text);
                            PO.XZMechanism_Clamp_Z_Position = Convert.ToInt32(tbMotorPositionZ.Text);
                            tbXZMechanismClampPosition.Text = $"{PO.XZMechanism_Clamp_X_Position} , {PO.XZMechanism_Clamp_Z_Position}";
                            break;
                        case "XZ機構拍照位置":
                            PO.XZMechanism_Capture_X_Position = Convert.ToInt32(tbMotorPositionX.Text);
                            PO.XZMechanism_Capture_Z_Position = Convert.ToInt32(tbMotorPositionZ.Text);
                            tbXZMechanismCapturePosition.Text = $"{PO.XZMechanism_Capture_X_Position} , {PO.XZMechanism_Capture_Z_Position}";
                            break;
                        case "XZ機構釋放位置":
                            PO.XZMechanism_Relax_X_Position = Convert.ToInt32(tbMotorPositionX.Text);
                            PO.XZMechanism_Relax_Z_Position = Convert.ToInt32(tbMotorPositionZ.Text);
                            tbXZMechanismRelaxPosition.Text = $"{PO.XZMechanism_Relax_X_Position} , {PO.XZMechanism_Relax_Z_Position}";
                            break;
                        case "XZ機構釋放Fail位置":
                            PO.XZMechanism_Relax_X_Position2 = Convert.ToInt32(tbMotorPositionX.Text);
                            PO.XZMechanism_Relax_Z_Position2 = Convert.ToInt32(tbMotorPositionZ.Text);
                            tbXZFailMechanismRelaxPosition.Text = $"{PO.XZMechanism_Relax_X_Position2} , {PO.XZMechanism_Relax_Z_Position2}";
                            break;
                        case "左相機位置調整":
                            PO.LeftCapture_X_Position = Convert.ToInt32(tbMotorPositionX.Text);
                            tbLeftCapturePosition.Text = PO.LeftCapture_X_Position.ToString();
                            break;
                        case "右相機位置調整":
                            PO.RightCapture_X_Position = Convert.ToInt32(tbMotorPositionX.Text);
                            tbRightCapturePosition.Text = PO.RightCapture_X_Position.ToString();
                            break;
                    }
                }

                PO.Save(full_Path);
            }
            else
            {
                MessageBox.Show("請先新增機種~~", "機種設置儲存", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void btnDenominator_Click(object sender, EventArgs e)
        {
            string denominator = "1";
            int divider = 1;
            NormalBox.InputBox("截圖等分", "等分數目:", ref denominator);
            if (!string.IsNullOrEmpty(denominator) && int.TryParse(denominator, out divider))
            {
                if (sender == btnWidthBeDivide)
                {
                    double scalar = (double)selectedROI.width / (double)divider;
                    for (int i = 1; i <= divider; i++)
                    {
                        Rectangle rec;
                        int x = selectedROI.x + (int)((i - 1) * scalar);
                        int y = selectedROI.y;
                        int delta_Width = 0;
                        if (i < divider) delta_Width = (int)(i * scalar) + selectedROI.x - x;
                        else delta_Width = selectedROI.width + selectedROI.x - x;
                        int height = selectedROI.height;
                        //rec = new Rectangle(x, y, delta_Width, height);
                        CaptureROI r = new ImageCapture.CaptureROI()
                        {
                            serial = selectedROI.serial,
                            index = selectedROI.index,
                            x = x,
                            y = y,
                            width = delta_Width,
                            height = height,
                        };
                        ROIS.Add(r);
                    }
                }
                else
                {
                    double scalar = (double)selectedROI.height / (double)divider;
                    for (int i = 1; i <= divider; i++)
                    {
                        int x = selectedROI.x;
                        int y = selectedROI.y + (int)((i - 1) * scalar);
                        int delta_height = 0;
                        if (i < divider) delta_height = (int)(i * scalar) + selectedROI.y - y;
                        else delta_height = selectedROI.height + selectedROI.y - y;
                        int width = selectedROI.width;
                        //rec = new Rectangle(x, y, delta_Width, height);
                        CaptureROI r = new ImageCapture.CaptureROI()
                        {
                            serial = selectedROI.serial,
                            index = selectedROI.index,
                            x = x,
                            y = y,
                            width = width,
                            height = delta_height,
                            mask = false,
                        };
                        ROIS.Add(r);
                    }
                }

                ROIS.Remove(selectedROI);
                selectedROI = null;
                UpdateDataGridViewForROI();
            }
        }

        private void dataGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (selectedROI != null)
            {
                foreach (DataGridViewRow r in dataGridView1.Rows)
                {
                    if ((int)r.Cells["x"].Value == selectedROI.x && (int)r.Cells["y"].Value == selectedROI.y && (int)r.Cells["width"].Value == selectedROI.width && (int)r.Cells["height"].Value == selectedROI.height)
                    {
                        r.Selected = true;
                    }
                }
            }
            else dataGridView1.ClearSelection();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
            {
                displayROI = false;
                if (dataGridView1.SelectedRows != null && dataGridView1.SelectedRows.Count > 0)
                {
                    DataGridViewRow r = dataGridView1.SelectedRows[0];
                    int serial = (int)r.Cells["serial"].Value;
                    int index = (int)r.Cells["index"].Value;
                    int x = (int)r.Cells["x"].Value;
                    int y = (int)r.Cells["y"].Value;
                    int width = (int)r.Cells["width"].Value;
                    int height = (int)r.Cells["height"].Value;
                    bool mask = (bool)r.Cells["mask"].Value;
                    string category = (string)r.Cells["category"].Value;
                    selectedROI = ROIS.Where(i => i.serial == serial && i.index == index && i.x == x && i.y == y && i.width == width && i.height == height).FirstOrDefault();
                    tbX.Value = selectedROI.x;
                    tbY.Value = selectedROI.y;
                    tbWidth.Value = selectedROI.width;
                    tbHeight.Value = selectedROI.height;
                    selectedROI.mask = mask;
                    selectedROI.category = category;
                    displayROI = true;
                }
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                displayROI = false;
                DataGridViewRow r = dataGridView1.Rows[e.RowIndex];
                r.Selected = true;
                int serial = (int)r.Cells["serial"].Value;
                int index = (int)r.Cells["index"].Value;
                int x = (int)r.Cells["x"].Value;
                int y = (int)r.Cells["y"].Value;
                int width = (int)r.Cells["width"].Value;
                int height = (int)r.Cells["height"].Value;
                selectedROI = ROIS.Where(i => i.serial == serial && i.index == index && i.x == x && i.y == y && i.width == width && i.height == height).FirstOrDefault();
                tbX.Value = selectedROI.x;
                tbY.Value = selectedROI.y;
                tbWidth.Value = selectedROI.width;
                tbHeight.Value = selectedROI.height;
                displayROI = true;
            }
        }
        #endregion

        private void btnDebug_Click(object sender, EventArgs e)
        {
            //btnTest.Enabled = false;
            current_step = Test_Step.wait_dut_in;
            TaskTimer.Elapsed += Timer_Elapsed;
            TaskTimer.Enabled = true;
            TaskTimer.AutoReset = false;

            //btnTest.Text = "Running";
        }

        private void tbPSelectModel_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (TaskTimer.Enabled && e.TabPage == tpSetting) e.Cancel = true;

        }

        private void tsbLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "XML file|*.XML";
            openFileDialog.Multiselect = false;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                LoadParameters(Path.GetFileNameWithoutExtension(openFileDialog.FileName));
                if (PO != null)
                {
                    LeftCaptureMechanism?.AbsoluteMove(PO.LeftCapture_X_Position, 0);
                    RightCaptureMechanism?.AbsoluteMove(PO.RightCapture_X_Position, 0);
                }

                if (tabMain.SelectedTab == tpSetting)
                {
                    ReflashSettingUI();
                }
                tslProduct_Name.Text = $"當前運行機種: {(string.IsNullOrEmpty(Product_Name) ? "NA" : Product_Name)}";
                cfg.CurrentModel = Product_Name;
                lbModelName.Text = Product_Name;
            }
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {

        }
        #region IO手動點擊
        private void ioButton_Click(object sender, EventArgs e)
        {
            switch (((Button)sender).Name)
            {
                case "btnRotationAreaClampOrRelax"://旋轉機構 夾緊/鬆開
                    RotaryMechanism.SetClamp(!RotaryMechanism.Clamp);
                    Thread.Sleep(10);
                    ((Button)sender).Text = RotaryMechanism.Clamp ? "Relax(鬆開)" : "Clamp(夾緊)";
                    break;
                case "btnRotationAreaVacuum":
                    RotaryMechanism.SetVacuum(!RotaryMechanism.VacuumON);
                    Thread.Sleep(10);
                    ((Button)sender).Text = RotaryMechanism.VacuumON ? "Vacuum(吸真空) OFF" : "Vacuum(吸真空) ON";
                    break;
                case "btnXZAreaVacuum":
                    XZMechanism.SetVacuum(!XZMechanism.VacuumOn);
                    Thread.Sleep(10);
                    ((Button)sender).Text = XZMechanism.VacuumOn ? "Vacuum(吸真空) OFF" : "Vacuum(吸真空) ON";
                    break;
                case "btnXZAreaBreakVacuum":
                    XZMechanism.SetBreakVacuum(!XZMechanism.BreakVacuumOn);
                    Thread.Sleep(10);
                    ((Button)sender).Text = XZMechanism.BreakVacuumOn ? "Break Vacuum (破真空) OFF" : "Break Vacuum (破真空) ON";
                    break;
                case "btnConveyor":
                    ConveyorMechanism.Conveyor2(!ConveyorMechanism.ConveyorIsRunning);
                    Thread.Sleep(10);
                    ((Button)sender).Text = ConveyorMechanism.ConveyorIsRunning ? "Conveyor(皮帶2) OFF" : "Conveyor(皮帶2) ON";
                    break;
                case "btnUpDownAreaConveyor":
                    UpDownMechanism.Conveyor(!UpDownMechanism.ConveyorIsRunning);
                    Thread.Sleep(10);
                    ((Button)sender).Text = UpDownMechanism.ConveyorIsRunning ? "Conveyor(皮帶1) OFF" : "Conveyor(皮帶1) ON";
                    break;
                case "btnFailAreaConveyor":
                    OutputMechanism.Conveyor(!OutputMechanism.ConveyorIsRunning);
                    Thread.Sleep(10);
                    ((Button)sender).Text = OutputMechanism.ConveyorIsRunning ? "Conveyor(皮帶) OFF" : "Conveyor(皮帶) ON";
                    break;
                case "BtnLightControl":
                    if (ColorLight.LightControl.State)
                    {
                        ColorLight.LightControl.WriteState(false);
                        ((Button)sender).Text = "光源 OFF";
                    }
                    else
                    {
                        ColorLight.LightControl.WriteState(true);
                        ((Button)sender).Text = "光源 ON";
                    }
                    break;
                case "btn3ColorRed":
                    if (ColorLight.redLight.State)
                    {
                        ColorLight.redLight.WriteState(false);
                        ((Button)sender).Text = "Red(紅燈) ON";
                    }
                    else
                    {
                        ColorLight.redLight.WriteState(true);
                        ((Button)sender).Text = "Red(紅燈) OFF";
                    }
                    break;
                case "btn3ColorGreen":
                    if (ColorLight.greenLight.State)
                    {
                        ColorLight.greenLight.WriteState(false);
                        ((Button)sender).Text = "Green(綠燈) ON";
                    }
                    else
                    {
                        ColorLight.greenLight.WriteState(true);
                        ((Button)sender).Text = "Green(綠燈) OFF";
                    }
                    break;
                case "btn3ColorYellow":
                    if (ColorLight.yellowLight.State)
                    {
                        ColorLight.yellowLight.WriteState(false);
                        ((Button)sender).Text = "Green(黃燈) ON";
                    }
                    else
                    {
                        ColorLight.yellowLight.WriteState(true);
                        ((Button)sender).Text = "Green(黃燈) OFF";
                    }
                    break;
                case "btn3ColorAlarm":
                    if (ColorLight.buzzer.State)
                    {
                        ColorLight.buzzer.WriteState(false);
                        ((Button)sender).Text = "Alarm(蜂鳴器) ON";
                    }
                    else
                    {
                        ColorLight.buzzer.WriteState(true);
                        ((Button)sender).Text = "Alarm(蜂鳴器) OFF";
                    }
                    break;

            }
        }
        #endregion

        #region Motor手動
        private void rbMotor_Move_Parameters_CheckedChanged(object sender, EventArgs e)
        {
            if (((RadioButton)sender).Checked == false) return;

            //IMotorInterface mechanism = null;
            //if (tabSettings.SelectedTab == tpRotaryArea)
            //{
            //    mechanism = RotaryMechanism;
            //}
            //else if (tabSettings.SelectedTab == tpXZArea)
            //{
            //    mechanism = XZMechanism;
            //}
            //else if (tabSettings.SelectedTab == tpSetting && cbDevice.SelectedItem.Equals(LeftCaptureMechanism.BaslerVideoCapture))
            //{
            //    mechanism = LeftCaptureMechanism;
            //}
            //else if (tabSettings.SelectedTab == tpSetting && cbDevice.SelectedItem.Equals(LeftCaptureMechanism.BaslerVideoCapture))
            //{
            //    mechanism = RightCaptureMechanism;
            //}
            if (selectedMechanism != null)
            {
                //int motor_Move_Distance = mechanism.Motor_Move_Distance;
                //Velocity velocity = mechanism.Velocity;
                switch ((sender as RadioButton).Name)
                {
                    case "rb1mm":
                        selectedMechanism.Motor_Move_Distance = 1;
                        break;
                    case "rb2mm":
                        selectedMechanism.Motor_Move_Distance = 2;
                        break;
                    case "rb5mm":
                        selectedMechanism.Motor_Move_Distance = 5;
                        break;
                    case "rb10mm":
                        selectedMechanism.Motor_Move_Distance = 10;
                        break;
                    case "rbLow_Velocity":
                        selectedMechanism.Velocity = Velocity.Low;
                        break;
                    case "rbMedium_Velocity":
                        selectedMechanism.Velocity = Velocity.Medium;
                        break;
                    case "rbHigh_Velocity":
                        selectedMechanism.Velocity = Velocity.High;
                        break;

                }
            }


        }
        private void Motor_Manul_Button_Click(object sender, EventArgs e)
        {
            if (backgroundWorker1.IsBusy) return;
            //IMotorInterface mechanism= null;
            //if (tabSettings.SelectedTab == tpRotaryArea) mechanism = RotaryMechanism;
            //else if (tabSettings.SelectedTab == tpXZArea) mechanism = XZMechanism;
            //else if (tabSettings.SelectedTab == tpSetting && cbDevice.SelectedItem.Equals(LeftCaptureMechanism.BaslerVideoCapture))
            //{
            //    mechanism = LeftCaptureMechanism;
            //}
            //else if (tabSettings.SelectedTab == tpSetting && cbDevice.SelectedItem.Equals(RightCaptureMechanism.BaslerVideoCapture))
            //{
            //    mechanism = RightCaptureMechanism;
            //}
            //else return;
            int distance = rb1mm.Checked ? 1 : (rb2mm.Checked ? 2 : (rb5mm.Checked ? 5 : 10));
            if (selectedMechanism == null) return;
            else if (sender.Equals(btnMotorResetError))//reset error
            {
                selectedMechanism.ResetError();
                return;
            }
            else if (sender.Equals(btnMotorServoOnOff))//servo on/off
            {
                if (selectedMechanism.IsServoOn())
                {
                    selectedMechanism.ServoOff();
                    ((Button)sender).Text = "Servo On";
                }
                else
                {
                    selectedMechanism.ServoOn();
                    ((Button)sender).Text = "Servo Off";
                }
            }
            else if (((Button)sender).Equals(btnStopMotor))//stop motor
            {
                //backgroundWorker1.RunWorkerAsync(new object[] { mechanism, "Stop" });
                selectedMechanism.Stop();
                //backgroundWorker1.CancelAsync();
            }
            else if (sender.Equals(btnGoHome)) //go home
            //{
            //    backgroundWorker1.RunWorkerAsync(new object[] { selectedMechanism, "Home" });
            //}
            //else if (sender.Equals(btnXPositive))
            //{
            //    backgroundWorker1.RunWorkerAsync(new object[] { selectedMechanism, "X", -distance });
            //}
            //else if (sender.Equals(btnXNegative))
            //{
            //    backgroundWorker1.RunWorkerAsync(new object[] { selectedMechanism, "X", distance });
            //}
            //else if (sender.Equals(btnZPositive))
            //{
            //    backgroundWorker1.RunWorkerAsync(new object[] { selectedMechanism, "Z", distance });
            //}
            //else if (sender.Equals(btnZNegative))
            //{
            //    backgroundWorker1.RunWorkerAsync(new object[] { selectedMechanism, "Z", -distance });
            //}
            {
                backgroundWorker1.RunWorkerAsync(new object[] { selectedMechanism, "Home" });
            }
            else if (sender.Equals(btnXPositive))
            {
                backgroundWorker1.RunWorkerAsync(new object[] { selectedMechanism, "X", -distance });
            }
            else if (sender.Equals(btnXNegative))
            {
                backgroundWorker1.RunWorkerAsync(new object[] { selectedMechanism, "X", distance });
            }
            else if (sender.Equals(btnZPositive))
            {
                backgroundWorker1.RunWorkerAsync(new object[] { selectedMechanism, "Z", distance });
            }
            else if (sender.Equals(btnZNegative))
            {
                backgroundWorker1.RunWorkerAsync(new object[] { selectedMechanism, "Z", -distance });
            }
            else return;


        }

        #endregion

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            object[] data = e.Argument as object[];

            IMotorInterface mechanism = (IMotorInterface)data[0];
            try
            {
                switch ((String)(data[1]))
                {
                    case "Home":
                        mechanism.ResetError();
                        mechanism.Home();
                        break;
                    case "X":
                        mechanism.RelativeMove((int)data[2] * 1000, 0);
                        break;
                    case "Z":
                        mechanism.RelativeMove(0, (int)data[2] * 4000);
                        break;
                    case "Stop":
                        mechanism.Stop();
                        break;
                    case "AbsoluteMove":
                        if (mechanism.Equals(RotaryMechanism) && ((Mechanism_Position)data[4]) == Mechanism_Position.Initial)
                        {
                            RotaryMechanism.AbsoluteMove_RotationFirst((int)data[2], (int)data[3]);
                        }
                        else
                            mechanism.AbsoluteMove((int)data[2], (int)data[3]);
                        break;

                }

                TimeCounter timeCounter = new TimeCounter(40 * 1000);
                if (timeCounter.Start(() => mechanism.Ready(), true))
                {
                    if ((string)data[1] == "Home")
                    {
                        //Thread.Sleep(1000);
                        mechanism.ResetPosition();
                    }
                    e.Result = e.Argument;
                }
                else
                {
                    throw new Exception("馬達運動超時");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                log.wrieException(e.Error);
                MessageBox.Show(e.Error.Message, "馬達運動", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                object[] data = e.Result as object[];
                IMotorInterface mechanism = data[0] as IMotorInterface;
                //if (((string)data[1]).Equals("Home"))
                //{
                //    tbMotorPositionX.Text = "0";
                //    tbMotorPositionZ.Text = "0";
                //}
                if (((string)data[1]).Equals("AbsoluteMove"))
                {
                    mechanism.Current_Position = (Mechanism_Position)data[4];
                    if (mechanism.Current_Position == Mechanism_Position.Capture)
                    {
                        LeftCaptureMechanism.BaslerVideoCapture.index = 0;
                        RightCaptureMechanism.BaslerVideoCapture.index = 0;
                    }
                    else if (mechanism.Current_Position == Mechanism_Position.Rotary)
                    {
                        LeftCaptureMechanism.BaslerVideoCapture.index = 1;
                        RightCaptureMechanism.BaslerVideoCapture.index = 1;
                    }
                    UpdateDataGridViewForROI();
                }
            }
        }

        private void btnAddNewModel_Click(object sender, EventArgs e)
        {
            string modelName = Product_Name;
            pegatron.basic.NormalBox.InputBox("儲存", "請輸入機種名稱:", ref modelName);
            PO = new ProductOutward()
            {
                Name = modelName,
            };
            ReflashMotorUIPosition();
            lbModelName.Text = modelName;
        }
        private void ReflashMotorUIPosition()
        {
            tbRotaryMechanismInitialPosition.Text = $"{PO.RotaryMechanism_Initial_Position} , 0";
            tbRotaryMechanismCapturePosition.Text = $"{PO.RotaryMechanism_Capture_X_Position} , {PO.RotaryMechanism_Capture_Z_Position}";
            tbRotaryMechansimRotaryPosition.Text = $"{PO.RotaryMechanism_Rotary_X_Position} , {PO.RotaryMechanism_Rotary_Z_Position}";
            tbRotaryMechanismFinalPosition.Text = $"{PO.RotaryMechanism_Final_X_Position} , {PO.RotaryMechanism_Final_Z_Position}";
            tbXZMechanismInitialPosition.Text = $"{PO.XZMechanism_Initila_X_position} , {PO.XZMechanism_Initila_Z_position}";
            tbXZMechanismClampPosition.Text = $"{PO.XZMechanism_Clamp_X_Position} , {PO.XZMechanism_Clamp_Z_Position}";
            tbXZMechanismCapturePosition.Text = $"{PO.XZMechanism_Capture_X_Position} , {PO.XZMechanism_Capture_Z_Position}";
            tbXZMechanismRelaxPosition.Text = $"{PO.XZMechanism_Relax_X_Position} , {PO.XZMechanism_Relax_Z_Position}";
            tbXZFailMechanismRelaxPosition.Text = $"{PO.XZMechanism_Relax_X_Position2},{PO.XZMechanism_Relax_Z_Position2}";
            tbLeftCapturePosition.Text = PO.LeftCapture_X_Position.ToString();
            tbRightCapturePosition.Text = PO.RightCapture_X_Position.ToString();
        }


        private void cbRotatryMotorPosition_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (PO != null)
            {
                if (selectedMotorIndex != cbMotorPosition.SelectedIndex) selectedROI = null;
                switch (cbMotorPosition.SelectedItem)
                {
                    case "旋轉機構初始位置":
                        //gbMotorMotion.Enabled = true;
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = false;
                        btnZPositive.Enabled = false;
                        selectedMechanism = RotaryMechanism;
                        backgroundWorker1.RunWorkerAsync(new object[] { RotaryMechanism, "AbsoluteMove", PO.RotaryMechanism_Initial_Position, 0, Mechanism_Position.Initial });
                        break;
                    case "旋轉機構拍照位置":
                        //gbMotorMotion.Enabled = true;
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = true;
                        btnZPositive.Enabled = true;
                        selectedMechanism = RotaryMechanism;
                        //gbROISettings.Enabled = true;
                        backgroundWorker1.RunWorkerAsync(new object[] { RotaryMechanism, "AbsoluteMove", PO.RotaryMechanism_Capture_X_Position, PO.RotaryMechanism_Capture_Z_Position, Mechanism_Position.Capture });
                        break;
                    case "旋轉機構旋轉位置":
                        //gbMotorMotion.Enabled = true;
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = true;
                        btnZPositive.Enabled = true;
                        gbROISettings.Enabled = true;
                        selectedMechanism = RotaryMechanism;
                        backgroundWorker1.RunWorkerAsync(new object[] { RotaryMechanism, "AbsoluteMove", PO.RotaryMechanism_Rotary_X_Position, PO.RotaryMechanism_Rotary_Z_Position, Mechanism_Position.Rotary });
                        break;
                    case "旋轉機構吸取位置":
                        //gbMotorMotion.Enabled = true;
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = true;
                        btnZPositive.Enabled = true;
                        selectedMechanism = RotaryMechanism;
                        backgroundWorker1.RunWorkerAsync(new object[] { RotaryMechanism, "AbsoluteMove", PO.RotaryMechanism_Final_X_Position, PO.RotaryMechanism_Final_Z_Position, Mechanism_Position.Final });
                        break;
                    case "XZ機構初始位置":
                        //gbMotorMotion.Enabled = true;
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = true;
                        btnZPositive.Enabled = true;
                        //gbROISettings.Enabled = false;
                        selectedMechanism = XZMechanism;
                        backgroundWorker1.RunWorkerAsync(new object[] { XZMechanism, "AbsoluteMove", PO.XZMechanism_Initila_X_position, PO.XZMechanism_Initila_Z_position, Mechanism_Position.Initial });
                        break;
                    case "XZ機構吸取位置":
                        //gbMotorMotion.Enabled = true;
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = true;
                        btnZPositive.Enabled = true;
                        selectedMechanism = XZMechanism;
                        if (XZMechanism.Current_Position == Enumes.Mechanism_Position.Relax)
                        {
                            MessageBox.Show("當前馬達位置，不允許移至吸取位置", "馬達移動", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        backgroundWorker1.RunWorkerAsync(new object[] { XZMechanism, "AbsoluteMove", PO.XZMechanism_Clamp_X_Position, PO.XZMechanism_Clamp_Z_Position, Mechanism_Position.Clamp });
                        break;
                    case "XZ機構拍照位置":
                        //gbMotorMotion.Enabled = true;
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = true;
                        btnZPositive.Enabled = true;
                        selectedMechanism = XZMechanism;
                        backgroundWorker1.RunWorkerAsync(new object[] { XZMechanism, "AbsoluteMove", PO.XZMechanism_Capture_X_Position, PO.XZMechanism_Capture_Z_Position, Mechanism_Position.Capture });
                        break;
                    case "XZ機構釋放位置":
                        //gbMotorMotion.Enabled = true;
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = true;
                        btnZPositive.Enabled = true;
                        selectedMechanism = XZMechanism;
                        if (XZMechanism.Current_Position == Enumes.Mechanism_Position.Clamp)
                        {
                            MessageBox.Show("當前馬達位置，不允許移至吸取位置", "馬達移動", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        backgroundWorker1.RunWorkerAsync(new object[] { XZMechanism, "AbsoluteMove", PO.XZMechanism_Relax_X_Position, PO.XZMechanism_Relax_Z_Position, Mechanism_Position.Relax });
                        break;
                    case "XZ機構釋放Fail位置":
                        //gbMotorMotion.Enabled = true;
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = true;
                        btnZPositive.Enabled = true;
                        selectedMechanism = XZMechanism;
                        if (XZMechanism.Current_Position == Enumes.Mechanism_Position.Clamp)
                        {
                            MessageBox.Show("當前馬達位置，不允許移至Fail釋放位置", "馬達移動", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        backgroundWorker1.RunWorkerAsync(new object[] { XZMechanism, "AbsoluteMove", PO.XZMechanism_Relax_X_Position2, PO.XZMechanism_Relax_Z_Position2, Mechanism_Position.Relax });
                        break;
                    case "左相機位置調整":
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = false;
                        btnZPositive.Enabled = false;
                        selectedMechanism = LeftCaptureMechanism;
                        backgroundWorker1.RunWorkerAsync(new object[] { LeftCaptureMechanism, "AbsoluteMove", PO.LeftCapture_X_Position, 0, Mechanism_Position.Initial });
                        break;
                    case "右相機位置調整":
                        btnXNegative.Enabled = true;
                        btnXPositive.Enabled = true;
                        btnZNegative.Enabled = false;
                        btnZPositive.Enabled = false;
                        selectedMechanism = RightCaptureMechanism;
                        backgroundWorker1.RunWorkerAsync(new object[] { RightCaptureMechanism, "AbsoluteMove", PO.RightCapture_X_Position, 0, Mechanism_Position.Initial });
                        break;


                }
                if (selectedMechanism != null)
                {
                    selectedMotorIndex = cbMotorPosition.SelectedIndex;
                    if (selectedMechanism.Velocity == Velocity.High) rbHigh_Velocity.Checked = true;
                    else if (selectedMechanism.Velocity == Velocity.Medium) rbMedium_Velocity.Checked = true;
                    else rbLow_Velocity.Checked = true;
                    if (selectedMechanism.Motor_Move_Distance == 1) rb1mm.Checked = true;
                    else if (selectedMechanism.Motor_Move_Distance == 2) rb2mm.Checked = true;
                    else if (selectedMechanism.Motor_Move_Distance == 5) rb5mm.Checked = true;
                    else rb10mm.Checked = true;
                }
            }
            else
            {
                MessageBox.Show("未新增機種或載入機種", "馬達點位", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void VelocityChange(object sender, EventArgs e)
        {
            ((ToolStripMenuItem)sender).Image = Properties.Resources.selected;
            if (sender.Equals(tsmiHighVelocity))
            {
                Velocity = Velocity.High;
                tsmiMediumVelocity.Image = null;
                tsmiLowVelocity.Image = null;
                //RotaryMechanism.Velocity = Velocity.High;
                //XZMechanism.Velocity = Velocity.High;
            }
            else if (sender.Equals(tsmiMediumVelocity))
            {
                Velocity = Velocity.Medium;
                tsmiHighVelocity.Image = null;
                tsmiLowVelocity.Image = null;
                //RotaryMechanism.Velocity = Velocity.Medium;
                //XZMechanism.Velocity = Velocity.Medium;
            }
            else
            {
                Velocity = Velocity.Low;
                tsmiHighVelocity.Image = null;
                tsmiMediumVelocity.Image = null;
                //RotaryMechanism.Velocity = Velocity.Low;
                //XZMechanism.Velocity = Velocity.Low;
            }
            if (tabMain.SelectedTab == tpSetting && tabNewModelSettings.SelectedTab == tpMotorPoints && cbMotorPosition.SelectedIndex >= 0)
            {
                rbHigh_Velocity.CheckedChanged -= rbMotor_Move_Parameters_CheckedChanged;
                rbMedium_Velocity.CheckedChanged -= rbMotor_Move_Parameters_CheckedChanged;
                rbLow_Velocity.CheckedChanged -= rbMotor_Move_Parameters_CheckedChanged;
                if (Velocity == Velocity.High) rbHigh_Velocity.Checked = true;
                else if (Velocity == Velocity.Medium) rbMedium_Velocity.Checked = true;
                else rbLow_Velocity.Checked = true;
                rbHigh_Velocity.CheckedChanged += rbMotor_Move_Parameters_CheckedChanged;
                rbMedium_Velocity.CheckedChanged += rbMotor_Move_Parameters_CheckedChanged;
                rbLow_Velocity.CheckedChanged += rbMotor_Move_Parameters_CheckedChanged;
            }


            XZMechanism.Velocity = Velocity;
            RotaryMechanism.Velocity = Velocity;
            RightCaptureMechanism.Velocity = Velocity;
            LeftCaptureMechanism.Velocity = Velocity;
        }

        private void tsmiLowVelocity_Click(object sender, EventArgs e)
        {

        }

        private void RunMode_Click(object sender, EventArgs e)
        {
            ((ToolStripMenuItem)sender).Image = Properties.Resources.selected;
            if (sender.Equals(tsmiNormalTest))
            {
                RunMode = TestMode.Test_Mode;
                tsmiCollectImageMode.Image = null;
                tsmiConveyorMode.Image = null;
            } else if (sender.Equals(tsmiCollectImageMode))
            {
                RunMode = TestMode.Collect_Image_Mode;
                tsmiNormalTest.Image = null;
                tsmiConveyorMode.Image = null;
            }
            else
            {
                RunMode = TestMode.Conveyor_Mode;
                tsmiCollectImageMode.Image = null;
                tsmiNormalTest.Image = null;
            }
        }

        private void tsmiStopAfterClearDUT_Click(object sender, EventArgs e)
        {
            IsRunning = false;
            tsmiStartButton.Enabled = false;
            tsmiStopAfterClearDUT.Enabled = false;
        }

        private void tsmiResetDecisionMechanismResults_Click(object sender, EventArgs e)
        {
            DecisionMechanism?.ClearResults();
        }
        public void ControlPointBelt()
        {
            if (RBtnSamePlacement.Checked == true)
            {
                DecisionMechanism.SamePlacement = true;
                DecisionMechanism.PlaceSeparately = false;
            }
            else if (RBtnPlaceSeparately.Checked == true)
            {
                DecisionMechanism.PlaceSeparately = true;
                DecisionMechanism.SamePlacement = false;
                if (RBtnForeward.Checked == true)
                {
                    DecisionMechanism.Foreward = true;
                    DecisionMechanism.Reverse = false;
                }
                else
                {
                    DecisionMechanism.Foreward = false;
                    DecisionMechanism.Reverse = true;
                }
            }
        }
        public void FailTrayTimer(object sender, EventArgs e)
        {
            if (UpDownMechanism.FailLaydownarea && (ConveyorMechanism.HasDutInPosition2 || ConveyorMechanism.HasDutInPosition1))
            {
                ColorLight.FailError();
            }
            else
            {
                ColorLight.Normal();
            }

        }
        private void ReadBarcode()
        {
            UpdateMsg("等待检查", Color.Blue);
            int Q = cfg.BarcodeLength;
            int index = 0;
            int position = cfg.ImageBarcodePoint;
            string timer = timera;
            string ImageBarcode = "";
            string ImageTimerpp = "";
            ImageTimerpp = ImageProcess.timer;
            selectedCapture.serial = cfg.BarcodeCameraSN;
            string smallImage = Path.Combine(cfg.CollectImagePath, $"{selectedCapture.serial}_{index}", "small");
            string predict_temporary_path = Path.Combine(cfg.ImagePath/*, $"{selectedCapture.serial}_{index}"*/);
            string ImageP = Path.Combine(predict_temporary_path, $"{selectedCapture.serial}_{index}_{ImageTimerpp}_{position}.png");
            smallImage = Path.Combine(smallImage, DateTime.Now.ToString("yyyyMMdd"));
            string image = Path.Combine(smallImage, $"{timera}_{selectedCapture.serial}_{ReadBarcodeIsn}_{index}_{position}.png");
            string isn = null;

            if (RunMode == TestMode.Test_Mode)
            {
                ImageBarcode = ImageP;
            }
            else
            {
                ImageBarcode = image;
            }
            BarcodeReader reader = new BarcodeReader();
            using (Bitmap bmp = new Bitmap(ImageBarcode))
            {
                Result result = reader.Decode(bmp);
                if (result != null)
                {
                    //isn = result.Text;
                    isn = result.Text.Substring(0, Q);
                    ReadBarcodeIsn = isn;
                    ReadBarcodeIsn1 = isn;
                    log.write($"{isn} 条码识别成功.");
                    Test_Barcode = true;
                }
                else
                {
                    log.write("识别条码失败");
                    Test_Barcode = false;
                }
            }
        }
        public void Light(bool on)
        {
            if (cfg.Light_Control)
            {
                if (on)
                {
                    ColorLight.ControlLightOn();
                }
                else
                {
                    ColorLight.ControlLightOff();
                }
            }
        }
        public string msg { get; set; }
        public delegate void stringhandler(string msg);
        public event stringhandler OnMessageCreate;
        public bool SFISresult { get; private set; } = true;
        public int Login_Init()
        {
            bool login = SFIS.Login();
            if (login)
            {
                msg = "登录成功\r\n";
                log.write("SFIS登入成功");
                OnMessageCreate?.Invoke(msg);
                return 1;
            }
            else
            {
                msg = "登录失败\r\n";
                log.write("SFIS登入失败");
                OnMessageCreate?.Invoke(msg);
                return 4;
            }
        }
        public bool Decode_Function(string barcode,string REASON,string DUTY)
        {
            bool passStation;
            if (!SFIS.IsLogin) SFIS.Login();
            passStation = SFIS.WTSP_REPAIR(barcode, REASON, DUTY);
            if (passStation)
            {
                msg = "[" + barcode + "] AOI解碼成功！！！ [" + SFIS.LastMessage + "]\r\n";
                SFISresult = true;
                log.write(msg);
                OnMessageCreate?.Invoke(msg);
                msg= ReadBarcodeIsn1+"----->再次上傳SFIS";
                log.write(msg);
                PASS_Function(barcode);
                return true;
            }
            else
            {
                msg = "[" + barcode + "] AOI解碼失敗！！！[" + SFIS.LastMessage + "]\r\n";
                SFISmsg = "AOI解碼失敗";
                SFISresult = false;
                log.write(msg);
                OnMessageCreate?.Invoke(msg);
                return false;
            }
        }
        public bool PASS_Function(string barcode)
        {
            string text = "LABEL";
            bool passStation;
            if (!SFIS.IsLogin) SFIS.Login();
            passStation = SFIS.WTSP_RESULT(barcode, "", "Item,Value,UCL,LCL\n");
            if (passStation)
            {
                msg = "[" + barcode + "] SFIS网站上传成功！！！ [" + SFIS.LastMessage + "]\r\n";
                SFISmsg = "AOI上传成功";
                SFISresult = true;
                log.write(msg);
                OnMessageCreate?.Invoke(msg);
                return true;
            }
            else
            {
                text = SFIS.LastMessage;
                //msg = "[" + barcode + "] SFIS网站上传失败！！！[" + SFIS.LastMessage + "]\r\n";
                if (SFIS.LastMessage.Contains("BACK:PACKING"))
                {
                    msg = "[" + barcode + "] SFIS已過站!!!請到下一站！！！[" + SFIS.LastMessage + "]\r\n";
                    SFISmsg = "AOI已過站!!!請到下一站";
                }
                else if(SFIS.LastMessage.Contains("BACK:ACT2"))
                {
                    msg = "[" + barcode + "] 非本站點機臺,請檢查站點[" + SFIS.LastMessage + "]\r\n";
                    SFISmsg = "非本站點機臺,請檢查站點";
                }
                else if (SFIS.LastMessage.Contains("REPAIR OF AP01"))
                {
                    msg = "[" + barcode + "] 已鎖碼,經行解碼[" + SFIS.LastMessage + "]\r\n";
                    Decode_Function(barcode, cfg.REASON, cfg.DUTY);
                }
                else
                {
                    msg = "[" + barcode + "] SFIS网站上传失败！！！[" + SFIS.LastMessage + "]\r\n";
                    SFISmsg = "AOI上传失败";
                    SFISresult = false;
                }
                
                log.write(msg);
                OnMessageCreate?.Invoke(msg);
                return false;
            }
        }
        public bool NG_Function(string barcode, string errorcode)
        {
            bool passStation;
            if (!SFIS.IsLogin) SFIS.Login();
            passStation = SFIS.WTSP_RESULT(barcode, errorcode, "Item,Value,UCL,LCL\n");
            if (passStation)
            {
                msg = "[" + barcode + "] Faill已锁码！！！ [" + SFIS.LastMessage + "]\r\n";
                log.write(msg);
                OnMessageCreate?.Invoke(msg);
                return true;
            }
            else
            {
                msg = "[" + barcode + "] SFIS网站上传失败！！！[" + SFIS.LastMessage + "]\r\n";
                log.write(msg);
                OnMessageCreate?.Invoke(msg);
                return false;
            }
        }
        delegate void updateYieldHandler();
        private void updateYield()
        {
            LBCountPass.Text = CountPass.ToString();
            LBCountFail.Text = CountFail.ToString();
            LBCoutInput.Text = (CountPass + CountFail).ToString();
            if (CountPass > 0)
            {
                LBProductYield.Text = ((double)CountPass / (CountPass + CountFail)).ToString("P2").Replace("%", String.Empty);
            }
        }
        private void imageSN()
        {
            LBSN.Text = ReadBarcodeIsn1;
        }
    }
}
