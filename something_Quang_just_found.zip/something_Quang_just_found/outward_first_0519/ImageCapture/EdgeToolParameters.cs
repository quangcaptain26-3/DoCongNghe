﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageCapture
{
    public partial class EdgeToolForm 
    {
        bool isSetting = false;
        bool robotimage = false;
        bool displayROI = false;
        /// <summary>
        /// 相機擷取點位集合
        /// </summary>
        List<CaptureROI> ROIS = new List<CaptureROI>();
        /// <summary>
        /// 當下聚焦的點位
        /// </summary>
        CaptureROI selectedROI = null;// new Rectangle();
        /// <summary>
        /// 相機解析度集合
        /// </summary>
        List<Rectangle> cameraResolution = new List<Rectangle>();
        /// <summary>
        /// 相機對應的ImageBox
        /// </summary>
        List<Emgu.CV.UI.ImageBox> boxes;
        /// <summary>
        /// 要推論的圖檔路徑，這是根路徑，下面有根據相機序號建立子路徑
        /// </summary>
        public string Predict_Image_Path { get; set; }
        /// <summary>
        /// 所有相機截圖集合
        /// </summary>
        public List<List<Small_Image>> all_small_images = new List<List<Small_Image>>();
        /// <summary>
        /// 每支相機最後推論結果(最後結果是根據每張小圖推論做判定，有一張FAIL，該支相機最後結果就是FAIL)
        /// </summary>
        public Dictionary<string, string> predict_result=new Dictionary<string, string>();
        
        /// <summary>
        /// 推論圖片暫存資料夾(根據相機序號建立資料夾)
        /// </summary>
        //string[] predict_temporary_path;
        /// <summary>
        /// 推論完後，是否儲存圖片
        /// </summary>
        public bool Save_Image_After_Predict { get; set; }
        /// <summary>
        /// 推論完後，圖片儲存路徑
        /// </summary>
        public string Image_Path_After_Predict = null;
        /// <summary>
        /// 產品名稱，M2MLOG需要
        /// </summary>
        public string Product_Name { get; set; }

        public string DefaultLanguage { get; set; }
    }
}
