﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Emgu.CV;
using Emgu.CV.Structure;
using System.IO;
using System.Drawing;
using System.Xml;
using System.Xml.Serialization;


namespace ImageCapture
{
  
    internal static partial class ImageProcess
    {
        public static string timer;
        private static Image<Rgb, byte> img2;
        public static List<Small_Image> Capture(this Image<Rgb, byte> img, List<CaptureROI> ROIS, string captureSavePath)
        {
            int i = 0;
            List<Small_Image> result = new List<Small_Image>();
            foreach (CaptureROI roi in ROIS)
            {
                Rectangle rec = new Rectangle(roi.x, roi.y, roi.width, roi.height);
                img.ROI = rec;
                string timerP = Path.Combine(DateTime.Now.ToString("yyyyMMddHHmmss"));
                //string dir = Path.Combine(captureSavePath, $"{serial}_{timerP}_{string.Format("{0:d2}", i)}.jpg");
                //string dir = Path.Combine(captureSavePath, $"{roi.serial}_{timerP}_{string.Format("{0:d2}", i)}.png");
                string dir = Path.Combine(captureSavePath, $"{roi.serial}_{roi.index}_{timerP}_{string.Format("{0:d2}", i)}.png");
                timer = timerP;
                //using (Image<Rgb, byte> img2 = img.Copy().Resize(224, 224, Emgu.CV.CvEnum.Inter.Linear))
                //{
                //    img2.Save(dir);
                //}
                img2 = img.Copy().Resize(280, 280, Emgu.CV.CvEnum.Inter.Linear);
                img2.Save(dir);
                result.Add(new Small_Image() { 
                    imagePath = dir, 
                    predictResult = null, 
                    r = rec,
                    index=i,
                    //camera_serial=roi.index,
                    //camera_serial = roi.serial,
                    camera_serial = $"{roi.serial}_{roi.index}",
                    mask =roi.mask,
                    category=roi.category,
                });
                img.ROI = Rectangle.Empty;
                i++;
                img2.Dispose();
            }
            return result;
        }
    }
    public class CaptureROI
    {
        public int serial
        {
            get; set;
        }
        public int index
        {
            get; set;
        }
        public int x { get; set; }
        public int y { get; set; }
        public int width { get; set; }
        public int height { get; set; }
        public bool mask { get; set; } = false;
        public string category { get; set; } = "PASS";
        public override string ToString()
        {
            string s = x.ToString() + "," + y.ToString() + "," + width.ToString() + "," + height.ToString() + ";";
            return s;
        }
    }

    public class Small_Image
    {
        public string imagePath;
        public string predictResult;
        public static string predictResult2;
        public bool mask { get; set; } = false;
        public Rectangle r;
        /// <summary>
        /// 相機編號
        /// </summary>
        public string camera_serial { get; set; }
        /// <summary>
        /// 圖片對應編號
        /// </summary>
        public int index { get; set; }
        public string category { get; set; } = "1"; 

        public void ClearInfo()
        {
            this.imagePath = null;
            this.predictResult = null;
        }
        public void Save(string image_Path, string name)
        {
            string path = Path.Combine(image_Path, name, $"{DateTime.Now:yyyyMMdd}");
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            path = Path.Combine(path, this.predictResult, this.camera_serial.ToString());
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            string new_image = Path.Combine(path, $"{DateTime.Now:yyyyMMddHHmmss}_{string.Format("{0:d2}", this.index)}_{this.predictResult}.png");
            File.Copy(imagePath, new_image,true);
        }
        public void SavenewImage(string image_Path,string name)
        {
            
            string path = Path.Combine(image_Path, name, $"{DateTime.Now:yyyyMMdd}");
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            string new_image = Path.Combine(path, $"{DateTime.Now:yyyyMMddHHmmss}_{string.Format("{0:d2}", this.index)}_{this.predictResult}.png");
            File.Copy(imagePath, new_image,true);
        }

    }
   
}
