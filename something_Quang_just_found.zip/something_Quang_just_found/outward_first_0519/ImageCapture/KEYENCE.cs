﻿using Keyence.AutoID.SDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace KEYENCE
{
    public class Reader :IDisposable
    {
        public delegate void SerachReadersResultDelegate(List<ReaderSearchResult> result);
        public event SerachReadersResultDelegate SerachReadersResult;
        List<ReaderSearchResult> readers = new List<ReaderSearchResult>();
        public event Action<string> GetReaderReadResult;
        ReaderSearcher m_searcher = new ReaderSearcher();
        private Dictionary<string, ReaderAccessor> m_resisterdReaders = new Dictionary<string, ReaderAccessor>();

        public string IP { get; set; }
        public int port { get; set; } = 9004;
        public Reader(string ip)
        {
            this.IP = ip;
            this.port = port;
            SearchReaders();
        }
        public  void SearchReaders()
        {
            List<NicSearchResult> m_nicList = new List<NicSearchResult>();
            m_nicList = m_searcher.ListUpNic();
            if (this.IP != null)
            {
                string[] p = this.IP.Split(new char[] { '.' });
                if (m_nicList.Where(x => x.NicIpAddr.StartsWith(p[0])).Any())
                {
                    m_searcher.SelectedNicSearchResult = m_nicList.Where(x => x.NicIpAddr.StartsWith(p[0])).First();
                }
            }
            m_searcher.Start(new Action<ReaderSearchResult>(reader =>
            {
                ReaderSearchResult r = reader as ReaderSearchResult;
                if (!string.IsNullOrEmpty(r.IpAddress) && !(string.IsNullOrEmpty(r.ReaderName)))
                {
                    readers.Add(reader);
                    m_resisterdReaders.Add(r.ReaderName, new ReaderAccessor(r.IpAddress));
                }               
            }));
            Thread enumerateReader = new Thread(WaitEnumerateRaders);
            enumerateReader.Start();
        }
        public void Trigger()
        {
            foreach(ReaderAccessor reader in m_resisterdReaders.Values)
            {
                reader.Connect();
                string resp =reader.ExecCommand("LON");
                resp = resp.TrimEnd(new char[] { '\r', '\n' });
                if (GetReaderReadResult != null) GetReaderReadResult(resp);
            }
        }

        public string TriggerScanner()
        {
            string result;
            List<ReaderAccessor> readers = m_resisterdReaders.Values.ToList();
            readers[0].Connect();
            string resp = readers[0].ExecCommand("LON");
            resp = resp.TrimEnd(new char[] { '\r', '\n' });
            result = resp;
            return result;
        }

        public void WaitEnumerateRaders()
        {
            while (m_searcher.IsSearching)
            {
                Thread.Sleep(100);
            }
            if (SerachReadersResult != null) SerachReadersResult(readers); 
        }

        public void Dispose()
        {
            m_searcher.Dispose();
            foreach (ReaderAccessor reader in m_resisterdReaders.Values)
            {
                reader.Dispose();
            }
        }
    }


    public class TCPReader
    {

        const string Initial = "KEYENCE\r";
        const string Reader_Trigger = "LON\r";
        const string Reader_OFF = "LOFF\r";
        const string Reader_Tune = "TUNE,01\r";
        //const string Reader_Fine_Tune = "FTUNE\r";
        public event Action<string> GetReaderReadResult;
        ReaderSearcher m_searcher = new ReaderSearcher();
        TcpClient client = null;// new TcpClient();
        public string IP { get; set; }
        public int Port { get; set; }
        public TCPReader(string ip,int port=9004)
        {
            try
            {
                this.IP = ip;
                this.Port = port;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public bool Tune()
        {
            string result=GetResult(Reader_Tune);
            if (result.Contains("OK")) return true;
            else return false;
        }
        private string GetResult(string cmd)
        {
            try
            {
                byte[] b = Encoding.ASCII.GetBytes(cmd);
                string result = null;
                client = new TcpClient();
                client.Connect(IPAddress.Parse(this.IP), this.Port);
                NetworkStream stream = client.GetStream();
                stream.Write(b, 0, b.Length);
                byte[] buffer = new byte[64];

                int bytes = stream.Read(buffer, 0, buffer.Length);
                if (bytes > 0)
                {
                    result= Encoding.ASCII.GetString(buffer, 0, bytes);
                    result=result.TrimEnd(new char[] { '\r', '\n' });                   
                }
                
                stream.Close();
                //stream.Dispose();
                client.Close();
                
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
        public void Trigger()
        {
            string result = GetResult(Reader_Trigger);
            result = result.TrimEnd(new char[] { '\r', '\n' });
            if (GetReaderReadResult != null) GetReaderReadResult(result);
        }
    }
}
