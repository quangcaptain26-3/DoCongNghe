﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ImageCapture
{
    public partial class OptionForm2 : Form
    {
        public Screenshot_Area screenshot_area;
        public int max_h { get; set; }
        public  int max_w { get; set; }
        public delegate void UpdatePositionDelegate( Screenshot_Area area);
        public event EventHandler SaveCapturePosition;
        public event UpdatePositionDelegate UpdatePosition;

        public OptionForm2()
        {
            InitializeComponent();
        }
        public OptionForm2(Screenshot_Area s,int max_height, int max_width)
        {
            InitializeComponent();
            this.screenshot_area = s;
            this.max_h = max_height;
            this.max_w = max_width;
            trackBar_h.Maximum = max_height;
            trackBar_y.Maximum = max_height;
            trackBar_x.Maximum = max_width;
            trackBar_w.Maximum = max_width;
            
        }


        private void trackBar_Scroll(object sender, EventArgs e)
        {
     
            screenshot_area.r.X = trackBar_x.Value;
            screenshot_area.r.Y = trackBar_y.Value;
            screenshot_area.r.Height = trackBar_h.Value;
            screenshot_area.r.Width = trackBar_w.Value;

            if (UpdatePosition != null) UpdatePosition(screenshot_area);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (SaveCapturePosition != null) SaveCapturePosition(this, null);
        }

        private void OptionForm2_Load(object sender, EventArgs e)
        {

        }
    }
}
