﻿using AdvantechIOCard;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageCapture
{
    public partial class ScanInput : Form
    {
        public string Input => this.textBox1.Text.Trim();
        System.Windows.Forms.Timer tmr = new System.Windows.Forms.Timer();


        public ScanInput()
        {
            InitializeComponent();
        }

        public ScanInput(OutputControl io)
        {
            InitializeComponent();
            tmr.Interval = 1000;
            //tmr.Tick += (s, e) => {
                this.textBox1.Clear();
                this.textBox1.SelectAll();
                this.textBox1.Focus();

                io.WriteState(true);
                Thread.Sleep(500);
                io.WriteState(false);
            //};
            //tmr.Start();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.Close();
            }
        }

        private void ScanInput_Load(object sender, EventArgs e)
        {
            this.textBox1.Focus();
        }

    }
}
