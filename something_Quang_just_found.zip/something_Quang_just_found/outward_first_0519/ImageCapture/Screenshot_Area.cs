﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;

namespace ImageCapture
{
    public class Screenshot_Area
    {
        public string name { get; set; }
        public Rectangle r;
        public override string ToString()
        {
            return r.X.ToString()+","+r.Y.ToString()+","+r.Height.ToString()+","+r.Width.ToString();
        }
    }

    
}
