﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace ImageCapture
{
    public enum ProducerMode
    {
        online,
        debug,
        off_line,
    }
    public enum Log_type
    {
        VISION,
        ROBOT,
    }

    class M2MProducer2 : IDisposable
    {

        [DllImport(@"\M2MWrapper\CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr CreateM2MInstance(string device_id, string path, int mode);

        [DllImport(@"\M2MWrapper\CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern void DisposeM2MInstance(IntPtr pM2MInstance);

        [DllImport(@"\M2MWrapper\CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int Init_m2m(IntPtr pM2MInstance, string module_info, string device_info);

        [DllImport(@"\M2MWrapper\CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int Collect_data(IntPtr pM2MInstance, string module_info, string file_path);

        [DllImport(@"\M2MWrapper\CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int Get_sdk_version(StringBuilder ver, int length);

        [DllImport(@"\M2MWrapper\CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int Get_sdk_name(StringBuilder name, int length);

        [DllImport(@"\M2MWrapper\CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int ConstructExecutingM2MMessage(IntPtr pM2MInstance, string module_info, string executing_info);

        [DllImport(@"\M2MWrapper\CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int ConstructCompletionM2MMessage(IntPtr pM2MInstance, string module_info, string completion_info);

        [DllImport(@"\M2MWrapper\CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern int ConstructM2MMessage(IntPtr pM2MInstance, string module_info, string dut_info, string resp_info, string img_path, bool send_img);


        //[DllImport("CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        //private static extern IntPtr CreateM2MInstance(string device_id, string path, int mode);

        //[DllImport("CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        //private static extern void DisposeM2MInstance(IntPtr pM2MInstance);

        //[DllImport("CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        //private static extern int Init_m2m(IntPtr pM2MInstance, string module_info, string device_info);

        //[DllImport("CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        //private static extern int Collect_data(IntPtr pM2MInstance, string module_info, string file_path);

        //[DllImport("CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        //private static extern int Get_sdk_version(StringBuilder ver, int length);

        //[DllImport("CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        //private static extern int Get_sdk_name(StringBuilder name, int length);

        //[DllImport("CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        //private static extern int ConstructExecutingM2MMessage(IntPtr pM2MInstance, string module_info, string executing_info);

        //[DllImport("CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        //private static extern int ConstructCompletionM2MMessage(IntPtr pM2MInstance, string module_info, string completion_info);

        //[DllImport("CambrianM2MWrapper.dll", CallingConvention = CallingConvention.Cdecl)]
        //private static extern int ConstructM2MMessage(IntPtr pM2MInstance, string module_info, string dut_info, string resp_info, string img_path, bool send_img);


        public delegate void InitialProducerHandler(string skdName, string version);
        public event InitialProducerHandler ProducerInitialComplete;

        string producerPath { get; set; }
        IntPtr pM2MClass = IntPtr.Zero;
        public ProducerMode mode { get; }
        public string deviceid { get; }
        public string module_Name { get; set; }
        public string plant { get; set; }
        public string line { get; set; }
        public string station_Name { get; set; }
        public Log_type type { get; set; } = Log_type.VISION;
        string module_info = null;
        StringBuilder version = new StringBuilder(0, 256);
        StringBuilder name = new StringBuilder(0, 256);
        public bool IsReady { get; set; } = false;
        public string master_info { get; set; }
        public string vision_info { get; set; }
        string device_Info { get; set; }
        public pegatron.basic.pegatronLog log;
        public M2MProducer2(string producerPath, string deviceid, ProducerMode mode,string plant, 
            string line, string module_name,
            string station,pegatron.basic.pegatronLog log)
        {
            try
            {

                this.producerPath = producerPath;
                this.mode = mode;
                this.deviceid = deviceid;
                this.plant = plant;
                this.line = line;
                this.module_Name = module_name;
                this.station_Name = station;
                master_info= "{" +
                    "\"module_name\": \""+ module_name +"\"," +
                    "\"log_type\" : \"MASTER\"" +
                    "}";
                vision_info = "{" +
                    "\"module_name\": \""+ module_name +"\"," +                    
                    "\"log_type\" : \"VISION\"," +
                    "\"model_version\" : \"1.0.0.1\"," +
                    "\"inference_module\" : \"classification\"" +
                    "}";
                this.log = log;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
       
        public void CreateInstance()
        {
            
            pM2MClass = CreateM2MInstance(deviceid, producerPath, (int)this.mode);
            this.IsReady = true;
        }
        public int    CreateVisionLogTypeInstance(string device_Info)
        {
            try
            {

                this.device_Info = device_Info;
                IniProducer();
                this.CreateInstance();
                if (pM2MClass != IntPtr.Zero)
                {
                    if (log != null)
                    {
                        log.write("master_info=" + master_info);
                        log.write("master_device_info=" + device_Info+"\r\n");
                    }
                    int ret = Init_m2m(pM2MClass, master_info, device_Info);
                    if (ret != 0)  throw new Exception($"initila m2m Master info error:({ret})");
                    else
                    {
                        if (log != null)
                        {
                            log.write("visoin_info=" + master_info);
                            log.write("vision_device_info={}" +"\r\n");
                        }
                        ret = Init_m2m(pM2MClass, vision_info, "{}");//device_vision_info寫空的~~
                        return ret;
                    }
                }
                else throw new Exception("Create M2M instance fail.");
                                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int ExecuteConstructMaster(string construct_info)
        {
            if (log != null)
            {
                log.write("run ConstructExecutingM2MMessage...");
                log.write("master info=" + master_info);
                log.write("construct_info=" + construct_info+"\r\n");
            }
            int ret = ConstructExecutingM2MMessage(pM2MClass, master_info, construct_info);
            return ret;
        }
        public int ExecuteConstructM2MMessage(string dut_info,string imagePath,string predict_response_Info)
        {
            if (log != null)
            {
                log.write("run ConstructM2MMessage...");
                log.write("vision_info=" + vision_info);
                log.write("dut_info=" + dut_info);
                log.write("resp_info=" + predict_response_Info);
                log.write("image path=" + imagePath+"\r\n");
            }
            int ret = ConstructM2MMessage(this.pM2MClass, this.vision_info, dut_info, predict_response_Info, imagePath, true);
            return ret;

        }
        public int ExecuteConstructCompletionM2MMessage(string completion_Info)
        {
            if (log != null)
            {
                log.write("run  ConstructCompletionM2MMessage...");
                log.write("master_info=" + master_info);
                log.write("completion_Info=" + completion_Info+"\r\n");
              
            }
            int ret = ConstructCompletionM2MMessage(pM2MClass, master_info, completion_Info);
            return ret;
        }
        private void IniProducer()
        {

            try
            {
                Get_sdk_version(version, 256);
                Get_sdk_name(name, 256);
                if (ProducerInitialComplete != null)
                {
                    ProducerInitialComplete(name.ToString(), version.ToString());
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public void SetModule_Info()
        {
            module_info =
                    "{" +
                    "\"module_name\": \"" + this.module_Name + "\"," +
                    "\"log_type\" : \"" + this.type.ToString() + "\"," +
                    "\"model_version\" : \"1.0.0.1\"," +
                    "\"inference_module\" : \"\"" +
                    "}";
        }
        public int UploadCambrian(string imageFile)
        {

            int ret = -1;
            if (module_info == null) SetModule_Info();
            if (pM2MClass != IntPtr.Zero)
            {
                string device_info = "{}";
                Init_m2m(pM2MClass, module_info, device_info);
                ret = Collect_data(pM2MClass, module_info, imageFile);
            }
            return ret;
        }
        #region IDisposable Support
        private bool disposedValue = false; // 要检测冗余调用

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 释放托管状态(托管对象)。
                }

                // TODO: 释放未托管的资源(未托管的对象)并在以下内容中替代终结器。
                // TODO: 将大型字段设置为 null。

                disposedValue = true;
            }
        }

        // TODO: 仅当以上 Dispose(bool disposing) 拥有用于释放未托管资源的代码时才替代终结器。
        // ~M2MProducer() {
        //   // 请勿更改此代码。将清理代码放入以上 Dispose(bool disposing) 中。
        //   Dispose(false);
        // }

        // 添加此代码以正确实现可处置模式。
        public void Dispose()
        {
            // 请勿更改此代码。将清理代码放入以上 Dispose(bool disposing) 中。
            Dispose(true);
            if (pM2MClass != IntPtr.Zero) DisposeM2MInstance(pM2MClass);
            pM2MClass = IntPtr.Zero;

            // TODO: 如果在以上内容中替代了终结器，则取消注释以下行。
            // GC.SuppressFinalize(this);
        }
        #endregion

    }
}
