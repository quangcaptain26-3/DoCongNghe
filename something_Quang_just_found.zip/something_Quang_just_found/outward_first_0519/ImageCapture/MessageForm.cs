﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ImageCapture
{
    public partial class MessageForm : Form
    {
        public MessageForm()
        {
            InitializeComponent();
        }

        public void SetMessage(string msg)
        {
            lbMSG.Text = msg;
            this.Width = msg.Length * 12;
            this.Text = msg;
            this.Refresh();
        }
    }
}